RPP multi-version source project (best-effort compatibility scaffold)

Build target commands:
  Paper 1.21.11: mvn -Ppaper-1.21.11 clean package
  Paper 26.3:    mvn -Ppaper-26.3 clean package

Requirements:
  - Java 21 JDK for the Paper 1.21.11 build
  - Java 25 JDK for the Paper 26.3 build
  - Maven 3.9+

Important:
This project now has Maven's standard src/main/java and src/main/resources layout and separate build profiles.
The source originated from a supplied plugin archive and has NOT been compiled or runtime-tested against both Paper versions here.
Paper API and Minecraft internals changed between 1.21.11 and 26.3; reflective NMS/fake-connection functionality may need version-specific fixes.
If a build fails, share the full Maven output so the specific API incompatibilities can be fixed.
The plugin.yml api-version is generated from the selected profile.

Updated build commands (run from the folder containing pom.xml):
  Paper 1.21.11: mvn -Ppaper-1.21.11 clean package   (JDK 21 or newer; output target\RPP-1.21.11.jar)
  Paper 26.2:    mvn -Ppaper-26.2 clean package      (JDK 25; output target\RPP-26.2.jar)
  Paper 26.3:    mvn -Ppaper-26.3 clean package      (JDK 25; output target\RPP-26.3.jar)
The compiler now runs forked so real javac errors are printed instead of the "this.hashes is null" crash.
