import com.rppbot.plugin.motion.*;
public class WasdSelfTest {
   static int fails = 0;
   static void check(boolean ok, String msg) { if (!ok) { fails++; System.out.println("FAIL: " + msg); } }
   public static void main(String[] a) {
      WasdKeys k = new WasdKeys();
      // facing +Z (yaw 0): wanting +Z => W; wanting -X (right hand) => D; wanting +X => A; wanting -Z => S
      WasdMotor.chooseKeys(k, 0, 1, 0f);  check(k.sector()==0, "ahead W got " + k);
      k = new WasdKeys(); WasdMotor.chooseKeys(k, -1, 0, 0f); check(k.sector()==2, "right D got " + k);
      k = new WasdKeys(); WasdMotor.chooseKeys(k, 1, 0, 0f);  check(k.sector()==6, "left A got " + k);
      k = new WasdKeys(); WasdMotor.chooseKeys(k, 0, -1, 0f); check(k.sector()==4, "back S got " + k);
      k = new WasdKeys(); WasdMotor.chooseKeys(k, -1, 1, 0f); check(k.sector()==1, "W+D got " + k);
      k = new WasdKeys(); WasdMotor.chooseKeys(k, 1, 1, 0f);  check(k.sector()==7, "W+A got " + k);
      // yaw 90 faces -X; wanting -X => W
      k = new WasdKeys(); WasdMotor.chooseKeys(k, -1, 0, 90f); check(k.sector()==0, "yaw90 W got " + k);
      // round trip: for any yaw/dir, wish direction from chosen keys is within 22.5deg+hyst of wanted
      double[] w = new double[2]; double worst = 0;
      java.util.Random r = new java.util.Random(1);
      for (int i = 0; i < 20000; i++) {
         float yaw = r.nextFloat()*360-180; double ang = r.nextDouble()*Math.PI*2;
         double dx = Math.cos(ang), dz = Math.sin(ang);
         WasdKeys kk = new WasdKeys();
         WasdMotor.chooseKeys(kk, dx, dz, yaw);
         WasdMotor.wishDirection(kk, yaw, w);
         double dot = dx*w[0]+dz*w[1]; double err = Math.toDegrees(Math.acos(Math.max(-1,Math.min(1,dot))));
         worst = Math.max(worst, err);
      }
      System.out.println("worst heading error fresh keys (deg): " + worst);
      check(worst <= 22.6, "heading error too big " + worst);
      // hysteresis: keys do not flicker for tiny bearing wobble
      k = new WasdKeys(); WasdMotor.chooseKeys(k, 0, 1, 0f); int flips = 0; int prev = k.sector();
      for (int i = 0; i < 1000; i++) { double e = Math.toRadians(20*Math.sin(i*0.7)); WasdMotor.chooseKeys(k, Math.sin(e), Math.cos(e), 0f); if (k.sector()!=prev){flips++;prev=k.sector();} }
      check(flips == 0, "flicker flips=" + flips);
      // corner test: running +Z at sprint speed, path turns 90deg to +X. Body yaw turns 28deg/tick. Bot must never drop below 60% speed.
      double[] vel = {0, 0.629}; double speedMin = 1e9; float yaw = 0; WasdKeys kc = new WasdKeys(); double[] wish = new double[2];
      for (int t = 0; t < 14; t++) {
         float targetYaw = (float)Math.toDegrees(Math.atan2(-1, 0)); // heading +X => yaw -90
         double d = WasdMotor.wrap180(targetYaw - yaw); yaw += Math.copySign(Math.min(Math.abs(d), 28), d);
         WasdMotor.chooseKeys(kc, 1, 0, yaw);
         WasdMotor.wishDirection(kc, yaw, wish);
         WasdMotor.integrate(vel, wish, 0.629, true, true);
         double sp = Math.hypot(vel[0], vel[1]); speedMin = Math.min(speedMin, sp);
         if (t < 5 || t == 13) System.out.printf("t=%d yaw=%.0f keys=%s vel=(%.3f,%.3f) speed=%.3f%n", t, yaw, kc, vel[0], vel[1], sp);
      }
      System.out.println("min speed through 90deg corner: " + speedMin);
      check(speedMin > 0.38, "bot slowed too much at corner " + speedMin);
      // release keys on ground -> stops
      vel = new double[]{0.6, 0}; for (int t=0;t<8;t++) WasdMotor.integrate(vel, new double[]{0,0}, 0.6, true, false);
      check(vel[0]==0 && vel[1]==0, "should be stopped " + vel[0]);
      // air steering: still able to change direction a bit, keeps momentum
      vel = new double[]{0, 0.5}; for (int t=0;t<6;t++) WasdMotor.integrate(vel, new double[]{1,0}, 0.5, false, true);
      System.out.printf("air after 6 ticks vel=(%.3f,%.3f)%n", vel[0], vel[1]);
      check(vel[0] > 0.1 && vel[1] > 0.1, "air steering unexpected");
      System.out.println(fails == 0 ? "ALL PASS" : fails + " FAILURES");
   }
}
