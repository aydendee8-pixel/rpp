RPP 1.7.0 - W/A/S/D movement + PvP overhaul
===========================================

NOT COMPILED OR RUN against Paper. The sandbox this was written in could not reach the Paper repo, so only the pure
motion maths (motion/WasdKeys, motion/WasdMotor) was compiled and tested (tools/WasdSelfTest.java). Build with the
profile commands in README-MULTIVERSION.txt and send the Maven output if anything fails.

1) One movement system: virtual W/A/S/D
---------------------------------------
Every kind of walking now presses virtual keys (WasdKeys) and goes through RppCommand.driveKeys():
paths, follow, formation, patrol, roam, breeding walk, build walking, combat footwork and mid-air steering.
- Keys are chosen against the body's CURRENT yaw, so a bot that is still turning keeps moving with A/D/S
  instead of stopping to pivot.
- Sprint needs W held (like the real game); jumps are a key too (sprint-jumps get the vanilla forward boost).
- Direction changes are absorbed by grip (WasdMotor.GROUND_GRIP / AIR_GRIP), not by braking: a 90 degree corner at
  sprint speed keeps >80% of its speed in the unit test. Mid-air the same keys steer, with weaker grip.
- Path following advances a node when the bot has run past it, and a corner-cutting look-ahead point that would send
  it over an edge falls back to the exact path node instead of stopping dead.
- Top speeds are the PLAYER_WALK_SPEED / SPRINT_SPEED constants. I could not run a server to compare them with the
  old effective speeds, so tune those two constants if bots feel faster/slower than before.

2) PvP
------
- Real attack cooldown per weapon (sword 1.6/s, axe 0.8-1.0/s, mace 0.6/s, fists 4/s ...) and charge-scaled damage
  (0.2 + 0.8*charge^2). Bots wait for ~92-99% charge, like players.
- Hits need reach <= 3.0 to the target's hitbox, a clear line of sight, AND the crosshair on the hitbox.
- Aim lags the target by 1-2 ticks and has small wobble; first contact has a 4-9 tick reaction delay.
- Jump-crits (falling, not sprinting, full charge), sprint-hits with extra knockback and W-taps, plain hits.
- Footwork: A/D circle-strafing with random flips/pauses, W/S spacing, no strafing off ledges or into walls.
- Shield: raised with the real use-item state (so the game does the blocking), with a reaction delay, only when the
  attacker is facing it; manual fallback block if the game is not blocking for it; axe hits disable it for 5 s.
- Below 30% health the bot runs (sprint+W) away from walls/edges until ~55% or 16 blocks, or fights back if cornered.
- Target choice: a bot only switches to a new attacker if it is clearly closer/bigger threat.
- Knocked-back bots can still aim and swing (movement is skipped so knockback is not cancelled).
- Attack sounds/crit particles like a player.

3) Not in this codebase
-----------------------
"Tower spots" do not exist in this source, so nothing was changed for them.
