package com.rppbot.plugin.schematic;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;

public final class LoadedSchematic {
   public final String name;
   public Schematic schematic;
   public final BlockData[] states;
   public final BlockCost.ItemCost[] costs;
   public final int buildableBlocks;
   public final int unsupportedBlocks;
   private World world;
   private int centerX;
   private int centerY;
   private int centerZ;
   private boolean originSet;
   public boolean previewVisible;
   public int previewVersion;
   public final GhostPreview ghost = new GhostPreview();
   public int rotationTurns;

   private LoadedSchematic(String name, Schematic schematic, BlockData[] states, BlockCost.ItemCost[] costs, int buildable, int unsupported) {
      this.name = name;
      this.schematic = schematic;
      this.states = states;
      this.costs = costs;
      this.buildableBlocks = buildable;
      this.unsupportedBlocks = unsupported;
   }

   public static LoadedSchematic create(String name, Schematic schematic) {
      int paletteSize = schematic.palette.length;
      BlockData[] states = new BlockData[paletteSize];
      BlockCost.ItemCost[] costs = new BlockCost.ItemCost[paletteSize];
      boolean[] air = new boolean[paletteSize];

      for(int i = 0; i < paletteSize; ++i) {
         String state = schematic.palette[i];
         air[i] = Schematic.isAirState(state);
         if (!air[i]) {
            try {
               states[i] = Bukkit.createBlockData(state);
               costs[i] = BlockCost.of(states[i]);
            } catch (NullPointerException | IllegalArgumentException var11) {
               states[i] = null;
               costs[i] = null;
            }
         }
      }

      long[] counts = new long[paletteSize];

      for(int b : schematic.blocks) {
         counts[b]++;
      }

      int buildable = 0;
      int unsupported = 0;

      for(int i = 0; i < paletteSize; ++i) {
         if (!air[i]) {
            if (costs[i] != null) {
               buildable += (int)counts[i];
            } else {
               unsupported += (int)counts[i];
            }
         }
      }

      return new LoadedSchematic(name, schematic, states, costs, buildable, unsupported);
   }

   public void setCenter(Location location) {
      this.world = location.getWorld();
      this.centerX = location.getBlockX();
      this.centerY = location.getBlockY();
      this.centerZ = location.getBlockZ();
      this.originSet = true;
      ++this.previewVersion;
   }

   public void inheritOrigin(LoadedSchematic other) {
      if (other.hasOrigin()) {
         this.world = other.world;
         this.centerX = other.centerX;
         this.centerY = other.centerY;
         this.centerZ = other.centerZ;
         this.originSet = true;
      }

      if (other.rotationTurns != 0) {
         this.rotate(other.rotationTurns);
      }

      ++this.previewVersion;
   }

   public void rotate(int quarterTurns) {
      int turns = (quarterTurns % 4 + 4) % 4;

      for(int t = 0; t < turns; ++t) {
         this.rotateOnce();
      }

      this.rotationTurns = (this.rotationTurns + turns) % 4;
      ++this.previewVersion;
   }

   private void rotateOnce() {
      Schematic old = this.schematic;
      int w = old.width;
      int h = old.height;
      int l = old.length;
      int newW = l;
      int newL = w;
      int[] rotated = new int[old.blocks.length];

      for(int y = 0; y < h; ++y) {
         for(int z = 0; z < l; ++z) {
            for(int x = 0; x < w; ++x) {
               int nx = l - 1 - z;
               rotated[(y * newL + x) * newW + nx] = old.blocks[(y * l + z) * w + x];
            }
         }
      }

      for(int i = 0; i < this.states.length; ++i) {
         if (this.states[i] != null) {
            this.states[i] = BlockRotation.clockwise(this.states[i]);
            old.palette[i] = this.states[i].getAsString();
         }
      }

      this.schematic = new Schematic(old.name, old.format, newW, h, newL, old.palette, rotated);
   }

   public boolean hasOrigin() {
      return this.originSet && this.world != null;
   }

   public World world() {
      return this.world;
   }

   public int minX() {
      return this.centerX - this.schematic.width / 2;
   }

   public int minY() {
      return this.centerY;
   }

   public int minZ() {
      return this.centerZ - this.schematic.length / 2;
   }

   public int maxX() {
      return this.minX() + this.schematic.width - 1;
   }

   public int maxY() {
      return this.minY() + this.schematic.height - 1;
   }

   public int maxZ() {
      return this.minZ() + this.schematic.length - 1;
   }

   public int worldX(int index) {
      return this.minX() + index % this.schematic.width;
   }

   public int worldZ(int index) {
      return this.minZ() + index / this.schematic.width % this.schematic.length;
   }

   public int worldY(int index) {
      return this.minY() + index / (this.schematic.width * this.schematic.length);
   }
}
