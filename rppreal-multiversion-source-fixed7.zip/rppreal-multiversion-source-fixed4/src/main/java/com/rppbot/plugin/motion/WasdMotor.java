package com.rppbot.plugin.motion;

/**
 * Pure maths for the W/A/S/D movement model (no Bukkit types so it can be unit-tested).
 *
 * Minecraft yaw convention: yaw 0 faces +Z, forward = (-sin yaw, cos yaw), the player's
 * right hand (D key) = (-cos yaw, -sin yaw).
 */
public final class WasdMotor {
   /** A key combo is kept until the wanted bearing is this far outside its 45 degree sector (anti-flicker). */
   private static final double SECTOR_HYSTERESIS_DEGREES = 31.0;
   /** Horizontal grip while keys are held on the ground: fraction of the velocity error corrected per tick. */
   public static final double GROUND_GRIP = 0.62;
   /** Horizontal grip while keys are released on the ground (friction / braking). */
   public static final double GROUND_BRAKE_GRIP = 0.55;
   /** Mid-air steering: weaker than ground, but the same keys. */
   public static final double AIR_GRIP = 0.13;
   public static final double AIR_DRAG = 0.985;
   public static final double MAX_ACCEL_GROUND = 0.46;
   public static final double MAX_ACCEL_AIR = 0.09;

   private WasdMotor() {
   }

   public static double forwardX(float yawDeg) {
      return -Math.sin(Math.toRadians(yawDeg));
   }

   public static double forwardZ(float yawDeg) {
      return Math.cos(Math.toRadians(yawDeg));
   }

   public static double rightX(float yawDeg) {
      return -Math.cos(Math.toRadians(yawDeg));
   }

   public static double rightZ(float yawDeg) {
      return -Math.sin(Math.toRadians(yawDeg));
   }

   /** Bearing of a world direction relative to the facing yaw, degrees, 0 = ahead, +90 = to the right. */
   public static double relativeBearing(double dirX, double dirZ, float yawDeg) {
      double f = dirX * forwardX(yawDeg) + dirZ * forwardZ(yawDeg);
      double r = dirX * rightX(yawDeg) + dirZ * rightZ(yawDeg);
      return Math.toDegrees(Math.atan2(r, f));
   }

   /**
    * Chooses which of the eight W/A/S/D combinations moves the bot along (dirX, dirZ) given where
    * its body currently faces. Writes the result into {@code keys} (movement keys only).
    * Because the bearing is taken against the CURRENT yaw, a bot whose body is still turning keeps
    * moving along its path with A/D/S instead of stopping to pivot.
    */
   public static void chooseKeys(WasdKeys keys, double dirX, double dirZ, float yawDeg) {
      double len = Math.sqrt(dirX * dirX + dirZ * dirZ);
      if (len < 1.0E-6) {
         keys.setSector(-1);
         return;
      }

      double bearing = relativeBearing(dirX / len, dirZ / len, yawDeg);
      int previous = keys.sector();
      if (previous >= 0) {
         double center = previous * 45.0;
         double diff = Math.abs(wrap180(bearing - center));
         if (diff <= SECTOR_HYSTERESIS_DEGREES) {
            return;
         }
      }

      double normalized = bearing < 0.0 ? bearing + 360.0 : bearing;
      int sector = (int)Math.round(normalized / 45.0) % 8;
      keys.setSector(sector);
   }

   /** World-space unit wish direction produced by the held keys (zero vector when none). */
   public static void wishDirection(WasdKeys keys, float yawDeg, double[] out) {
      double f = keys.forwardAxis();
      double r = keys.strafeAxis();
      double len = Math.sqrt(f * f + r * r);
      if (len < 1.0E-6) {
         out[0] = 0.0;
         out[1] = 0.0;
         return;
      }

      f /= len;
      r /= len;
      out[0] = forwardX(yawDeg) * f + rightX(yawDeg) * r;
      out[1] = forwardZ(yawDeg) * f + rightZ(yawDeg) * r;
   }

   /**
    * One tick of horizontal velocity. {@code vel} holds the current horizontal velocity and receives the new one.
    * Direction changes are absorbed by the grip (not by stopping), so sharp corners keep their speed.
    */
   public static void integrate(double[] vel, double[] wish, double maxSpeed, boolean grounded, boolean keysHeld) {
      double desiredX = wish[0] * maxSpeed;
      double desiredZ = wish[1] * maxSpeed;
      double grip;
      double maxAccel;
      if (grounded) {
         grip = keysHeld ? GROUND_GRIP : GROUND_BRAKE_GRIP;
         maxAccel = MAX_ACCEL_GROUND;
      } else {
         grip = keysHeld ? AIR_GRIP : 0.0;
         maxAccel = MAX_ACCEL_AIR;
         vel[0] *= AIR_DRAG;
         vel[1] *= AIR_DRAG;
      }

      double dx = (desiredX - vel[0]) * grip;
      double dz = (desiredZ - vel[1]) * grip;
      double dlen = Math.sqrt(dx * dx + dz * dz);
      if (dlen > maxAccel) {
         double k = maxAccel / dlen;
         dx *= k;
         dz *= k;
      }

      vel[0] += dx;
      vel[1] += dz;
      if (!keysHeld && grounded && vel[0] * vel[0] + vel[1] * vel[1] < 0.035 * 0.035) {
         vel[0] = 0.0;
         vel[1] = 0.0;
      }

      double speed = Math.sqrt(vel[0] * vel[0] + vel[1] * vel[1]);
      double cap = Math.max(maxSpeed, 0.0);
      if (keysHeld && speed > cap && grounded) {
         vel[0] *= cap / speed;
         vel[1] *= cap / speed;
      }
   }

   public static double wrap180(double degrees) {
      double w = degrees % 360.0;
      if (w >= 180.0) {
         w -= 360.0;
      } else if (w < -180.0) {
         w += 360.0;
      }

      return w;
   }
}
