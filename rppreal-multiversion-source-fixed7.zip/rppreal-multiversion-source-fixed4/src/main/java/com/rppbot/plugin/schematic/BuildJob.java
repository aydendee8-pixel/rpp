package com.rppbot.plugin.schematic;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Material;

public final class BuildJob {
   public final LoadedSchematic schem;
   public final UUID owner;
   public final int total;
   private final int[] order;
   private int cursor;
   private final ArrayDeque<Integer> deferred = new ArrayDeque();
   private final Map<Integer, Integer> attempts = new HashMap();
   private static final int MAX_ATTEMPTS = 3;
   private final Set<Material> unavailable = new HashSet();
   private final Map<Material, Integer> missing = new LinkedHashMap();
   public int placed;
   public int alreadyCorrect;
   public int skippedMissing;
   public int skippedUnreachable;
   public boolean noChestReported;

   public BuildJob(LoadedSchematic schem, UUID owner) {
      this.schem = schem;
      this.owner = owner;
      Schematic s = schem.schematic;
      int[] tmp = new int[Math.max(0, schem.buildableBlocks)];
      int n = 0;

      for(int y = 0; y < s.height; ++y) {
         for(int z = 0; z < s.length; ++z) {
            boolean reverse = (z & 1) == 1;

            for(int i = 0; i < s.width; ++i) {
               int x = reverse ? s.width - 1 - i : i;
               int idx = s.index(x, y, z);
               if (schem.costs[s.blocks[idx]] != null && n < tmp.length) {
                  tmp[n++] = idx;
               }
            }
         }
      }

      this.order = n == tmp.length ? tmp : Arrays.copyOf(tmp, n);
      this.total = n;
   }

   public int[] claimBatch(int max) {
      int available = this.order.length - this.cursor;
      int take = Math.min(max, available);
      if (take > 0) {
         int[] batch = new int[take];
         System.arraycopy(this.order, this.cursor, batch, 0, take);
         this.cursor += take;
         return batch;
      } else {
         int n = Math.min(max, this.deferred.size());
         int[] batch = new int[n];

         for(int i = 0; i < n; ++i) {
            batch[i] = (Integer)this.deferred.poll();
         }

         return batch;
      }
   }

   public void defer(int index) {
      int tries = (Integer)this.attempts.merge(index, 1, Integer::sum);
      if (tries >= 3) {
         ++this.skippedUnreachable;
      } else {
         this.deferred.add(index);
      }

   }

   public int remaining() {
      return this.order.length - this.cursor + this.deferred.size();
   }

   public boolean isUnavailable(Material item) {
      return this.unavailable.contains(item);
   }

   public boolean markUnavailable(Material item) {
      return this.unavailable.add(item);
   }

   public void giveBack(int[] batch, int fromPos) {
      for(int i = fromPos; i < batch.length; ++i) {
         this.deferred.add(batch[i]);
      }

   }

   public void recordMissing(Material item) {
      ++this.skippedMissing;
      this.missing.merge(item, 1, Integer::sum);
   }

   public Map<Material, Integer> missingCounts() {
      return this.missing;
   }
}
