package com.rppbot.plugin.schematic;

import java.util.Map;
import java.util.Set;
import org.bukkit.Material;
import org.bukkit.block.data.Bisected;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Bisected.Half;
import org.bukkit.block.data.type.Bed;
import org.bukkit.block.data.type.Candle;
import org.bukkit.block.data.type.Door;
import org.bukkit.block.data.type.SeaPickle;
import org.bukkit.block.data.type.Slab;
import org.bukkit.block.data.type.Snow;
import org.bukkit.block.data.type.TurtleEgg;
import org.bukkit.block.data.type.Bed.Part;
import org.bukkit.block.data.type.Slab.Type;

public final class BlockCost {
   private static final Map<String, String> ITEM_OVERRIDES = Map.ofEntries(Map.entry("WHEAT", "WHEAT_SEEDS"), Map.entry("POTATOES", "POTATO"), Map.entry("CARROTS", "CARROT"), Map.entry("BEETROOTS", "BEETROOT_SEEDS"), Map.entry("MELON_STEM", "MELON_SEEDS"), Map.entry("ATTACHED_MELON_STEM", "MELON_SEEDS"), Map.entry("PUMPKIN_STEM", "PUMPKIN_SEEDS"), Map.entry("ATTACHED_PUMPKIN_STEM", "PUMPKIN_SEEDS"), Map.entry("TORCHFLOWER_CROP", "TORCHFLOWER_SEEDS"), Map.entry("PITCHER_CROP", "PITCHER_POD"), Map.entry("SWEET_BERRY_BUSH", "SWEET_BERRIES"), Map.entry("COCOA", "COCOA_BEANS"), Map.entry("REDSTONE_WIRE", "REDSTONE"), Map.entry("TRIPWIRE", "STRING"), Map.entry("KELP_PLANT", "KELP"), Map.entry("TWISTING_VINES_PLANT", "TWISTING_VINES"), Map.entry("WEEPING_VINES_PLANT", "WEEPING_VINES"), Map.entry("CAVE_VINES", "GLOW_BERRIES"), Map.entry("CAVE_VINES_PLANT", "GLOW_BERRIES"), Map.entry("TALL_SEAGRASS", "SEAGRASS"), Map.entry("BAMBOO_SAPLING", "BAMBOO"), Map.entry("BIG_DRIPLEAF_STEM", "BIG_DRIPLEAF"), Map.entry("POWDER_SNOW", "POWDER_SNOW_BUCKET"), Map.entry("WATER_CAULDRON", "CAULDRON"), Map.entry("LAVA_CAULDRON", "CAULDRON"), Map.entry("POWDER_SNOW_CAULDRON", "CAULDRON"));
   private static final Set<String> TALL_PLANTS = Set.of("TALL_GRASS", "LARGE_FERN", "SUNFLOWER", "LILAC", "ROSE_BUSH", "PEONY", "TALL_SEAGRASS", "PITCHER_PLANT");

   private BlockCost() {
   }

   public static ItemCost of(BlockData data) {
      if (data == null) {
         return null;
      } else {
         Material block = data.getMaterial();
         if (block.isAir()) {
            return null;
         } else {
            Material item = itemFor(block);
            if (item == null) {
               return null;
            } else {
               int count = 1;
               if (data instanceof Bed) {
                  Bed bed = (Bed)data;
                  count = bed.getPart() == Part.HEAD ? 0 : 1;
               } else if (data instanceof Door) {
                  Door door = (Door)data;
                  count = door.getHalf() == Half.TOP ? 0 : 1;
               } else {
                  if (data instanceof Bisected) {
                     Bisected bisected = (Bisected)data;
                     if (TALL_PLANTS.contains(block.name())) {
                        count = bisected.getHalf() == Half.TOP ? 0 : 1;
                        return new ItemCost(item, count);
                     }
                  }

                  if (data instanceof Slab) {
                     Slab slab = (Slab)data;
                     count = slab.getType() == Type.DOUBLE ? 2 : 1;
                  } else if (data instanceof Snow) {
                     Snow snow = (Snow)data;
                     count = Math.max(1, snow.getLayers());
                  } else if (data instanceof SeaPickle) {
                     SeaPickle pickle = (SeaPickle)data;
                     count = Math.max(1, pickle.getPickles());
                  } else if (data instanceof Candle) {
                     Candle candle = (Candle)data;
                     count = Math.max(1, candle.getCandles());
                  } else if (data instanceof TurtleEgg) {
                     TurtleEgg egg = (TurtleEgg)data;
                     count = Math.max(1, egg.getEggs());
                  }
               }

               return new ItemCost(item, count);
            }
         }
      }
   }

   private static Material itemFor(Material block) {
      String name = block.name();
      String override = (String)ITEM_OVERRIDES.get(name);
      if (override != null) {
         return Material.matchMaterial(override);
      } else if (name.startsWith("POTTED_")) {
         return Material.matchMaterial("FLOWER_POT");
      } else {
         String flattened = null;
         if (name.startsWith("WALL_")) {
            flattened = name.substring("WALL_".length());
         } else if (name.contains("_WALL_")) {
            flattened = name.replace("_WALL_", "_");
         }

         if (flattened != null) {
            Material base = Material.matchMaterial(flattened);
            if (base != null && base.isItem()) {
               return base;
            }
         }

         return block.isItem() ? block : null;
      }
   }

   public static record ItemCost(Material item, int count) {
   }
}
