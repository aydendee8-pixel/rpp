package com.rppbot.plugin.mocap;

import org.bukkit.Material;
import org.bukkit.block.BlockState;
import org.bukkit.block.data.BlockData;

public record MocapBlockChange(int frame, BlockState before, BlockData after, Material item) {
   public MocapBlockChange withFrame(int newFrame) {
      return new MocapBlockChange(newFrame, this.before, this.after, this.item);
   }

   public void revert() {
      this.before.update(true, false);
   }

   public void apply() {
      this.before.getBlock().setBlockData(this.after, false);
   }
}
