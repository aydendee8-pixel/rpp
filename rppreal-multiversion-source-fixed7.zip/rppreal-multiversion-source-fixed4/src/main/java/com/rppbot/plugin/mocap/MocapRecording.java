package com.rppbot.plugin.mocap;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

public final class MocapRecording {
   private final UUID worldId;
   private final List<MocapFrame> frames;
   private final List<MocapBlockChange> changes;
   private final List<MocapAction> actions;
   private final Map<Material, Integer> requiredItems = new EnumMap(Material.class);
   private List<Location> changeSpots;

   public MocapRecording(UUID worldId, List<MocapFrame> frames, List<MocapBlockChange> changes, List<MocapAction> actions) {
      this.worldId = worldId;
      this.frames = List.copyOf(frames);
      this.changes = List.copyOf(changes);
      this.actions = List.copyOf(actions);

      for(MocapBlockChange change : this.changes) {
         Material item = change.item();
         if (item != null && !item.isAir() && item.isItem()) {
            this.requiredItems.merge(item, 1, Integer::sum);
         }
      }

   }

   public UUID worldId() {
      return this.worldId;
   }

   public World world() {
      return Bukkit.getWorld(this.worldId);
   }

   public int size() {
      return this.frames.size();
   }

   public MocapFrame frame(int index) {
      return (MocapFrame)this.frames.get(index);
   }

   public List<MocapBlockChange> changes() {
      return this.changes;
   }

   public List<MocapAction> actions() {
      return this.actions;
   }

   public Map<Material, Integer> requiredItems() {
      return this.requiredItems;
   }

   public List<Location> changeSpots(int max) {
      if (this.changeSpots == null) {
         List<Location> unique = new ArrayList();
         Set<Long> seen = new HashSet();

         for(MocapBlockChange change : this.changes) {
            Location loc = change.before().getLocation();
            long key = (long)loc.getBlockX() * 73856093L ^ (long)loc.getBlockY() * 19349663L ^ (long)loc.getBlockZ() * 83492791L;
            if (seen.add(key)) {
               unique.add(loc);
            }
         }

         List<Location> sampled = new ArrayList();
         if (unique.size() <= max) {
            sampled.addAll(unique);
         } else {
            for(int i = 0; i < max; ++i) {
               sampled.add((Location)unique.get((int)((long)i * (long)unique.size() / (long)max)));
            }
         }

         this.changeSpots = sampled;
      }

      return this.changeSpots;
   }

   public Location startLocation() {
      World world = this.world();
      if (world != null && !this.frames.isEmpty()) {
         MocapFrame first = (MocapFrame)this.frames.get(0);
         return new Location(world, first.x(), first.y(), first.z(), first.yaw(), first.pitch());
      } else {
         return null;
      }
   }

   public double seconds() {
      return (double)this.frames.size() / (double)20.0F;
   }
}
