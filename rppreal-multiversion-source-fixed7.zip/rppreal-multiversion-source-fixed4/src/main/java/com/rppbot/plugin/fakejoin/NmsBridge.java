package com.rppbot.plugin.fakejoin;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Player;

final class NmsBridge {
   private static final Logger LOG = Bukkit.getLogger();

   private NmsBridge() {
   }

   static Class<?> craftClass(String suffix) throws ClassNotFoundException {
      try {
         return Class.forName("org.bukkit.craftbukkit." + suffix);
      } catch (ClassNotFoundException var4) {
         String serverPackage = Bukkit.getServer().getClass().getPackage().getName();
         String[] parts = serverPackage.split("\\.");
         if (parts.length >= 4) {
            return Class.forName("org.bukkit.craftbukkit." + parts[3] + "." + suffix);
         } else {
            throw new ClassNotFoundException("Cannot resolve CraftBukkit class: " + suffix);
         }
      }
   }

   static Object minecraftServer() throws ReflectiveOperationException {
      Class<?> craftServer = craftClass("CraftServer");
      Method getServer = craftServer.getMethod("getServer");
      return getServer.invoke(craftServer.cast(Bukkit.getServer()));
   }

   static Object serverLevel(World world) throws ReflectiveOperationException {
      Class<?> craftWorld = craftClass("CraftWorld");
      Method getHandle = craftWorld.getMethod("getHandle");
      return getHandle.invoke(craftWorld.cast(world));
   }

   static Object serverPlayerHandle(Player player) throws ReflectiveOperationException {
      Class<?> craftPlayer = craftClass("entity.CraftPlayer");
      Method getHandle = craftPlayer.getMethod("getHandle");
      return getHandle.invoke(craftPlayer.cast(player));
   }

   static Object playerList() throws ReflectiveOperationException {
      Object server = minecraftServer();
      Method getPlayerList = findMethod(server.getClass(), "getPlayerList");
      return getPlayerList.invoke(server);
   }

   static Method findMethod(Class<?> type, String name, Class<?>... paramTypes) throws NoSuchMethodException {
      for(Class<?> c = type; c != null; c = c.getSuperclass()) {
         try {
            Method m = c.getDeclaredMethod(name, paramTypes);
            m.setAccessible(true);
            return m;
         } catch (NoSuchMethodException ignored) {
            // Continue searching parent classes.
         }
      }

      String var10002 = type.getName();
      throw new NoSuchMethodException(var10002 + "#" + name);
   }

   static Method findMethodAnyName(Class<?> type, String... candidateNames) throws NoSuchMethodException {
      for(String name : candidateNames) {
         try {
            return findMethod(type, name);
         } catch (NoSuchMethodException var7) {
         }
      }

      String var10002 = type.getName();
      throw new NoSuchMethodException(var10002 + " has none of: " + String.join(", ", candidateNames));
   }

   static Constructor<?> findConstructorByArity(Class<?> type, int arity) throws NoSuchMethodException {
      for(Constructor<?> ctor : type.getDeclaredConstructors()) {
         if (ctor.getParameterCount() == arity) {
            ctor.setAccessible(true);
            return ctor;
         }
      }

      String var10002 = type.getName();
      throw new NoSuchMethodException(var10002 + " has no constructor with " + arity + " parameters");
   }

   static Field findField(Class<?> type, String name) throws NoSuchFieldException {
      for(Class<?> c = type; c != null; c = c.getSuperclass()) {
         try {
            Field f = c.getDeclaredField(name);
            f.setAccessible(true);
            return f;
         } catch (NoSuchFieldException ignored) {
            // Continue searching parent classes.
         }
      }

      String var10002 = type.getName();
      throw new NoSuchFieldException(var10002 + "#" + name);
   }

   static void warn(String message, Throwable t) {
      LOG.warning("[rpp fakejoin] " + message + (t != null ? " (" + String.valueOf(t) + ")" : ""));
   }

   static UUID offlineUuidFor(String name) {
      return UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
   }
}
