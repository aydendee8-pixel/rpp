package com.rppbot.plugin;

import com.destroystokyo.paper.profile.PlayerProfile;
import com.rppbot.plugin.fakejoin.FakeJoinManager;
import com.rppbot.plugin.fakejoin.TabListPresence;
import com.rppbot.plugin.mocap.MocapAction;
import com.rppbot.plugin.mocap.MocapBlockChange;
import com.rppbot.plugin.mocap.MocapFrame;
import com.rppbot.plugin.mocap.MocapPlayback;
import com.rppbot.plugin.mocap.MocapRecorder;
import com.rppbot.plugin.mocap.MocapRecording;
import com.rppbot.plugin.motion.WasdKeys;
import com.rppbot.plugin.motion.WasdMotor;
import com.rppbot.plugin.schematic.BlockCost;
import com.rppbot.plugin.schematic.BuildJob;
import com.rppbot.plugin.schematic.LoadedSchematic;
import com.rppbot.plugin.schematic.Schematic;
import com.rppbot.plugin.schematic.SchematicLoader;
import io.papermc.paper.datacomponent.item.ResolvableProfile;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.logging.Logger;
import java.util.stream.Stream;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.block.data.Bisected;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Openable;
import org.bukkit.block.data.Waterlogged;
import org.bukkit.block.data.Bisected.Half;
import org.bukkit.block.data.type.Door;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.ExperienceOrb;
import org.bukkit.entity.Firework;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mannequin;
import org.bukkit.entity.Player;
import org.bukkit.entity.Pose;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.ThrowableProjectile;
import org.bukkit.entity.ThrownPotion;
import org.bukkit.entity.AbstractArrow.PickupStatus;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.Event.Result;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockMultiPlaceEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.PotionSplashEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

public class RppCommand implements CommandExecutor, TabCompleter, Listener {
   private final Plugin plugin;
   private final FakeJoinManager fakeJoinManager;
   private final TabListPresence tabPresence;
   private final File settingsFile;
   private final File waypointsFile;
   private final File mannequinsFile;
   private final File presetsDir;
   private final File schematicsDir;
   private final Map<String, LoadedSchematic> loadedSchematics = new HashMap();
   private final Map<String, BuildJob> activeJobs = new HashMap();
   private final Map<UUID, MannequinRecord> pendingMannequinRestores = new HashMap();
   private static String MANNEQUIN_LABEL = "Squad";
   private static final String BOT_NAME_PREFIX = "RaccoonBot";
   private int nextBotNumber = 1;
   private static final List<String> RANDOM_NAME_POOL = List.of("Boulder", "Ashvale", "Nimbus", "Pixelwood", "Ferrix", "Duskwalker", "Embergaze", "Ironhollow", "Frostbyte", "Willowmere", "Skyshard", "Thistledown", "Grimshade", "Copperfen", "Basalt", "Novaleaf", "Cinderfox", "Palewick", "Voxel", "Marrowick", "Glimmerpeak", "Stonehatch", "Runeforge", "Hollowpine", "Amberlynx", "Driftwood", "Cragmoor", "Vespertine", "Quartzling", "Mossgrove", "Sablewing", "Tallowmere", "Brackenrun", "Vantablock", "Ridgewalker", "Emberlynx", "Pinehollow", "Wrenfield", "Cobaltmoss", "Slatepeak");
   private static final List<String> SUBCOMMANDS = List.of("spawn", "follow", "stop", "sneak", "stand", "remove", "attack", "roam", "settings", "waypoint", "patrol", "rename", "list", "jump", "save", "load", "formation", "build", "schem", "mocap", "giveall", "setskin");
   private static final Set<String> BOT_TARGETABLE_SUBCOMMANDS = Set.of("follow", "stop", "sneak", "stand", "remove", "attack", "roam", "patrol", "jump", "formation", "build", "giveall");
   private static final List<String> WAYPOINT_ACTIONS = List.of("create", "delete", "addpoint", "removepoint", "connect", "disconnect", "list", "rename");
   private static final double PLAYER_WALK_SPEED = 0.2158; // vanilla walk: 4.317 blocks/s
   private static final double SPRINT_SPEED = 0.2806; // vanilla sprint: 5.612 blocks/s
   private static final double JUMP_VELOCITY = 0.42;
   private static final double OBSTACLE_CHECK_DISTANCE = 0.6;
   private static final double STOP_DISTANCE = (double)2.0F;
   private static final double FORMATION_SPACING = (double)2.25F;
   private static final double FORMATION_FRONT_GAP = (double)3.0F;
   private static final double FORMATION_STOP_DISTANCE = (double)1.0F;
   private static final double WAYPOINT_REACHED_DISTANCE = 0.6;
   private static final double STEERING_LOOKAHEAD_DISTANCE = (double)2.75F;
   private static final double HUMAN_ACCEL_GROUND = 0.24;
   private static final double HUMAN_ACCEL_AIR = 0.08;
   private static final double HUMAN_BRAKE = 0.34;
   private static final double HUMAN_MIN_CONTROL_SPEED = 0.035;
   private static final float HUMAN_TURN_SLOW = 7.0F;
   private static final float HUMAN_TURN_NORMAL = 14.0F;
   private static final float HUMAN_TURN_FAST = 28.0F;
   private static final long HUMAN_MICRO_CORRECTION_TICKS = 7L;
   private static final double HUMAN_MICRO_CORRECTION = 0.035;
   private static final long HUMAN_BUILD_MIN_PLACE_TICKS = 4L;
   private static final long HUMAN_BUILD_MAX_PLACE_TICKS = 7L;
   private static final long HUMAN_BUILD_STUCK_TICKS = 180L;
   private static final double CATCHUP_DISTANCE_THRESHOLD = (double)10.0F;
   private static final double CATCHUP_RAMP_DISTANCE = (double)20.0F;
   private static final double CATCHUP_MAX_MULTIPLIER = 1.35;
   private static final double SNEAK_SPEED_MULTIPLIER = 0.3;
   private static final double SWIM_SPEED_MULTIPLIER = 0.3;
   private static final double FLOAT_RISE_SPEED = 0.04;
   private static final double MOVE_FRICTION = 0.78;
   private static final double MOVE_ACCELERATION = 0.21999999999999997;
   private static final float TURN_RATE_DEGREES = 22.0F;
   private static final float COMBAT_TURN_RATE_DEGREES = 38.0F;
   private static final double LOOK_AT_RANGE = (double)12.0F;
   private static final long LOOK_AT_SCAN_INTERVAL_TICKS = 4L;
   private static final double LOOK_AT_MAX_ANGLE_DEGREES = (double)10.0F;
   private static final float LOOK_AT_TURN_RATE_DEGREES = 25.0F;
   private static final double MAX_PATH_DISTANCE = (double)32.0F;
   private static final int MAX_SEARCH_NODES = 3000;
   private static final long PATH_RECOMPUTE_INTERVAL_TICKS = 12L;
   private static final long PATH_RECOMPUTE_STAGGER_TICKS = 20L;
   private static final double TARGET_JUMP_RECOMPUTE_DISTANCE = (double)8.0F;
   private static final int MAX_FALL_DISTANCE = 3;
   private static final double DROP_MOVE_COST_PER_BLOCK = 0.15;
   private static final double WATER_STEP_PENALTY = (double)4.0F;
   private static final double LAVA_ADJACENCY_PENALTY = (double)4.0F;
   private static final double LEAVES_UNDERFOOT_PENALTY = (double)2.0F;
   private static final double CLOSED_DOOR_PENALTY = (double)0.5F;
   private static final int[][] CARDINAL_OFFSETS = new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
   private static final double RANDOM_JUMP_CHANCE = 0.015;
   private static final long JUMP_SYNCED_INTERVAL_TICKS = 20L;
   private static final long JUMP_RANDOM_MIN_TICKS = 12L;
   private static final long JUMP_RANDOM_MAX_TICKS = 45L;
   private static final double WAYPOINT_NODE_REACHED_DISTANCE = (double)1.25F;
   private static final Material AUTO_REFILL_FOOD;
   private static final int AUTO_REFILL_AMOUNT = 8;
   private static final double DEFAULT_ROAM_RADIUS = (double)20.0F;
   private static final double MAX_ROAM_RADIUS = (double)200.0F;
   private static final long ROAM_MIN_PAUSE_TICKS = 40L;
   private static final long ROAM_MAX_PAUSE_TICKS = 140L;
   private static final int[][] HORIZONTAL_OFFSETS;
   private static final int[][] JUMP_OFFSETS;
   private static final double JUMP_MOVE_COST = 1.8;
   private static final double GOLDEN_APPLE_HEAL_TRIGGER_HEALTH = (double)14.0F;
   private static final int GOLDEN_APPLE_REGEN_AMPLIFIER = 1;
   private static final int GOLDEN_APPLE_REGEN_DURATION_TICKS = 100;
   private static final int GOLDEN_APPLE_ABSORPTION_AMPLIFIER = 0;
   private static final int GOLDEN_APPLE_ABSORPTION_DURATION_TICKS = 2400;
   private static final int NOTCH_APPLE_REGEN_AMPLIFIER = 3;
   private static final int NOTCH_APPLE_REGEN_DURATION_TICKS = 400;
   private static final int NOTCH_APPLE_ABSORPTION_AMPLIFIER = 3;
   private static final int NOTCH_APPLE_ABSORPTION_DURATION_TICKS = 2400;
   private static final int NOTCH_APPLE_RESISTANCE_DURATION_TICKS = 6000;
   private static final String BREEDING_BABY_NAME = "BehBeh Fpp";
   private static final String BREEDING_BABY_SKIN = "MNIK_13";
   private static final double BREEDING_BABY_SCALE = 0.55;
   private static final long LOVE_MODE_DURATION_TICKS = 600L;
   private static final long BABY_GROWTH_TICKS = 200L;
   private static final double BREEDING_MEET_DISTANCE = 1.3;
   private static final long BREEDING_COURTSHIP_TICKS = 80L;
   private static final double BREEDING_DEATH_CHANCE = (double)0.5F;
   private static final double BREEDING_WALK_MIN_SPEED = 0.08;
   private static final double BREEDING_WALK_MAX_SPEED = (double)0.75F;
   private static final long BREEDING_CROUCH_INTERVAL_TICKS = 2L;
   private static final double PEARL_ESCAPE_HEALTH = (double)10.0F;
   private static final double PEARL_ESCAPE_DISTANCE = (double)10.0F;
   private static final long PEARL_ESCAPE_COOLDOWN_TICKS = 200L;
   private static final double ATTACK_RANGE = (double)3.0F;
   private static final double UNARMED_DAMAGE = (double)1.0F;
   private static final long ATTACK_COOLDOWN_TICKS = 15L;
   private static final double BOT_MAX_HEALTH = (double)40.0F;
   private static final double BOT_KNOCKBACK_RESISTANCE = 0.4;
   private static final double BOT_SEPARATION_DISTANCE = 0.7;
   private static final double BOT_SEPARATION_STRENGTH = 0.06;
   private static final double STRAFE_SPEED = 0.16;
   private static final long STRAFE_INTERVAL_MIN_TICKS = 6L;
   private static final long STRAFE_INTERVAL_MAX_TICKS = 26L;
   private static final double DODGE_HOP_CHANCE = 0.03;
   private static final double COMBAT_RETREAT_HEALTH_FRACTION = (double)0.25F;
   private static final double RETREAT_SPEED = 0.2;
   private static final double RETREAT_WOBBLE = 0.35;
   private static final double CRITICAL_HIT_MULTIPLIER = (double)1.5F;
   private static final double SHIELD_BLOCK_CHANCE = 0.35;
   private static final double SHIELD_BLOCK_DAMAGE_MULTIPLIER = 0.3;
   private static final double KNOCKBACK_BASE_STRENGTH = 0.4;
   private static final double KNOCKBACK_SPRINT_MULTIPLIER = (double)2.0F;
   private static final double KNOCKBACK_MAX_HORIZONTAL_SPEED = 0.9;
   private static final long KNOCKBACK_LOCK_TICKS = 6L;
   private static final String[] TOOL_TIERS;
   private static final Map<String, Double> TIER_DAMAGE_BONUS;
   private static final Map<String, Double> AXE_DAMAGE_BONUS;
   private static final double SHARPNESS_BONUS_PER_LEVEL = (double)0.5F;
   private static final double SHARPNESS_FLAT_BONUS = (double)0.5F;
   private static final int GUI_SIZE = 54;
   private static final int SLOT_MAIN_HAND = 0;
   private static final int SLOT_OFFHAND = 1;
   private static final int SLOT_HELMET = 3;
   private static final int SLOT_CHESTPLATE = 4;
   private static final int SLOT_LEGGINGS = 5;
   private static final int SLOT_BOOTS = 6;
   private static final int STORAGE_START = 9;
   private static final int STORAGE_SIZE = 45;
   private static final Set<Integer> HEADER_EDITABLE_SLOTS;
   private boolean autoPvpEnabled = true;
   private boolean randomHopEnabled = true;
   private boolean alwaysSprintEnabled = true;
   private boolean debugPathEnabled = false;
   private boolean autoEatEnabled = true;
   private boolean autoRefillEnabled = true;
   private boolean autoHealEnabled = true;
   private boolean autoPearlEnabled = true;
   private boolean autoPickupEnabled = true;
   private boolean mocapHarmEnabled = false;
   private NamespacedKey mocapShotKey;
   private static final double MAX_HUNGER = (double)20.0F;
   private static final double HUNGER_DECAY_PER_TICK = 0.0033333333333333335;
   private static final double EAT_THRESHOLD = (double)6.0F;
   private static final long EAT_DURATION_TICKS = 32L;
   private static final double GENERIC_FOOD_RESTORE = (double)3.0F;
   private static final Map<Material, Double> FOOD_RESTORE_AMOUNTS;
   private final Map<UUID, Companion> companions = new HashMap();
   private boolean tickerStarted = false;
   private long tickCounter = 0L;
   private final Map<String, WaypointNetwork> waypointNetworks = new HashMap();
   private static final int SETTINGS_GUI_SIZE = 27;
   private static final int SETTINGS_SLOT_HEADER = 4;
   private static final int SETTINGS_SLOT_AUTO_EAT = 9;
   private static final int SETTINGS_SLOT_AUTO_PVP = 10;
   private static final int SETTINGS_SLOT_RANDOM_HOP = 11;
   private static final int SETTINGS_SLOT_SPRINT = 12;
   private static final int SETTINGS_SLOT_DEBUG_PATH = 13;
   private static final int SETTINGS_SLOT_AUTO_REFILL = 14;
   private static final int SETTINGS_SLOT_AUTO_HEAL = 15;
   private static final int SETTINGS_SLOT_AUTO_PEARL = 16;
   private static final int SETTINGS_SLOT_AUTO_PICKUP = 17;
   private static final long AUTOSAVE_INTERVAL_TICKS = 6000L;
   private static final double PICKUP_RADIUS = (double)1.5F;
   private static final int SPRINTING_SHARED_FLAG_INDEX = 3;
   private static volatile Method setSharedFlagMethod;
   private static volatile boolean setSharedFlagResolutionFailed;
   private static final List<String> SCHEM_ACTIONS = List.of("load", "remove", "center", "rotate");
   private static final List<String> ROTATE_AMOUNTS = List.of("90", "180", "270");
   private static final int BUILD_CLAIM = 1;
   private static final int BUILD_PLAN = 2;
   private static final int BUILD_TO_CHEST = 3;
   private static final int BUILD_AT_CHEST = 4;
   private static final int BUILD_PLACING = 5;
   private static final int BUILD_BATCH_SIZE = 256;
   private static final long BUILD_CHEST_WAIT_TICKS = 40L;
   private static final long BUILD_PLACE_INTERVAL_TICKS = 4L;
   private static final long BUILD_CHEST_WALK_TIMEOUT_TICKS = 600L;
   private static final long BUILD_STUCK_TICKS = 100L;
   private static final double BUILD_REACH = (double)4.5F;
   private static final double CHEST_REACH = 3.2;
   private static final int CHEST_SEARCH_CHUNK_RADIUS = 3;
   private static final double MOCAP_WATCH_RANGE = (double)96.0F;
   private static final double MOCAP_WATCH_HALF_FOV_DEGREES = (double)65.0F;
   private static final long MOCAP_WATCH_SCAN_INTERVAL_TICKS = 3L;
   private final Map<UUID, MocapRecorder> mocapRecorders = new HashMap();
   private static final Map<EntityType, String> MOCAP_LAUNCH_SOUNDS;

   public RppCommand(Plugin plugin) {
      this.plugin = plugin;
      this.mocapShotKey = new NamespacedKey(plugin, "mocap_shot");
      this.fakeJoinManager = new FakeJoinManager(plugin);
      this.tabPresence = new TabListPresence(plugin);
      File dataFolder = plugin.getDataFolder();
      if (!dataFolder.exists()) {
         dataFolder.mkdirs();
      }

      this.settingsFile = new File(dataFolder, "settings.yml");
      this.waypointsFile = new File(dataFolder, "waypoints.yml");
      this.mannequinsFile = new File(dataFolder, "mannequins.yml");
      this.presetsDir = new File(dataFolder, "presets");
      if (!this.presetsDir.exists()) {
         this.presetsDir.mkdirs();
      }

      this.schematicsDir = new File(dataFolder, "schematics");
      if (!this.schematicsDir.exists()) {
         this.schematicsDir.mkdirs();
      }

      this.loadSettings();
      this.loadWaypoints();
      this.pendingMannequinRestores.putAll(this.loadMannequinRecords());
      this.attemptPendingMannequinRestores();
   }

   public void shutdown() {
      for(MocapRecorder recorder : this.mocapRecorders.values()) {
         recorder.revertAll();
      }

      this.mocapRecorders.clear();

      for(LoadedSchematic loaded : this.loadedSchematics.values()) {
         loaded.ghost.clear();
      }

      this.despawnAllCompanions();
      this.saveAll();
      this.fakeJoinManager.leaveAll();
      this.tabPresence.removeAll();
   }

   private void despawnAllCompanions() {
      for(Companion c : new ArrayList<Companion>(this.companions.values())) {
         c.releaseBuild();
         this.fakeJoinManager.leave(c.entity.getUniqueId());
         if (c.tabId != null) {
            this.tabPresence.remove(c.tabId);
         }

         if (c.entity.isValid()) {
            c.entity.remove();
         }
      }

      this.companions.clear();
      this.pendingMannequinRestores.clear();
   }

   private String allocateBotName() {
      ThreadLocalRandom random = ThreadLocalRandom.current();
      List<String> shuffled = new ArrayList(RANDOM_NAME_POOL);
      Collections.shuffle(shuffled, random);

      for(String candidate : shuffled) {
         if (this.isBotNameFree(candidate)) {
            return candidate;
         }
      }

      for(int attempt = 0; attempt < 50; ++attempt) {
         String base = (String)RANDOM_NAME_POOL.get(random.nextInt(RANDOM_NAME_POOL.size()));
         String candidate = base + random.nextInt(10, 999);
         if (candidate.length() > 16) {
            candidate = candidate.substring(0, 16);
         }

         if (this.isBotNameFree(candidate)) {
            return candidate;
         }
      }

      String name = "RaccoonBot" + this.nextBotNumber;
      ++this.nextBotNumber;
      return name;
   }

   private boolean isBotNameFree(String candidate) {
      for(Companion c : this.companions.values()) {
         if (c.botName != null && c.botName.equalsIgnoreCase(candidate)) {
            return false;
         }
      }

      for(Player p : Bukkit.getOnlinePlayers()) {
         if (p.getName().equalsIgnoreCase(candidate)) {
            return false;
         }
      }

      return true;
   }

   /** Number of RPP-controlled bots currently active. */
   public int getActiveBotCount() {
      return this.companions.size();
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onPlayerJoinNotice(PlayerJoinEvent event) {
      Player player = event.getPlayer();
      if (player.isOp()) {
         return;
      }
      // One action-bar notice on join. The vanilla client fades action-bar text naturally.
      Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
         if (player.isOnline() && !player.isOp()) {
            Component notice = Component.text("This Server Is Running A Fake Player Plugin Bots Active: " + this.companions.size(), NamedTextColor.YELLOW);
            player.sendActionBar(notice);
         }
      }, 1L);
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (sender instanceof Player commandPlayer && !commandPlayer.isOp() && !commandPlayer.getName().equalsIgnoreCase("MrRacgoon")) {
         commandPlayer.sendMessage(Component.text("You don't have permission to use RPP.").color(NamedTextColor.RED));
         return true;
      }
      if (sender instanceof Player player) {
         if (args.length == 0) {
            player.sendMessage(Component.text("Usage: /rpp <spawn [amount]|follow|stop|sneak|stand|remove|attack <player|@a>|roam [radius]|patrol <waypoint> [--random]|waypoint <create|delete|addpoint|removepoint|connect|disconnect|list|rename>|rename <name>|list [page]|jump [--random]|settings|save <name>|load <name>|formation <follow|stop> (beta)|schem <name> <load|remove|center>|build <schematic>> [<BotName>]").color(NamedTextColor.YELLOW));
            player.sendMessage(Component.text("Gear/skins: /rpp giveall [BotName] copies your inventory + armor + offhand onto bots; /rpp setskin <@a|BotName> <PlayerName> changes their skin.").color(NamedTextColor.YELLOW));
            player.sendMessage(Component.text("Mocap: /rpp mocap start, then move/swing/do whatever, then /rpp mocap stop (spawns a bot that loops it) or /rpp mocap cancel.").color(NamedTextColor.YELLOW));
            player.sendMessage(Component.text("Schematics: put .schem/.litematic files in plugins/RppBot/schematics, then /rpp schem <name> <load|remove|center> and /rpp build <name>.").color(NamedTextColor.YELLOW));
            player.sendMessage(Component.text("Add a bot's name (e.g. RaccoonBot3) to any of those to target just that bot instead of the whole squad.").color(NamedTextColor.YELLOW));
            return true;
         } else {
            switch (args[0].toLowerCase()) {
               case "spawn":
                  this.spawnMannequins(player, args);
                  break;
               case "follow":
                  this.startFollowing(player, args);
                  break;
               case "stop":
                  this.stopAll(player, args);
                  break;
               case "sneak":
                  this.setSneaking(player, true, args);
                  break;
               case "stand":
                  this.setSneaking(player, false, args);
                  break;
               case "remove":
                  this.removeAll(player, args);
                  break;
               case "attack":
                  this.startAttacking(player, args);
                  break;
               case "roam":
                  this.startRoaming(player, args);
                  break;
               case "settings":
                  this.openSettingsGui(player);
                  break;
               case "waypoint":
                  this.handleWaypointCommand(player, args);
                  break;
               case "patrol":
                  this.startPatrolling(player, args);
                  break;
               case "rename":
                  this.renameSquad(player, args);
                  break;
               case "list":
                  this.listMannequins(player, args);
                  break;
               case "jump":
                  this.startJumping(player, args);
                  break;
               case "save":
                  this.saveSquadPreset(player, args);
                  break;
               case "load":
                  this.loadSquadPreset(player, args);
                  break;
               case "formation":
                  this.handleFormation(player, args);
                  break;
               case "build":
                  this.startBuild(player, args);
                  break;
               case "schem":
                  this.handleSchemSubcommand(player, args);
                  break;
               case "mocap":
                  this.handleMocapCommand(player, args);
                  break;
               case "giveall":
                  this.giveAll(player, args);
                  break;
               case "setskin":
                  this.setSkin(player, args);
                  break;
               default:
                  if (!this.handleSchematicCommand(player, args)) {
                     player.sendMessage(Component.text("Unknown option. Use spawn, follow, stop, sneak, stand, remove, attack, roam, patrol, waypoint, rename, list, jump, save, load, formation, build, schem, mocap, giveall, setskin, or settings").color(NamedTextColor.RED));
                  }
            }

            return true;
         }
      } else {
         sender.sendMessage(Component.text("Only players can use this").color(NamedTextColor.RED));
         return true;
      }
   }

   private void spawnMannequins(Player player, String[] args) {
      int amount = 1;
      if (args.length >= 2) {
         try {
            amount = Integer.parseInt(args[1]);
         } catch (NumberFormatException var51) {
            player.sendMessage(Component.text("Amount must be a whole number.").color(NamedTextColor.RED));
            return;
         }

         if (amount < 1) {
            player.sendMessage(Component.text("Amount must be at least 1.").color(NamedTextColor.RED));
            return;
         }
      }

      List<Companion> spawned = this.spawnSquad(player, amount);
      if (spawned.isEmpty()) {
         player.sendMessage(Component.text("Failed to spawn any mannequins.").color(NamedTextColor.RED));
      }

   }

   private List<Companion> spawnSquad(Player player, int amount) {
      return this.spawnSquad(player, amount, (Location)null);
   }

   private List<Companion> spawnSquad(Player player, int amount, Location origin) {
      this.purgeDeadCompanions();
      List<Mannequin> spawned = new ArrayList();
      List<Companion> spawnedCompanions = new ArrayList();

      for(int i = 0; i < amount; ++i) {
         Location loc = origin != null && i == 0 ? origin.clone() : this.spawnLocationFor(player, i);
         Entity entity = loc.getWorld().spawnEntity(loc, EntityType.MANNEQUIN);
         if (entity instanceof Mannequin spawned0) {
            spawned0.setImmovable(false);
            String botName = this.allocateBotName();
            spawned0.customName(Component.text(botName));
            spawned0.setCustomNameVisible(true);
            spawned0.setDescription((Component)null);
            spawned0.setCollidable(false);
            AttributeInstance maxHealthAttr = spawned0.getAttribute(Attribute.MAX_HEALTH);
            if (maxHealthAttr != null) {
               maxHealthAttr.setBaseValue((double)40.0F);
            }

            spawned0.setHealth((double)40.0F);
            AttributeInstance knockbackAttr = spawned0.getAttribute(Attribute.KNOCKBACK_RESISTANCE);
            if (knockbackAttr != null) {
               knockbackAttr.setBaseValue(0.4);
            }

            Companion companion = new Companion(spawned0, botName);
            this.companions.put(spawned0.getUniqueId(), companion);
            spawned.add(spawned0);
            spawnedCompanions.add(companion);
         }
      }

      if (spawned.isEmpty()) {
         return spawnedCompanions;
      } else {
         for(Companion c : spawnedCompanions) {
            c.tabId = this.applySkin(c.entity, c.botName, player);
            this.tabPresence.add(c.tabId, c.botName);
            Bukkit.broadcast(Component.text(c.botName + " joined the game").color(NamedTextColor.YELLOW));
         }

         this.ensureTicker();
         return spawnedCompanions;
      }
   }

   private void saveSquadPreset(Player player, String[] args) {
      if (this.hasMannequins(player)) {
         if (args.length < 2) {
            player.sendMessage(Component.text("Usage: /rpp save <name>").color(NamedTextColor.YELLOW));
         } else {
            String presetName = args[1];
            File file = this.presetFile(presetName);
            if (file == null) {
               player.sendMessage(Component.text("That preset name isn't valid - use letters, numbers, - or _.").color(NamedTextColor.RED));
            } else {
               List<Companion> squad = new ArrayList(this.companions.values());
               YamlConfiguration yaml = new YamlConfiguration();
               yaml.set("bot-count", squad.size());
               ConfigurationSection botsSection = yaml.createSection("bots");

               for(int i = 0; i < squad.size(); ++i) {
                  Companion c = (Companion)squad.get(i);
                  ConfigurationSection s = botsSection.createSection(String.valueOf(i));
                  EntityEquipment equipment = c.entity.getEquipment();
                  if (equipment != null) {
                     ConfigurationSection eq = s.createSection("equipment");
                     eq.set("mainhand", equipment.getItemInMainHand());
                     eq.set("offhand", equipment.getItemInOffHand());
                     eq.set("helmet", equipment.getHelmet());
                     eq.set("chestplate", equipment.getChestplate());
                     eq.set("leggings", equipment.getLeggings());
                     eq.set("boots", equipment.getBoots());
                  }

                  s.set("storage", new ArrayList(Arrays.asList(c.storageContents)));
               }

               try {
                  yaml.save(file);
               } catch (IOException e) {
                  Bukkit.getLogger().severe("[RppCommand] Failed to save preset '" + presetName + "': " + e.getMessage());
                  player.sendMessage(Component.text("Failed to save preset.").color(NamedTextColor.RED));
                  return;
               }

               int var10001 = squad.size();
               player.sendMessage(Component.text("Saved current squad (" + var10001 + " bot" + (squad.size() == 1 ? "" : "s") + ") as preset \"" + presetName + "\".").color(NamedTextColor.GREEN));
            }
         }
      }

   }

   private void loadSquadPreset(Player player, String[] args) {
      if (args.length < 2) {
         player.sendMessage(Component.text("Usage: /rpp load <name>").color(NamedTextColor.YELLOW));
      } else {
         String presetName = args[1];
         File file = this.presetFile(presetName);
         if (file != null && file.exists()) {
            YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
            ConfigurationSection botsSection = yaml.getConfigurationSection("bots");
            int botCount = yaml.getInt("bot-count", botsSection != null ? botsSection.getKeys(false).size() : 0);
            if (botCount < 1) {
               player.sendMessage(Component.text("Preset \"" + presetName + "\" doesn't have any bots saved.").color(NamedTextColor.RED));
            } else {
               List<Companion> spawned = this.spawnSquad(player, botCount);
               if (spawned.isEmpty()) {
                  player.sendMessage(Component.text("Failed to spawn any mannequins.").color(NamedTextColor.RED));
               } else {
                  if (botsSection != null) {
                     for(int i = 0; i < spawned.size(); ++i) {
                        ConfigurationSection s = botsSection.getConfigurationSection(String.valueOf(i));
                        if (s != null) {
                           Companion c = (Companion)spawned.get(i);
                           ConfigurationSection eq = s.getConfigurationSection("equipment");
                           EntityEquipment equipment = c.entity.getEquipment();
                           if (eq != null && equipment != null) {
                              equipment.setItemInMainHand(this.getItemStack(eq, "mainhand"));
                              equipment.setItemInOffHand(this.getItemStack(eq, "offhand"));
                              equipment.setHelmet(this.getItemStack(eq, "helmet"));
                              equipment.setChestplate(this.getItemStack(eq, "chestplate"));
                              equipment.setLeggings(this.getItemStack(eq, "leggings"));
                              equipment.setBoots(this.getItemStack(eq, "boots"));
                           }

                           List<?> rawStorage = s.getList("storage");
                           if (rawStorage != null) {
                              for(int slot = 0; slot < Math.min(45, rawStorage.size()); ++slot) {
                                 Object var17 = rawStorage.get(slot);
                                 if (var17 instanceof ItemStack) {
                                    ItemStack item = (ItemStack)var17;
                                    c.storageContents[slot] = item;
                                 }
                              }
                           }
                        }
                     }
                  }

                  player.sendMessage(Component.text("Loaded preset \"" + presetName + "\" (" + spawned.size() + " bot" + (spawned.size() == 1 ? "" : "s") + ").").color(NamedTextColor.GREEN));
               }
            }
         } else {
            player.sendMessage(Component.text("No preset named \"" + presetName + "\" was found.").color(NamedTextColor.RED));
         }
      }

   }

   private ItemStack getItemStack(ConfigurationSection section, String key) {
      Object raw = section.get(key);
      ItemStack var10000;
      if (raw instanceof ItemStack item) {
         var10000 = item;
      } else {
         var10000 = null;
      }

      return var10000;
   }

   private File presetFile(String presetName) {
      return presetName != null && presetName.matches("[A-Za-z0-9_-]+") ? new File(this.presetsDir, presetName + ".yml") : null;
   }

   private List<String> listPresetNames() {
      File[] files = this.presetsDir.listFiles((dir, namex) -> namex.endsWith(".yml"));
      if (files == null) {
         return List.of();
      } else {
         List<String> names = new ArrayList();

         for(File f : files) {
            String name = f.getName();
            names.add(name.substring(0, name.length() - ".yml".length()));
         }

         return names;
      }
   }

   private Location spawnLocationFor(Player player, int index) {
      Location base = player.getLocation();
      if (index == 0) {
         return base;
      } else {
         double angle = (Math.PI / 4D) * (double)(index % 8);
         double radius = (double)1.5F + (double)(index / 8) * (double)1.0F;
         Location loc = base.clone();
         loc.setX(base.getX() + Math.cos(angle) * radius);
         loc.setZ(base.getZ() + Math.sin(angle) * radius);
         return loc;
      }
   }

   private UUID applySkin(Mannequin target, String botName, Player notify) {
      UUID tabId = UUID.randomUUID();
      PlayerProfile profile = Bukkit.createProfile(tabId, botName != null ? botName : "Bot");

      try {
         target.setProfile(ResolvableProfile.resolvableProfile(profile));
      } catch (Exception e) {
         Bukkit.getLogger().warning("[RppCommand] Failed to apply a default skin: " + e.getMessage());
         if (notify != null) {
            notify.sendMessage(Component.text("Couldn't apply a default skin to the bot.").color(NamedTextColor.RED));
         }
      }

      return tabId;
   }

   private void startFollowing(Player player, String[] args) {
      if (this.hasMannequins(player)) {
         List<Companion> targets = this.resolveTargets(args);

         for(Companion c : targets) {
            c.resetMode();
            c.following = true;
            c.moveTargetId = player.getUniqueId();
         }

         this.ensureTicker();
         String var10001 = this.describeTargets(targets);
         player.sendMessage(Component.text(var10001 + " is now finding its way to you.").color(NamedTextColor.GREEN));
      }

   }

   private void handleFormation(Player player, String[] args) {
      if (args.length >= 2 && (args[1].equalsIgnoreCase("follow") || args[1].equalsIgnoreCase("stop"))) {
         if (args[1].equalsIgnoreCase("stop")) {
            this.stopFormation(player, args);
         } else {
            this.startFormation(player, args);
         }
      } else {
         player.sendMessage(Component.text("Usage: /rpp formation <follow|stop> [<BotName>]  (beta)").color(NamedTextColor.YELLOW));
      }

   }

   private void startFormation(Player player, String[] args) {
      if (this.hasMannequins(player)) {
         List<Companion> targets = this.resolveTargets(args);
         int index = 0;

         for(Companion c : targets) {
            c.resetMode();
            c.formation = true;
            c.formationIndex = index++;
            c.moveTargetId = player.getUniqueId();
         }

         this.ensureTicker();
         String var7 = this.describeTargets(targets);
         player.sendMessage(Component.text(var7 + " is now forming up behind you. (formation is in beta - let me know if it does anything weird!)").color(NamedTextColor.GREEN));
      }

   }

   private void stopFormation(Player player, String[] args) {
      if (this.hasMannequins(player)) {
         List<Companion> targets = this.resolveTargets(args);

         for(Companion c : targets) {
            c.resetMode();
         }

         String var10001 = this.describeTargets(targets);
         player.sendMessage(Component.text(var10001 + " broke formation.").color(NamedTextColor.YELLOW));
      }

   }

   private void startAttacking(Player player, String[] args) {
      if (this.hasMannequins(player)) {
         if (args.length < 2) {
            player.sendMessage(Component.text("Usage: /rpp attack <player|@a>").color(NamedTextColor.YELLOW));
         } else if (args[1].equalsIgnoreCase("@a")) {
            this.startChaosAttack(player, args);
         } else {
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) {
               player.sendMessage(Component.text("Player \"" + args[1] + "\" isn't online.").color(NamedTextColor.RED));
            } else {
               List<Companion> targets = this.resolveTargets(args);

               for(Companion c : targets) {
                  c.resetMode();
                  c.attacking = true;
                  c.moveTargetId = target.getUniqueId();
               }

               this.ensureTicker();
               String var10001 = this.describeTargets(targets);
               player.sendMessage(Component.text(var10001 + " is now attacking " + target.getName() + ".").color(NamedTextColor.GREEN));
            }
         }
      }

   }

   private void startChaosAttack(Player player, String[] args) {
      List<Companion> targets = this.resolveTargets(args);
      List<LivingEntity> pool = new ArrayList();

      for(Companion c : this.companions.values()) {
         pool.add(c.entity);
      }

      for(Player online : Bukkit.getOnlinePlayers()) {
         pool.add(online);
      }

      if (pool.size() < 2) {
         player.sendMessage(Component.text("Not enough targets around for a free-for-all - spawn more bots or get more players online.").color(NamedTextColor.RED));
      } else {
         for(Companion c : targets) {
            LivingEntity chosen = this.pickChaosTarget(pool, c.entity);
            if (chosen != null) {
               c.resetMode();
               c.attacking = true;
               c.moveTargetId = chosen.getUniqueId();
            }
         }

         this.ensureTicker();
         String var10001 = this.describeTargets(targets);
         player.sendMessage(Component.text(var10001 + " is now in a free-for-all - everyone's got a different target, including each other.").color(NamedTextColor.GREEN));
      }

   }

   private LivingEntity pickChaosTarget(List<LivingEntity> pool, LivingEntity self) {
      List<LivingEntity> candidates = new ArrayList();

      for(LivingEntity e : pool) {
         if (!e.getUniqueId().equals(self.getUniqueId())) {
            candidates.add(e);
         }
      }

      if (candidates.isEmpty()) {
         return null;
      } else {
         return (LivingEntity)candidates.get(ThreadLocalRandom.current().nextInt(candidates.size()));
      }
   }

   private void startRoaming(Player player, String[] args) {
      if (this.hasMannequins(player)) {
         double radius = (double)20.0F;
         if (args.length >= 2) {
            try {
               radius = Double.parseDouble(args[1]);
            } catch (NumberFormatException var111) {
               player.sendMessage(Component.text("Radius must be a number.").color(NamedTextColor.RED));
               return;
            }

            if (radius < (double)1.0F) {
               player.sendMessage(Component.text("Radius must be at least 1.").color(NamedTextColor.RED));
               return;
            }
         }

         double finalRadius = Math.min(radius, (double)200.0F);
         Location center = player.getLocation();
         List<Companion> targets = this.resolveTargets(args);

         for(Companion c : targets) {
            c.resetMode();
            c.roaming = true;
            c.roamCenter = center.clone();
            c.roamRadius = finalRadius;
            c.roamPauseUntilTick = this.tickCounter;
         }

         this.ensureTicker();
         String var10001 = this.describeTargets(targets);
         player.sendMessage(Component.text(var10001 + " is now roaming within " + (int)finalRadius + " blocks.").color(NamedTextColor.GREEN));
      }

   }

   private void stopAll(Player player, String[] args) {
      if (this.hasMannequins(player)) {
         List<Companion> targets = this.resolveTargets(args);

         for(Companion c : targets) {
            c.resetMode();
         }

         String var10001 = this.describeTargets(targets);
         player.sendMessage(Component.text(var10001 + " stopped.").color(NamedTextColor.YELLOW));
      }

   }

   private void setSneaking(Player player, boolean sneak, String[] args) {
      if (this.hasMannequins(player)) {
         List<Companion> targets = this.resolveTargets(args);

         for(Companion c : targets) {
            this.setMannequinSneaking(c.entity, sneak);
         }

         String var10001 = this.describeTargets(targets);
         player.sendMessage(Component.text(var10001 + " is now " + (sneak ? "sneaking." : "standing.")).color(NamedTextColor.GREEN));
      }

   }

   private void setMannequinSneaking(Mannequin mannequin, boolean sneak) {
      mannequin.setSneaking(sneak);
      Pose targetPose = sneak ? Pose.SNEAKING : Pose.STANDING;
      if (Mannequin.validPoses().contains(targetPose)) {
         mannequin.setPose(targetPose);
      }

   }

   private void renameSquad(Player player, String[] args) {
      if (args.length < 2) {
         player.sendMessage(Component.text("Usage: /rpp rename <name>").color(NamedTextColor.YELLOW));
      } else {
         String newName = String.join(" ", Arrays.asList(args).subList(1, args.length)).trim();
         if (newName.isEmpty()) {
            player.sendMessage(Component.text("Name can't be empty.").color(NamedTextColor.RED));
         } else {
            String old = MANNEQUIN_LABEL;
            MANNEQUIN_LABEL = newName;
            player.sendMessage(Component.text("Renamed \"" + old + "\" to \"" + MANNEQUIN_LABEL + "\".").color(NamedTextColor.GREEN));
         }
      }

   }

   private void listMannequins(Player player, String[] args) {
      this.purgeDeadCompanions();
      if (this.companions.isEmpty()) {
         player.sendMessage(Component.text(MANNEQUIN_LABEL + " doesn't exist.").color(NamedTextColor.RED));
      } else {
         int perPage = 8;
         int totalPages = Math.max(1, (int)Math.ceil((double)this.companions.size() / (double)perPage));
         int page = 1;
         if (args.length >= 2) {
            try {
               page = Integer.parseInt(args[1]);
            } catch (NumberFormatException var14) {
               player.sendMessage(Component.text("Page must be a whole number.").color(NamedTextColor.RED));
               return;
            }
         }

         page = Math.max(1, Math.min(page, totalPages));
         String var10001 = MANNEQUIN_LABEL;
         player.sendMessage(Component.text(var10001 + " (" + this.companions.size() + " active) - page " + page + "/" + totalPages).color(NamedTextColor.GOLD));
         List<Companion> ordered = new ArrayList(this.companions.values());
         int start = (page - 1) * perPage;
         int end = Math.min(start + perPage, ordered.size());

         for(int i = start; i < end; ++i) {
            Companion c = (Companion)ordered.get(i);
            Location loc = c.entity.getLocation();
            String mode;
            if (c.attacking) {
               mode = "attacking";
            } else if (c.following) {
               mode = "following";
            } else if (c.formation) {
               mode = "formation (beta)";
            } else if (c.roaming) {
               mode = "roaming";
            } else if (c.patrolling) {
               mode = "patrolling";
            } else if (c.jumping) {
               mode = "jumping";
            } else {
               mode = "idle";
            }

            player.sendMessage(Component.text(String.format("  #%d %s [%s] hp=%.1f  (%d, %d, %d)", i + 1, c.botName != null ? c.botName : "?", mode, c.entity.getHealth(), loc.getBlockX(), loc.getBlockY(), loc.getBlockZ())).color(NamedTextColor.GRAY));
         }
      }

   }

   private void startJumping(Player player, String[] args) {
      if (this.hasMannequins(player)) {
         boolean random = this.hasFlag(args, "--random");
         List<Companion> targets = this.resolveTargets(args);

         for(Companion c : targets) {
            c.resetMode();
            c.jumping = true;
            c.jumpRandom = random;
            c.nextJumpTick = this.tickCounter;
         }

         this.ensureTicker();
         String var10001 = this.describeTargets(targets);
         player.sendMessage(Component.text(var10001 + " is now jumping" + (random ? " (randomized)." : ".")).color(NamedTextColor.GREEN));
      }

   }

   private boolean hasFlag(String[] args, String flag) {
      for(String arg : args) {
         if (arg.equalsIgnoreCase(flag)) {
            return true;
         }
      }

      return false;
   }

   private void handleWaypointCommand(Player player, String[] args) {
      if (args.length < 2) {
         player.sendMessage(Component.text("Usage: /rpp waypoint <create|delete|addpoint|removepoint|connect|disconnect|list|rename> ...").color(NamedTextColor.YELLOW));
      } else {
         switch (args[1].toLowerCase()) {
            case "create": {
               if (args.length < 3) {
                  player.sendMessage(Component.text("Usage: /rpp waypoint create <name>").color(NamedTextColor.YELLOW));
                  return;
               }

               String name = args[2];
               if (this.waypointNetworks.containsKey(name.toLowerCase())) {
                  player.sendMessage(Component.text("A waypoint network named \"" + name + "\" already exists.").color(NamedTextColor.RED));
                  return;
               }

               WaypointNetwork network = new WaypointNetwork(name);
               network.addPoint(player.getLocation());
               this.waypointNetworks.put(name.toLowerCase(), network);
               player.sendMessage(Component.text("Created waypoint network \"" + name + "\" with node #1 at your location.").color(NamedTextColor.GREEN));
               break;
            }
            case "delete": {
               WaypointNetwork network = this.requireNetwork(player, args, 2);
               if (network == null) {
                  return;
               }

               this.waypointNetworks.remove(network.name.toLowerCase());
               player.sendMessage(Component.text("Deleted waypoint network \"" + network.name + "\".").color(NamedTextColor.GREEN));
               break;
            }
            case "addpoint": {
               WaypointNetwork network = this.requireNetwork(player, args, 2);
               if (network == null) {
                  return;
               }

               WaypointNode node = network.addPoint(player.getLocation());
               player.sendMessage(Component.text("Added node #" + node.id + " to \"" + network.name + "\" at your location.").color(NamedTextColor.GREEN));
               break;
            }
            case "removepoint": {
               WaypointNetwork network = this.requireNetwork(player, args, 2);
               if (network == null) {
                  return;
               }

               Integer id = this.parseNodeId(player, args, 3);
               if (id == null) {
                  return;
               }

               if (network.removePoint(id)) {
                  player.sendMessage(Component.text("Removed node #" + id + " from \"" + network.name + "\".").color(NamedTextColor.GREEN));
               } else {
                  player.sendMessage(Component.text("No node #" + id + " on that network.").color(NamedTextColor.RED));
               }
               break;
            }
            case "connect": {
               WaypointNetwork network = this.requireNetwork(player, args, 2);
               if (network == null) {
                  return;
               }

               Integer a = this.parseNodeId(player, args, 3);
               Integer b = this.parseNodeId(player, args, 4);
               if (a == null || b == null) {
                  return;
               }

               if (network.connect(a, b)) {
                  player.sendMessage(Component.text("Connected #" + a + " <-> #" + b + ".").color(NamedTextColor.GREEN));
               } else {
                  player.sendMessage(Component.text("Couldn't connect those nodes - check the ids.").color(NamedTextColor.RED));
               }
               break;
            }
            case "disconnect": {
               WaypointNetwork network = this.requireNetwork(player, args, 2);
               if (network == null) {
                  return;
               }

               Integer a = this.parseNodeId(player, args, 3);
               Integer b = this.parseNodeId(player, args, 4);
               if (a == null || b == null) {
                  return;
               }

               if (network.disconnect(a, b)) {
                  player.sendMessage(Component.text("Disconnected #" + a + " <-> #" + b + ".").color(NamedTextColor.GREEN));
               } else {
                  player.sendMessage(Component.text("Those nodes weren't connected.").color(NamedTextColor.RED));
               }
               break;
            }
            case "rename": {
               WaypointNetwork network = this.requireNetwork(player, args, 2);
               if (network == null) {
                  return;
               }

               if (args.length < 4) {
                  player.sendMessage(Component.text("Usage: /rpp waypoint rename <name> <new name>").color(NamedTextColor.YELLOW));
                  return;
               }

               String newName = args[3];
               if (this.waypointNetworks.containsKey(newName.toLowerCase())) {
                  player.sendMessage(Component.text("A waypoint network named \"" + newName + "\" already exists.").color(NamedTextColor.RED));
                  return;
               }

               this.waypointNetworks.remove(network.name.toLowerCase());
               network.name = newName;
               this.waypointNetworks.put(newName.toLowerCase(), network);
               player.sendMessage(Component.text("Renamed waypoint network to \"" + newName + "\".").color(NamedTextColor.GREEN));
               break;
            }
            case "list": {
               if (args.length >= 3) {
                  WaypointNetwork network = this.requireNetwork(player, args, 2);
                  if (network == null) {
                     return;
                  }

                  String var10001 = network.name;
                  player.sendMessage(Component.text("\"" + var10001 + "\" - " + network.nodes.size() + " node(s):").color(NamedTextColor.GOLD));

                  for(WaypointNode node : network.nodes.values()) {
                     Location l = node.location;
                     int var27 = node.id;
                     player.sendMessage(Component.text("  #" + var27 + " (" + l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ() + ") -> " + String.valueOf(node.connections)).color(NamedTextColor.GRAY));
                  }
               } else {
                  if (this.waypointNetworks.isEmpty()) {
                     player.sendMessage(Component.text("No waypoint networks yet. Use /rpp waypoint create <name>.").color(NamedTextColor.YELLOW));
                     return;
                  }

                  player.sendMessage(Component.text("Waypoint networks:").color(NamedTextColor.GOLD));

                  for(WaypointNetwork network : this.waypointNetworks.values()) {
                     String var28 = network.name;
                     player.sendMessage(Component.text("  " + var28 + " (" + network.nodes.size() + " nodes)").color(NamedTextColor.GRAY));
                  }
               }
               break;
            }
            default:
               player.sendMessage(Component.text("Unknown waypoint action. Use create, delete, addpoint, removepoint, connect, disconnect, list, or rename.").color(NamedTextColor.RED));
         }
      }

   }

   private WaypointNetwork requireNetwork(Player player, String[] args, int index) {
      if (args.length <= index) {
         player.sendMessage(Component.text("Missing waypoint network name.").color(NamedTextColor.YELLOW));
         return null;
      } else {
         WaypointNetwork network = (WaypointNetwork)this.waypointNetworks.get(args[index].toLowerCase());
         if (network == null) {
            player.sendMessage(Component.text("No waypoint network named \"" + args[index] + "\".").color(NamedTextColor.RED));
         }

         return network;
      }
   }

   private Integer parseNodeId(Player player, String[] args, int index) {
      if (args.length <= index) {
         player.sendMessage(Component.text("Missing node id.").color(NamedTextColor.YELLOW));
         return null;
      } else {
         try {
            return Integer.parseInt(args[index]);
         } catch (NumberFormatException var5) {
            player.sendMessage(Component.text("Node id must be a whole number.").color(NamedTextColor.RED));
            return null;
         }
      }
   }

   private void startPatrolling(Player player, String[] args) {
      if (this.hasMannequins(player)) {
         if (args.length < 2) {
            player.sendMessage(Component.text("Usage: /rpp patrol <waypoint> [--random]").color(NamedTextColor.YELLOW));
         } else {
            WaypointNetwork network = (WaypointNetwork)this.waypointNetworks.get(args[1].toLowerCase());
            if (network == null) {
               player.sendMessage(Component.text("No waypoint network named \"" + args[1] + "\".").color(NamedTextColor.RED));
            } else if (network.nodes.isEmpty()) {
               player.sendMessage(Component.text("\"" + network.name + "\" has no nodes yet.").color(NamedTextColor.RED));
            } else {
               boolean random = this.hasFlag(args, "--random");
               List<Companion> targets = this.resolveTargets(args);

               for(Companion c : targets) {
                  c.resetMode();
                  c.patrolling = true;
                  c.patrolNetwork = network.name.toLowerCase();
                  c.patrolCurrentNodeId = null;
                  c.patrolTargetNodeId = null;
                  c.patrolRandom = random;
               }

               this.ensureTicker();
               player.sendMessage(Component.text(this.describeTargets(targets) + " is now patrolling \"" + network.name + "\"" + (random ? " (random)." : ".")).color(NamedTextColor.GREEN));
            }
         }
      }

   }

   private void tickPatrol(Companion c) {
      WaypointNetwork network = (WaypointNetwork)this.waypointNetworks.get(c.patrolNetwork);
      if (network != null && !network.nodes.isEmpty()) {
         Mannequin mannequin = c.entity;
         Location current = mannequin.getLocation();
         if (current.getWorld() != null && current.getChunk().isLoaded()) {
            if (c.patrolTargetNodeId == null) {
               WaypointNode start = c.patrolCurrentNodeId != null ? (WaypointNode)network.nodes.get(c.patrolCurrentNodeId) : network.nearest(current);
               if (start == null) {
                  c.resetMode();
                  return;
               }

               c.patrolTargetNodeId = start.id;
               c.resetPath();
            }

            WaypointNode targetNode = (WaypointNode)network.nodes.get(c.patrolTargetNodeId);
            if (targetNode == null) {
               c.patrolTargetNodeId = null;
            } else {
               double verticalVelocity = this.resolveVerticalVelocity(mannequin);
               if (this.flatDistance(current, targetNode.location) < (double)1.25F) {
                  this.stopMovement(c, mannequin, verticalVelocity);
                  Integer arrivedFrom = c.patrolCurrentNodeId;
                  c.patrolCurrentNodeId = targetNode.id;
                  WaypointNode next = network.nextNode(targetNode.id, arrivedFrom, c.patrolRandom);
                  c.patrolPreviousNodeId = arrivedFrom;
                  c.patrolTargetNodeId = next != null ? next.id : null;
                  c.resetPath();
               } else {
                  this.maybeRecomputePath(c, targetNode.location);
                  this.moveAlongPath(c, mannequin, current, targetNode.location, verticalVelocity);
               }
            }
         }
      } else {
         c.resetMode();
      }

   }

   @EventHandler
   public void onMannequinInteract(PlayerInteractEntityEvent event) {
      if (event.getHand() == EquipmentSlot.HAND) {
         Entity var3 = event.getRightClicked();
         if (var3 instanceof Mannequin) {
            Mannequin clicked = (Mannequin)var3;
            Companion c = (Companion)this.companions.get(clicked.getUniqueId());
            if (c != null) {
               Player player = event.getPlayer();
               ItemStack handItem = player.getInventory().getItemInMainHand();
               if (!c.isBaby && handItem != null && handItem.getType() == Material.ENCHANTED_GOLDEN_APPLE) {
                  event.setCancelled(true);
                  this.feedBreedingApple(player, c, handItem);
                  return;
               }

               event.setCancelled(true);
               this.openInventoryGui(player, clicked);
            }
         }
      }

   }

   private void feedBreedingApple(Player player, Companion c, ItemStack handItem) {
      if (!c.loveMode && c.breedingPartnerId == null) {
         if (player.getGameMode() != GameMode.CREATIVE) {
            ItemStack shrunk = this.shrink(handItem);
            player.getInventory().setItemInMainHand(shrunk);
         }

         c.resetMode();
         c.loveMode = true;
         c.loveModeUntilTick = this.tickCounter + 600L;
         this.spawnHeartBurst(c.entity, 7);
         World world = c.entity.getWorld();
         if (world != null) {
            world.playSound(c.entity.getLocation(), Sound.ENTITY_VILLAGER_YES, SoundCategory.NEUTRAL, 1.0F, 1.0F);
         }

         String var6 = this.displayName(c);
         player.sendMessage(Component.text(var6 + " munches the enchanted golden apple and gets a sparkle in its eye...").color(NamedTextColor.LIGHT_PURPLE));
         this.ensureTicker();
         this.tryPairLovers();
      } else {
         String var10001 = this.displayName(c);
         player.sendMessage(Component.text(var10001 + " is already feeling the love.").color(NamedTextColor.LIGHT_PURPLE));
      }
   }

   private String displayName(Companion c) {
      return c.botName != null ? c.botName : MANNEQUIN_LABEL;
   }

   private void spawnHeartBurst(Mannequin mannequin, int count) {
      World world = mannequin.getWorld();
      if (world != null) {
         Location loc = mannequin.getLocation().add((double)0.0F, mannequin.getHeight() + 0.3, (double)0.0F);
         world.spawnParticle(Particle.HEART, loc, count, 0.35, 0.35, 0.35, (double)0.0F);
      }

   }

   private void tryPairLovers() {
      List<Companion> available = new ArrayList();

      for(Companion c : this.companions.values()) {
         if (c.loveMode && c.breedingPartnerId == null && !c.isBaby && !c.entity.isDead() && c.entity.isValid()) {
            available.add(c);
         }
      }

      while(available.size() >= 2) {
         Companion first = (Companion)available.remove(0);
         Companion closest = null;
         double closestDist = Double.MAX_VALUE;

         for(Companion candidate : available) {
            if (candidate.entity.getWorld() != null && candidate.entity.getWorld().equals(first.entity.getWorld())) {
               double dist = candidate.entity.getLocation().distance(first.entity.getLocation());
               if (dist < closestDist) {
                  closestDist = dist;
                  closest = candidate;
               }
            }
         }

         if (closest == null) {
            break;
         }

         available.remove(closest);
         first.breedingPartnerId = closest.entity.getUniqueId();
         closest.breedingPartnerId = first.entity.getUniqueId();
         first.resetPath();
         closest.resetPath();
      }

   }

   private void tickBreeding(Companion c) {
      if (c.breedingPartnerId == null) {
         if (this.tickCounter >= c.loveModeUntilTick) {
            c.loveMode = false;
         } else if (this.tickCounter % 10L == 0L) {
            this.spawnHeartBurst(c.entity, 2);
         }

      } else {
         Companion partner = (Companion)this.companions.get(c.breedingPartnerId);
         if (partner != null && !partner.entity.isDead() && partner.entity.isValid() && partner.loveMode) {
            Mannequin mannequin = c.entity;
            Location current = mannequin.getLocation();
            Location targetLoc = partner.entity.getLocation();
            if (current.getWorld() != null && current.getWorld().equals(targetLoc.getWorld())) {
               if (current.getChunk().isLoaded() && targetLoc.getChunk().isLoaded()) {
                  double distance = this.flatDistance(current, targetLoc);
                  double verticalVelocity = this.resolveVerticalVelocity(mannequin);
                  if (distance < 1.3) {
                     boolean isLeader = mannequin.getUniqueId().compareTo(partner.entity.getUniqueId()) < 0;
                     if (c.breedingBeginTick == Long.MIN_VALUE) {
                        c.breedingBeginTick = this.tickCounter;
                     }

                     long courtshipElapsed = this.tickCounter - c.breedingBeginTick;
                     if (courtshipElapsed < 80L) {
                        if (isLeader) {
                           this.stopMovement(c, mannequin, verticalVelocity);
                           double awayX = current.getX() - (targetLoc.getX() - current.getX());
                           double awayZ = current.getZ() - (targetLoc.getZ() - current.getZ());
                           Location awayLoc = new Location(current.getWorld(), awayX, current.getY(), awayZ);
                           this.faceTarget(mannequin, current, awayLoc, 20.0F);
                           if (this.tickCounter % 2L == 0L) {
                              this.setMannequinSneaking(mannequin, !mannequin.isSneaking());
                           }
                        } else {
                           float leaderYawRad = (float)Math.toRadians((double)targetLoc.getYaw());
                           double forwardX = -Math.sin((double)leaderYawRad);
                           double forwardZ = Math.cos((double)leaderYawRad);
                           long leg = courtshipElapsed / 12L;
                           boolean movingBehind = (leg & 1L) == 0L;
                           double targetForwardOffset = movingBehind ? (double)-1.0F : 0.3;
                           Location courtshipLoc = targetLoc.clone().add(forwardX * targetForwardOffset, (double)0.0F, forwardZ * targetForwardOffset);
                           double progress = Math.min((double)1.0F, (double)courtshipElapsed / (double)80.0F);
                           double easedProgress = progress * progress;
                           double courtshipSpeed = 0.08 + 0.67 * easedProgress;
                           double distToCourtshipPoint = this.flatDistance(current, courtshipLoc);
                           if (distToCourtshipPoint > 0.12) {
                              this.moveTowardAtSpeed(c, mannequin, current, courtshipLoc, verticalVelocity, courtshipSpeed);
                           } else {
                              this.stopMovement(c, mannequin, verticalVelocity);
                           }

                           this.faceTarget(mannequin, current, targetLoc, 20.0F);
                        }

                        if (this.tickCounter % 8L == 0L) {
                           this.spawnHeartBurst(mannequin, 3);
                        }
                     } else {
                        if (mannequin.isSneaking()) {
                           this.setMannequinSneaking(mannequin, false);
                        }

                        this.stopMovement(c, mannequin, verticalVelocity);
                        this.faceTarget(mannequin, current, targetLoc);
                        if (this.tickCounter % 8L == 0L) {
                           this.spawnHeartBurst(mannequin, 3);
                        }

                        if (isLeader) {
                           this.spawnBaby(c, partner);
                        }
                     }
                  } else {
                     this.maybeRecomputePath(c, targetLoc);
                     this.moveAlongPath(c, mannequin, current, targetLoc, verticalVelocity);
                     if (this.tickCounter % 6L == 0L) {
                        this.spawnHeartBurst(mannequin, 2);
                     }
                  }
               }

            }
         } else {
            c.loveMode = false;
            c.breedingPartnerId = null;
            c.breedingBeginTick = Long.MIN_VALUE;
            c.resetPath();
            if (c.entity.isSneaking()) {
               this.setMannequinSneaking(c.entity, false);
            }

         }
      }
   }

   private void spawnBaby(Companion parentA, Companion parentB) {
      Location locA = parentA.entity.getLocation();
      Location locB = parentB.entity.getLocation();
      World world = locA.getWorld();
      if (world != null) {
         double mx = (locA.getX() + locB.getX()) / (double)2.0F;
         double my = Math.max(locA.getY(), locB.getY());
         double mz = (locA.getZ() + locB.getZ()) / (double)2.0F;
         Location spawnLoc = new Location(world, mx, my, mz, locA.getYaw(), 0.0F);
         Entity entity = world.spawnEntity(spawnLoc, EntityType.MANNEQUIN);
         if (entity instanceof Mannequin) {
            Mannequin baby = (Mannequin)entity;
            baby.setImmovable(false);
            baby.customName(Component.text("BehBeh Fpp"));
            baby.setCustomNameVisible(true);
            baby.setDescription((Component)null);
            baby.setCollidable(false);
            AttributeInstance maxHealthAttr = baby.getAttribute(Attribute.MAX_HEALTH);
            if (maxHealthAttr != null) {
               maxHealthAttr.setBaseValue((double)40.0F);
            }

            baby.setHealth((double)40.0F);
            AttributeInstance knockbackAttr = baby.getAttribute(Attribute.KNOCKBACK_RESISTANCE);
            if (knockbackAttr != null) {
               knockbackAttr.setBaseValue(0.4);
            }

            AttributeInstance scaleAttr = baby.getAttribute(Attribute.SCALE);
            if (scaleAttr != null) {
               scaleAttr.setBaseValue(0.55);
            }

            Companion babyCompanion = new Companion(baby, "BehBeh Fpp");
            babyCompanion.isBaby = true;
            babyCompanion.growUpAtTick = this.tickCounter + 200L;
            this.companions.put(baby.getUniqueId(), babyCompanion);
            this.applyNamedSkin(baby, "MNIK_13");
            world.spawnParticle(Particle.HEART, spawnLoc.clone().add((double)0.0F, (double)0.6F, (double)0.0F), 20, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.0F);
            world.spawnParticle(Particle.HAPPY_VILLAGER, spawnLoc, 15, 0.4, 0.4, 0.4, (double)0.0F);
            world.playSound(spawnLoc, Sound.ENTITY_VILLAGER_CELEBRATE, SoundCategory.NEUTRAL, 1.0F, 1.0F);
         }
      }

      parentA.loveMode = false;
      parentA.breedingPartnerId = null;
      parentA.breedingBeginTick = Long.MIN_VALUE;
      parentA.resetPath();
      parentB.loveMode = false;
      parentB.breedingPartnerId = null;
      parentB.breedingBeginTick = Long.MIN_VALUE;
      parentB.resetPath();
      if (ThreadLocalRandom.current().nextDouble() < (double)0.5F) {
         Companion doomedParent = ThreadLocalRandom.current().nextBoolean() ? parentA : parentB;
         this.killCompanionFromChildbirth(doomedParent);
      }

   }

   private void killCompanionFromChildbirth(Companion parent) {
      Mannequin mannequin = parent.entity;
      if (mannequin != null && mannequin.isValid() && !mannequin.isDead()) {
         try {
            mannequin.setHealth((double)0.0F);
         } catch (Exception e) {
            Bukkit.getLogger().severe("[RppCommand] Failed to apply childbirth death: " + e.getMessage());
         }
      }

   }

   private void tickBabyGrowth(Companion c) {
      c.isBaby = false;
      String botName = this.allocateBotName();
      c.botName = botName;
      c.entity.customName(Component.text(botName));
      c.entity.setCustomNameVisible(true);
      AttributeInstance scaleAttr = c.entity.getAttribute(Attribute.SCALE);
      if (scaleAttr != null) {
         scaleAttr.setBaseValue((double)1.0F);
      }

      if (c.tabId != null) {
         this.tabPresence.remove(c.tabId);
      }

      c.tabId = this.applySkin(c.entity, botName, (Player)null);
      this.tabPresence.add(c.tabId, botName);
      World world = c.entity.getWorld();
      if (world != null) {
         Location loc = c.entity.getLocation();
         world.spawnParticle(Particle.HAPPY_VILLAGER, loc.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 25, 0.4, (double)0.5F, 0.4, (double)0.0F);
         world.playSound(loc, Sound.ENTITY_PLAYER_LEVELUP, SoundCategory.NEUTRAL, 1.0F, 1.2F);
      }

   }

   private void applyNamedSkin(Mannequin target, String skinName) {
      UUID mannequinId = target.getUniqueId();
      Bukkit.getAsyncScheduler().runNow(this.plugin, (task) -> {
         PlayerProfile resolved;
         try {
            PlayerProfile lookup = Bukkit.createProfile(skinName);
            lookup.complete();
            resolved = lookup;
         } catch (Exception e) {
            Bukkit.getLogger().warning("[RppCommand] Skin lookup for '" + skinName + "' failed: " + e.getMessage());
            return;
         }

         Bukkit.getGlobalRegionScheduler().run(this.plugin, (mainTask) -> {
            Entity entity = Bukkit.getEntity(mannequinId);
            if (entity instanceof Mannequin mannequin) {
               if (mannequin.isValid()) {
                  try {
                     mannequin.setProfile(ResolvableProfile.resolvableProfile(resolved));
                  } catch (Exception e) {
                     Bukkit.getLogger().warning("[RppCommand] Failed to apply skin '" + skinName + "': " + e.getMessage());
                  }
               }
            }

         });
      });
   }

   @EventHandler
   public void onGuiClick(InventoryClickEvent event) {
      if (event.getInventory().getHolder() instanceof CompanionGuiHolder) {
         int slot = event.getRawSlot();
         if (slot >= 0 && slot < 54 && !this.isEditableSlot(slot)) {
            event.setCancelled(true);
         }
      }

   }

   @EventHandler
   public void onGuiClose(InventoryCloseEvent event) {
      InventoryHolder var3 = event.getInventory().getHolder();
      if (var3 instanceof CompanionGuiHolder holder) {
         Companion c = (Companion)this.companions.get(holder.mannequinId);
         if (c != null && !c.entity.isDead() && c.entity.isValid()) {
            Inventory gui = event.getInventory();
            EntityEquipment equipment = c.entity.getEquipment();
            equipment.setItemInMainHand(gui.getItem(0));
            equipment.setItemInOffHand(gui.getItem(1));
            equipment.setHelmet(gui.getItem(3));
            equipment.setChestplate(gui.getItem(4));
            equipment.setLeggings(gui.getItem(5));
            equipment.setBoots(gui.getItem(6));

            for(int i = 0; i < 45; ++i) {
               c.storageContents[i] = gui.getItem(9 + i);
            }

            HumanEntity var7 = event.getPlayer();
            if (var7 instanceof Player) {
               Player player = (Player)var7;
               player.sendMessage(Component.text(MANNEQUIN_LABEL + "'s inventory updated.").color(NamedTextColor.GREEN));
            }
         }
      }

   }

   private boolean isEditableSlot(int slot) {
      return HEADER_EDITABLE_SLOTS.contains(slot) || slot >= 9;
   }

   private void openInventoryGui(Player player, Mannequin target) {
      Companion c = (Companion)this.companions.get(target.getUniqueId());
      if (c != null) {
         CompanionGuiHolder holder = new CompanionGuiHolder(target.getUniqueId());
         Inventory gui = Bukkit.createInventory(holder, 54, Component.text(MANNEQUIN_LABEL + " - Inventory"));
         holder.setInventory(gui);
         EntityEquipment equipment = target.getEquipment();
         gui.setItem(0, equipment.getItemInMainHand());
         gui.setItem(1, equipment.getItemInOffHand());
         gui.setItem(3, equipment.getHelmet());
         gui.setItem(4, equipment.getChestplate());
         gui.setItem(5, equipment.getLeggings());
         gui.setItem(6, equipment.getBoots());

         for(int i = 0; i < 45; ++i) {
            gui.setItem(9 + i, c.storageContents[i]);
         }

         ItemStack filler = this.fillerPane();

         for(int slot = 0; slot < 9; ++slot) {
            if (!HEADER_EDITABLE_SLOTS.contains(slot)) {
               gui.setItem(slot, filler);
            }
         }

         player.openInventory(gui);
         player.sendMessage(Component.text("Top row: Main Hand, Off Hand, (gap), Helmet, Chestplate, Leggings, Boots. Everything below is general storage.").color(NamedTextColor.GRAY));
      }

   }

   private ItemStack fillerPane() {
      ItemStack pane = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
      ItemMeta meta = pane.getItemMeta();
      if (meta != null) {
         meta.displayName(Component.text(" "));
         pane.setItemMeta(meta);
      }

      return pane;
   }

   private List<SettingsToggle> settingsToggles() {
      return List.of(new SettingsToggle(9, Material.COOKED_BEEF, "Auto-Eat", "Eats food from inventory when hungry.", this.autoEatEnabled), new SettingsToggle(10, Material.DIAMOND_SWORD, "Auto PvP", "Fights back immediately when attacked.", this.autoPvpEnabled), new SettingsToggle(11, Material.RABBIT_FOOT, "Random Hop", "Occasionally hops while moving, like a real player.", this.randomHopEnabled), new SettingsToggle(12, Material.FEATHER, "Always Sprint", "Sprint speed while roaming/patrolling. Follow and attack\nalways sprint regardless of this toggle.", this.alwaysSprintEnabled), new SettingsToggle(13, Material.MAP, "Path Debug View", "Shows a particle trail along each mannequin's path.", this.debugPathEnabled), new SettingsToggle(14, Material.HOPPER, "Auto-Refill", "Conjures food into storage when a hungry\nmannequin has none.", this.autoRefillEnabled), new SettingsToggle(15, Material.GOLDEN_APPLE, "Auto-Heal (Golden Apple)", "Eats a golden apple when critically hurt.", this.autoHealEnabled), new SettingsToggle(16, Material.ENDER_PEARL, "Auto-Pearl (Escape)", "Teleports away with an ender pearl at low health.", this.autoPearlEnabled), new SettingsToggle(17, Material.HOPPER_MINECART, "Auto-Pickup", "Picks up nearby dropped items and XP orbs.\nDrops everything it's carrying on death.", this.autoPickupEnabled), new SettingsToggle(18, Material.BOW, "Mocap Shots Hurt Players", "Lets arrows, tridents, potions and fireworks that\nmocap bots replay hurt real players. Off = they\nare harmless to players.", this.mocapHarmEnabled));
   }

   private void openSettingsGui(Player player) {
      SettingsGuiHolder holder = new SettingsGuiHolder();
      Inventory gui = Bukkit.createInventory(holder, 27, Component.text(MANNEQUIN_LABEL + " - Settings"));
      holder.setInventory(gui);
      this.refreshSettingsGui(gui);
      player.openInventory(gui);
      player.playSound(player.getLocation(), Sound.ITEM_ARMOR_EQUIP_GENERIC, SoundCategory.MASTER, 0.6F, 1.2F);
   }

   private void refreshSettingsGui(Inventory gui) {
      List<SettingsToggle> toggles = this.settingsToggles();
      Set<Integer> used = new HashSet();
      used.add(4);
      gui.setItem(4, this.settingsHeaderItem());

      for(SettingsToggle toggle : toggles) {
         gui.setItem(toggle.slot(), this.settingsToggleItem(toggle));
         used.add(toggle.slot());
      }

      ItemStack filler = this.fillerPane();

      for(int slot = 0; slot < 27; ++slot) {
         if (!used.contains(slot)) {
            gui.setItem(slot, filler);
         }
      }

   }

   private ItemStack settingsHeaderItem() {
      ItemStack item = new ItemStack(Material.NETHER_STAR);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.displayName(Component.text(MANNEQUIN_LABEL + " Settings").color(NamedTextColor.AQUA));
         meta.lore(List.of((TextComponent)Component.text("Click an icon below to toggle it.").color(NamedTextColor.GRAY), (TextComponent)Component.text("Glowing = enabled").color(NamedTextColor.DARK_GRAY)));
         meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES});
         item.setItemMeta(meta);
      }

      return item;
   }

   private ItemStack settingsToggleItem(SettingsToggle toggle) {
      ItemStack item = new ItemStack(toggle.icon());
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.displayName(((TextComponent)Component.text(toggle.label()).color(toggle.enabled() ? NamedTextColor.GREEN : NamedTextColor.RED)).decoration(TextDecoration.ITALIC, false));
         List<Component> lore = new ArrayList();

         for(String line : toggle.description().split("\n")) {
            lore.add(((TextComponent)Component.text(line).color(NamedTextColor.GRAY)).decoration(TextDecoration.ITALIC, false));
         }

         lore.add(Component.text(""));
         lore.add(((TextComponent)Component.text(toggle.enabled() ? "ENABLED" : "DISABLED").color(toggle.enabled() ? NamedTextColor.GREEN : NamedTextColor.RED)).decoration(TextDecoration.ITALIC, false));
         lore.add(Component.text("Click to toggle").color(NamedTextColor.DARK_GRAY));
         meta.lore(lore);
         meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_UNBREAKABLE});
         if (toggle.enabled()) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
         }

         item.setItemMeta(meta);
      }

      return item;
   }

   @EventHandler
   public void onSettingsClick(InventoryClickEvent event) {
      if (event.getInventory().getHolder() instanceof SettingsGuiHolder) {
         event.setCancelled(true);
         int slot = event.getRawSlot();
         if (slot == 9) {
            this.autoEatEnabled = !this.autoEatEnabled;
         } else if (slot == 10) {
            this.autoPvpEnabled = !this.autoPvpEnabled;
         } else if (slot == 11) {
            this.randomHopEnabled = !this.randomHopEnabled;
         } else if (slot == 12) {
            this.alwaysSprintEnabled = !this.alwaysSprintEnabled;
         } else if (slot == 13) {
            this.debugPathEnabled = !this.debugPathEnabled;
         } else if (slot == 14) {
            this.autoRefillEnabled = !this.autoRefillEnabled;
         } else if (slot == 15) {
            this.autoHealEnabled = !this.autoHealEnabled;
         } else if (slot == 16) {
            this.autoPearlEnabled = !this.autoPearlEnabled;
         } else if (slot == 17) {
            this.autoPickupEnabled = !this.autoPickupEnabled;
         } else {
            if (slot != 18) {
               return;
            }

            this.mocapHarmEnabled = !this.mocapHarmEnabled;
         }

         this.refreshSettingsGui(event.getInventory());
         this.saveSettings();
         HumanEntity var4 = event.getWhoClicked();
         if (var4 instanceof Player) {
            Player player = (Player)var4;
            player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, SoundCategory.MASTER, 0.5F, 1.4F);
         }
      }

   }

   private void saveAll() {
      this.saveSettings();
      this.saveWaypoints();
      this.saveMannequins();
   }

   private void saveAllAsync() {
      YamlConfiguration settingsSnapshot = this.buildSettingsYaml();
      YamlConfiguration waypointsSnapshot = this.buildWaypointsYaml();
      YamlConfiguration mannequinsSnapshot = this.buildMannequinsYaml();
      Bukkit.getAsyncScheduler().runNow(this.plugin, (task) -> {
         this.writeYamlQuietly(settingsSnapshot, this.settingsFile, "settings.yml");
         this.writeYamlQuietly(waypointsSnapshot, this.waypointsFile, "waypoints.yml");
         this.writeYamlQuietly(mannequinsSnapshot, this.mannequinsFile, "mannequins.yml");
      });
   }

   private void writeYamlQuietly(YamlConfiguration yaml, File file, String label) {
      try {
         yaml.save(file);
      } catch (IOException e) {
         Bukkit.getLogger().severe("[RppCommand] Failed to save " + label + ": " + e.getMessage());
      }

   }

   private void loadSettings() {
      if (this.settingsFile.exists()) {
         YamlConfiguration yaml = YamlConfiguration.loadConfiguration(this.settingsFile);
         this.autoEatEnabled = yaml.getBoolean("auto-eat", this.autoEatEnabled);
         this.autoPvpEnabled = yaml.getBoolean("auto-pvp", this.autoPvpEnabled);
         this.randomHopEnabled = yaml.getBoolean("random-hop", this.randomHopEnabled);
         this.alwaysSprintEnabled = yaml.getBoolean("always-sprint", this.alwaysSprintEnabled);
         this.debugPathEnabled = yaml.getBoolean("debug-path", this.debugPathEnabled);
         this.autoRefillEnabled = yaml.getBoolean("auto-refill", this.autoRefillEnabled);
         this.autoHealEnabled = yaml.getBoolean("auto-heal", this.autoHealEnabled);
         this.autoPearlEnabled = yaml.getBoolean("auto-pearl", this.autoPearlEnabled);
         this.autoPickupEnabled = yaml.getBoolean("auto-pickup", this.autoPickupEnabled);
         this.mocapHarmEnabled = yaml.getBoolean("mocap-harm", this.mocapHarmEnabled);
         MANNEQUIN_LABEL = yaml.getString("label", MANNEQUIN_LABEL);
         this.nextBotNumber = yaml.getInt("next-bot-number", this.nextBotNumber);
      }

   }

   private void saveSettings() {
      this.writeYamlQuietly(this.buildSettingsYaml(), this.settingsFile, "settings.yml");
   }

   private YamlConfiguration buildSettingsYaml() {
      YamlConfiguration yaml = new YamlConfiguration();
      yaml.set("auto-eat", this.autoEatEnabled);
      yaml.set("auto-pvp", this.autoPvpEnabled);
      yaml.set("random-hop", this.randomHopEnabled);
      yaml.set("always-sprint", this.alwaysSprintEnabled);
      yaml.set("debug-path", this.debugPathEnabled);
      yaml.set("auto-refill", this.autoRefillEnabled);
      yaml.set("auto-heal", this.autoHealEnabled);
      yaml.set("auto-pearl", this.autoPearlEnabled);
      yaml.set("auto-pickup", this.autoPickupEnabled);
      yaml.set("mocap-harm", this.mocapHarmEnabled);
      yaml.set("label", MANNEQUIN_LABEL);
      yaml.set("next-bot-number", this.nextBotNumber);
      return yaml;
   }

   private void loadWaypoints() {
      if (this.waypointsFile.exists()) {
         YamlConfiguration yaml = YamlConfiguration.loadConfiguration(this.waypointsFile);
         ConfigurationSection root = yaml.getConfigurationSection("networks");
         if (root != null) {
            for(String netName : root.getKeys(false)) {
               ConfigurationSection netSection = root.getConfigurationSection(netName);
               if (netSection != null) {
                  WaypointNetwork network = new WaypointNetwork(netSection.getString("name", netName));
                  ConfigurationSection nodesSection = netSection.getConfigurationSection("nodes");
                  int maxId = 0;
                  if (nodesSection != null) {
                     for(String idStr : nodesSection.getKeys(false)) {
                        int id;
                        try {
                           id = Integer.parseInt(idStr);
                        } catch (NumberFormatException var151) {
                           continue;
                        }

                        ConfigurationSection nodeSection = nodesSection.getConfigurationSection(idStr);
                        if (nodeSection != null) {
                           Location loc = nodeSection.getLocation("location");
                           if (loc != null) {
                              WaypointNode node = new WaypointNode(id, loc);
                              node.connections.addAll(nodeSection.getIntegerList("connections"));
                              network.nodes.put(id, node);
                              maxId = Math.max(maxId, id);
                           }
                        }
                     }
                  }

                  network.nextId = maxId + 1;
                  this.waypointNetworks.put(netName, network);
               }
            }
         }
      }

   }

   private void saveWaypoints() {
      this.writeYamlQuietly(this.buildWaypointsYaml(), this.waypointsFile, "waypoints.yml");
   }

   private YamlConfiguration buildWaypointsYaml() {
      YamlConfiguration yaml = new YamlConfiguration();
      ConfigurationSection root = yaml.createSection("networks");

      for(Map.Entry<String, WaypointNetwork> entry : this.waypointNetworks.entrySet()) {
         WaypointNetwork network = (WaypointNetwork)entry.getValue();
         ConfigurationSection netSection = root.createSection((String)entry.getKey());
         netSection.set("name", network.name);
         ConfigurationSection nodesSection = netSection.createSection("nodes");

         for(WaypointNode node : network.nodes.values()) {
            ConfigurationSection nodeSection = nodesSection.createSection(String.valueOf(node.id));
            nodeSection.set("location", node.location);
            nodeSection.set("connections", new ArrayList(node.connections));
         }
      }

      return yaml;
   }

   private Map<UUID, MannequinRecord> loadMannequinRecords() {
      Map<UUID, MannequinRecord> records = new HashMap();
      if (!this.mannequinsFile.exists()) {
         return records;
      } else {
         YamlConfiguration yaml = YamlConfiguration.loadConfiguration(this.mannequinsFile);
         ConfigurationSection root = yaml.getConfigurationSection("mannequins");
         if (root == null) {
            return records;
         } else {
            for(String key : root.getKeys(false)) {
               UUID id;
               try {
                  id = UUID.fromString(key);
               } catch (IllegalArgumentException var161) {
                  continue;
               }

               ConfigurationSection s = root.getConfigurationSection(key);
               if (s != null) {
                  MannequinRecord r = new MannequinRecord();
                  r.following = s.getBoolean("following");
                  r.attacking = s.getBoolean("attacking");
                  r.roaming = s.getBoolean("roaming");
                  String targetStr = s.getString("move-target");
                  if (targetStr != null) {
                     try {
                        r.moveTargetId = UUID.fromString(targetStr);
                     } catch (IllegalArgumentException var15) {
                     }
                  }

                  if (s.isSet("roam-center")) {
                     r.roamCenter = s.getLocation("roam-center");
                     r.roamRadius = s.getDouble("roam-radius");
                  }

                  r.patrolling = s.getBoolean("patrolling");
                  r.patrolNetwork = s.getString("patrol-network");
                  r.patrolCurrentNodeId = s.contains("patrol-current-node") ? s.getInt("patrol-current-node") : null;
                  r.patrolTargetNodeId = s.contains("patrol-target-node") ? s.getInt("patrol-target-node") : null;
                  r.patrolRandom = s.getBoolean("patrol-random");
                  r.jumping = s.getBoolean("jumping");
                  r.jumpRandom = s.getBoolean("jump-random");
                  r.formation = s.getBoolean("formation");
                  r.formationIndex = s.contains("formation-index") ? s.getInt("formation-index") : null;
                  r.hunger = s.getDouble("hunger", (double)20.0F);
                  List<?> rawStorage = s.getList("storage");
                  if (rawStorage != null) {
                     ItemStack[] storage = new ItemStack[45];

                     for(int i = 0; i < Math.min(45, rawStorage.size()); ++i) {
                        Object var14 = rawStorage.get(i);
                        if (var14 instanceof ItemStack) {
                           ItemStack item = (ItemStack)var14;
                           storage[i] = item;
                        }
                     }

                     r.storageContents = storage;
                  }

                  r.storedXp = s.getInt("stored-xp", 0);
                  r.botName = s.getString("bot-name");
                  records.put(id, r);
               }
            }

            return records;
         }
      }
   }

   private void saveMannequins() {
      this.writeYamlQuietly(this.buildMannequinsYaml(), this.mannequinsFile, "mannequins.yml");
   }

   private YamlConfiguration buildMannequinsYaml() {
      YamlConfiguration yaml = new YamlConfiguration();
      ConfigurationSection root = yaml.createSection("mannequins");

      for(Companion c : this.companions.values()) {
         ConfigurationSection s = root.createSection(c.entity.getUniqueId().toString());
         s.set("following", c.following);
         s.set("attacking", c.attacking);
         s.set("roaming", c.roaming);
         s.set("move-target", c.moveTargetId != null ? c.moveTargetId.toString() : null);
         if (c.roamCenter != null) {
            s.set("roam-center", c.roamCenter);
            s.set("roam-radius", c.roamRadius);
         }

         s.set("patrolling", c.patrolling);
         s.set("patrol-network", c.patrolNetwork);
         s.set("patrol-current-node", c.patrolCurrentNodeId);
         s.set("patrol-target-node", c.patrolTargetNodeId);
         s.set("patrol-random", c.patrolRandom);
         s.set("jumping", c.jumping);
         s.set("jump-random", c.jumpRandom);
         s.set("formation", c.formation);
         s.set("formation-index", c.formationIndex);
         s.set("hunger", c.hunger);
         s.set("storage", new ArrayList(Arrays.asList(c.storageContents)));
         s.set("stored-xp", c.storedXp);
         s.set("bot-name", c.botName);
      }

      return yaml;
   }

   private void restoreMannequin(Mannequin entity, MannequinRecord r) {
      Companion c = new Companion(entity);
      c.following = r.following;
      c.attacking = r.attacking;
      c.roaming = r.roaming;
      c.moveTargetId = r.moveTargetId;
      c.roamCenter = r.roamCenter;
      c.roamRadius = r.roamRadius;
      c.patrolling = r.patrolling;
      c.patrolNetwork = r.patrolNetwork;
      c.patrolCurrentNodeId = r.patrolCurrentNodeId;
      c.patrolTargetNodeId = r.patrolTargetNodeId;
      c.patrolRandom = r.patrolRandom;
      c.jumping = r.jumping;
      c.jumpRandom = r.jumpRandom;
      c.formation = r.formation;
      c.formationIndex = r.formationIndex;
      c.hunger = r.hunger;
      if (r.storageContents != null) {
         System.arraycopy(r.storageContents, 0, c.storageContents, 0, Math.min(r.storageContents.length, c.storageContents.length));
      }

      c.storedXp = r.storedXp;
      c.botName = r.botName != null ? r.botName : this.allocateBotName();
      if (r.botName == null) {
         entity.customName(Component.text(c.botName));
         entity.setCustomNameVisible(true);
      }

      c.tabId = UUID.randomUUID();
      this.tabPresence.add(c.tabId, c.botName);
      this.companions.put(entity.getUniqueId(), c);
      this.ensureTicker();
   }

   private void attemptPendingMannequinRestores() {
      if (!this.pendingMannequinRestores.isEmpty()) {
         Iterator<Map.Entry<UUID, MannequinRecord>> it = this.pendingMannequinRestores.entrySet().iterator();

         while(it.hasNext()) {
            Map.Entry<UUID, MannequinRecord> entry = (Map.Entry)it.next();
            Entity var4 = Bukkit.getEntity((UUID)entry.getKey());
            if (var4 instanceof Mannequin) {
               Mannequin mannequin = (Mannequin)var4;
               this.restoreMannequin(mannequin, (MannequinRecord)entry.getValue());
               it.remove();
            }
         }
      }

   }

   @EventHandler
   public void onChunkLoad(ChunkLoadEvent event) {
      this.attemptPendingMannequinRestores();
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onCompanionDamaged(EntityDamageByEntityEvent event) {
      Entity var3 = event.getEntity();
      if (var3 instanceof Mannequin mannequin) {
         Companion c = (Companion)this.companions.get(mannequin.getUniqueId());
         if (c != null) {
            LivingEntity attacker = this.resolveAttacker(event.getDamager());
            if (attacker != null && !event.isCancelled()) {
               this.applyCombatKnockback(c, mannequin, attacker);
               if (this.autoPvpEnabled && (!c.attacking || !attacker.getUniqueId().equals(c.moveTargetId))) {
                  boolean switchTarget = true;
                  if (c.attacking && c.moveTargetId != null) {
                     Entity currentTarget = Bukkit.getEntity(c.moveTargetId);
                     if (currentTarget instanceof LivingEntity living && living.isValid() && !living.isDead() && living.getWorld().equals(mannequin.getWorld()) && attacker.getWorld().equals(mannequin.getWorld())) {
                        // stay on the current fight unless the newcomer is clearly the bigger threat
                        double distCurrent = living.getLocation().distance(mannequin.getLocation());
                        double distNew = attacker.getLocation().distance(mannequin.getLocation());
                        switchTarget = distNew + 1.5 < distCurrent || distCurrent > 6.0;
                     }
                  }

                  if (switchTarget) {
                     c.resetMode();
                     c.attacking = true;
                     c.moveTargetId = attacker.getUniqueId();
                     this.ensureTicker();
                  }
               }
            }
         }
      }

   }

   private LivingEntity resolveAttacker(Entity damager) {
      if (damager instanceof Player player) {
         return player;
      } else {
         if (damager instanceof Mannequin mannequin) {
            if (this.companions.containsKey(mannequin.getUniqueId())) {
               return mannequin;
            }
         }

         if (damager instanceof Projectile projectile) {
            ProjectileSource var4 = projectile.getShooter();
            if (var4 instanceof LivingEntity shooter) {
               return shooter;
            }
         }

         return null;
      }
   }

   @EventHandler(
      priority = EventPriority.NORMAL
   )
   public void onCompanionMaybeBlock(EntityDamageByEntityEvent event) {
      if (event.isCancelled()) {
         return;
      }

      if (!(event.getEntity() instanceof Mannequin mannequin)) {
         return;
      }

      Companion c = (Companion)this.companions.get(mannequin.getUniqueId());
      if (c == null) {
         return;
      }

      c.lastHitTakenTick = this.tickCounter;
      if (ThreadLocalRandom.current().nextDouble() < 0.4) {
         c.nextStrafeFlipTick = this.tickCounter;
      }

      // A raised shield is blocked by the game itself. Only if the game is not blocking for us (shield "up" in our
      // state but not actually in use) fall back to a manual block of attacks coming from the front.
      if (!c.shieldUp || mannequin.isHandRaised()) {
         return;
      }

      Entity damager = event.getDamager();
      Vector facing = mannequin.getLocation().getDirection().setY(0);
      Vector toAttacker = damager.getLocation().toVector().subtract(mannequin.getLocation().toVector()).setY(0);
      if (facing.lengthSquared() < 1.0E-6 || toAttacker.lengthSquared() < 1.0E-6) {
         return;
      }

      if (Math.toDegrees((double)facing.angle(toAttacker)) > 90.0) {
         return;
      }

      event.setDamage(0.0);
      World world = mannequin.getWorld();
      if (world != null) {
         world.playSound(mannequin.getLocation(), Sound.ITEM_SHIELD_BLOCK, SoundCategory.HOSTILE, 1.0F, 1.0F);
      }

      if (damager instanceof LivingEntity livingDamager && livingDamager.getEquipment() != null && livingDamager.getEquipment().getItemInMainHand().getType().name().endsWith("_AXE")) {
         c.shieldDisabledUntilTick = this.tickCounter + 100L;
         this.lowerShieldIfUp(c, mannequin);
      }

   }

   private void applyCombatKnockback(Companion c, Mannequin mannequin, LivingEntity source) {
      Location mLoc = mannequin.getLocation();
      Location sLoc = source.getLocation();
      double dx = mLoc.getX() - sLoc.getX();
      double dz = mLoc.getZ() - sLoc.getZ();
      double strength = 0.4;
      if (this.isSourceSprinting(source)) {
         strength *= (double)2.0F;
      }

      AttributeInstance resistanceAttr = mannequin.getAttribute(Attribute.KNOCKBACK_RESISTANCE);
      if (resistanceAttr != null) {
         strength *= Math.max((double)0.0F, (double)1.0F - resistanceAttr.getValue());
      }

      if (!(strength <= (double)0.0F)) {
         double dist = Math.sqrt(dx * dx + dz * dz);
         double dirX;
         double dirZ;
         if (dist >= 1.0E-4) {
            dirX = dx / dist;
            dirZ = dz / dist;
         } else {
            Vector facing = source.getLocation().getDirection().setY(0);
            if (facing.lengthSquared() < 1.0E-8) {
               facing = new Vector(1, 0, 0);
            } else {
               facing.normalize();
            }

            dirX = facing.getX();
            dirZ = facing.getZ();
         }

         Vector existing = mannequin.getVelocity();
         double newX = existing.getX() / (double)2.0F + dirX * strength;
         double newZ = existing.getZ() / (double)2.0F + dirZ * strength;
         double newY = mannequin.isOnGround() ? Math.min(0.4, existing.getY() / (double)2.0F + strength) : existing.getY();
         double horizontalSpeed = Math.sqrt(newX * newX + newZ * newZ);
         if (horizontalSpeed > 0.9) {
            double scale = 0.9 / horizontalSpeed;
            newX *= scale;
            newZ *= scale;
         }

         mannequin.setVelocity(new Vector(newX, newY, newZ));
         c.knockbackUntilTick = this.tickCounter + 6L;
      }

   }

   private boolean isSourceSprinting(LivingEntity source) {
      if (source instanceof Player player) {
         return player.isSprinting();
      } else if (!(source instanceof Mannequin mannequin)) {
         return false;
      } else {
         Companion sourceCompanion = (Companion)this.companions.get(mannequin.getUniqueId());
         return sourceCompanion != null && sourceCompanion.sprintingVisual;
      }
   }

   @EventHandler
   public void onPlayerDeath(PlayerDeathEvent event) {
      Player victim = event.getPlayer();
      EntityDamageEvent lastDamage = victim.getLastDamageCause();
      if (lastDamage instanceof EntityDamageByEntityEvent damageEvent) {
         Entity var6 = damageEvent.getDamager();
         if (var6 instanceof Mannequin mannequin) {
            Companion killerCompanion = (Companion)this.companions.get(mannequin.getUniqueId());
            if (killerCompanion != null) {
               String slayerName = killerCompanion.botName != null ? killerCompanion.botName : "MrRacgoon";
               String var10001 = victim.getName();
               event.deathMessage(Component.text(var10001 + " was slain by " + slayerName).color(NamedTextColor.WHITE));
            }
         }
      }

   }

   @EventHandler
   public void onCompanionDeath(EntityDeathEvent event) {
      LivingEntity var3 = event.getEntity();
      if (var3 instanceof Mannequin mannequin) {
         Companion removed = (Companion)this.companions.remove(mannequin.getUniqueId());
         if (removed != null) {
            this.fakeJoinManager.leave(mannequin.getUniqueId());
            if (removed.tabId != null) {
               this.tabPresence.remove(removed.tabId);
            }

            removed.releaseBuild();

            try {
               this.dropCompanionInventory(event, removed);
            } catch (Exception e) {
               Bukkit.getLogger().severe("[RppCommand] Failed to drop mannequin inventory: " + e.getMessage());
            }

            Player killer = mannequin.getKiller();
            String killerName = killer != null ? killer.getName() : null;
            if (killerName == null) {
               EntityDamageEvent lastDamage = mannequin.getLastDamageCause();
               if (lastDamage instanceof EntityDamageByEntityEvent) {
                  EntityDamageByEntityEvent damageEvent = (EntityDamageByEntityEvent)lastDamage;
                  Entity var9 = damageEvent.getDamager();
                  if (var9 instanceof Mannequin) {
                     Mannequin slayerMannequin = (Mannequin)var9;
                     Companion slayerCompanion = (Companion)this.companions.get(slayerMannequin.getUniqueId());
                     if (slayerCompanion != null) {
                        killerName = slayerCompanion.botName != null ? slayerCompanion.botName : "MrRacgoon";
                     }
                  }
               }
            }

            String deadName = removed.botName != null ? removed.botName : "MrRacgoon";
            Component message = killerName != null ? Component.text(deadName + " was slain by " + killerName).color(NamedTextColor.WHITE) : Component.text(deadName + " died.").color(NamedTextColor.WHITE);
            Bukkit.broadcast(message);
         }
      }

   }

   private void tickHunger(Companion c) {
      boolean isEating = c.eatingUntilTick != Long.MIN_VALUE && this.tickCounter < c.eatingUntilTick;
      if (c.eatingUntilTick != Long.MIN_VALUE && this.tickCounter >= c.eatingUntilTick) {
         this.finishEating(c);
         isEating = false;
      }

      if (!isEating && (!this.autoHealEnabled || !(c.entity.getHealth() <= (double)14.0F) || !this.tryEmergencyHeal(c)) && this.autoEatEnabled) {
         c.hunger = Math.max((double)0.0F, c.hunger - 0.0033333333333333335);
         if (!(c.hunger > (double)6.0F)) {
            this.tryStartEating(c);
         }
      }

   }

   private boolean tryEmergencyHeal(Companion c) {
      return this.consumeFirstMatching(c, this::isGoldenApple);
   }

   private boolean isGoldenApple(ItemStack item) {
      return item != null && (item.getType() == Material.GOLDEN_APPLE || item.getType() == Material.ENCHANTED_GOLDEN_APPLE);
   }

   private void tryStartEating(Companion c) {
      if (!this.consumeFirstMatching(c, this::isEdible) && this.autoRefillEnabled) {
         for(int i = 0; i < c.storageContents.length; ++i) {
            if (c.storageContents[i] == null) {
               c.storageContents[i] = new ItemStack(AUTO_REFILL_FOOD, 8);
               this.tryStartEating(c);
               return;
            }
         }
      }

   }

   private boolean consumeFirstMatching(Companion c, Predicate<ItemStack> filter) {
      EntityEquipment equipment = c.entity.getEquipment();
      if (equipment == null) {
         return false;
      } else {
         ItemStack offhand = equipment.getItemInOffHand();
         if (filter.test(offhand)) {
            this.startEating(c, offhand.getType(), false);
            equipment.setItemInOffHand(this.shrink(offhand));
            return true;
         } else {
            ItemStack mainHand = equipment.getItemInMainHand();
            if (filter.test(mainHand)) {
               this.startEating(c, mainHand.getType(), true);
               equipment.setItemInMainHand(this.shrink(mainHand));
               return true;
            } else {
               for(int i = 0; i < c.storageContents.length; ++i) {
                  ItemStack stored = c.storageContents[i];
                  if (filter.test(stored)) {
                     this.startEating(c, stored.getType(), false);
                     c.storageContents[i] = this.shrink(stored);
                     return true;
                  }
               }

               return false;
            }
         }
      }
   }

   private void startEating(Companion c, Material foodType, boolean alreadyInMainHand) {
      EntityEquipment equipment = c.entity.getEquipment();
      if (!alreadyInMainHand && equipment != null) {
         c.preEatMainHand = equipment.getItemInMainHand();
         equipment.setItemInMainHand(new ItemStack(foodType));
      } else {
         c.preEatMainHand = null;
      }

      c.eatingFoodType = foodType;
      c.pendingHungerRestore = (Double)FOOD_RESTORE_AMOUNTS.getOrDefault(foodType, (double)3.0F);
      c.eatingUntilTick = this.tickCounter + 32L;
      c.entity.swingMainHand();
   }

   private void finishEating(Companion c) {
      EntityEquipment equipment = c.entity.getEquipment();
      if (equipment != null && c.preEatMainHand != null) {
         equipment.setItemInMainHand(c.preEatMainHand);
      }

      c.hunger = Math.min((double)20.0F, c.hunger + c.pendingHungerRestore);
      if (c.eatingFoodType == Material.GOLDEN_APPLE) {
         this.applyGoldenAppleEffects(c, 1, 100, 0, 2400, 0);
      } else if (c.eatingFoodType == Material.ENCHANTED_GOLDEN_APPLE) {
         this.applyGoldenAppleEffects(c, 3, 400, 3, 2400, 6000);
      }

      c.preEatMainHand = null;
      c.eatingFoodType = null;
      c.pendingHungerRestore = (double)0.0F;
      c.eatingUntilTick = Long.MIN_VALUE;
   }

   private void applyGoldenAppleEffects(Companion c, int regenAmplifier, int regenDurationTicks, int absorptionAmplifier, int absorptionDurationTicks, int resistanceDurationTicks) {
      c.entity.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, regenDurationTicks, regenAmplifier));
      c.entity.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, absorptionDurationTicks, absorptionAmplifier));
      if (resistanceDurationTicks > 0) {
         c.entity.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, resistanceDurationTicks, 0));
         c.entity.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, resistanceDurationTicks, 0));
      }

   }

   private boolean isEdible(ItemStack item) {
      return item != null && item.getType() != Material.AIR && item.getType().isEdible();
   }

   private ItemStack shrink(ItemStack item) {
      if (item.getAmount() <= 1) {
         return null;
      } else {
         ItemStack copy = item.clone();
         copy.setAmount(copy.getAmount() - 1);
         return copy;
      }
   }

   private void tickPickup(Companion c) {
      for(Entity nearby : c.entity.getNearbyEntities((double)1.5F, (double)1.5F, (double)1.5F)) {
         if (nearby instanceof Item droppedItem) {
            if (droppedItem.isValid() && droppedItem.getPickupDelay() <= 0) {
               ItemStack stack = droppedItem.getItemStack();
               ItemStack leftover = this.tryStoreItem(c, stack);
               if (leftover == null) {
                  this.playPickupFeedback(c);
                  droppedItem.remove();
               } else if (leftover.getAmount() != stack.getAmount()) {
                  this.playPickupFeedback(c);
                  droppedItem.setItemStack(leftover);
               }
            }
         } else if (nearby instanceof ExperienceOrb orb) {
            if (orb.isValid()) {
               c.storedXp += orb.getExperience();
               this.playPickupFeedback(c);
               orb.remove();
            }
         }
      }

   }

   private ItemStack tryStoreItem(Companion c, ItemStack stack) {
      ItemStack remaining = stack.clone();

      for(int i = 0; i < c.storageContents.length && remaining.getAmount() > 0; ++i) {
         ItemStack existing = c.storageContents[i];
         if (existing != null && existing.isSimilar(remaining)) {
            int room = existing.getMaxStackSize() - existing.getAmount();
            if (room > 0) {
               int moved = Math.min(room, remaining.getAmount());
               existing.setAmount(existing.getAmount() + moved);
               remaining.setAmount(remaining.getAmount() - moved);
            }
         }
      }

      for(int i = 0; i < c.storageContents.length && remaining.getAmount() > 0; ++i) {
         if (c.storageContents[i] == null) {
            c.storageContents[i] = remaining.clone();
            remaining.setAmount(0);
         }
      }

      return remaining.getAmount() > 0 ? remaining : null;
   }

   private void playPickupFeedback(Companion c) {
      c.entity.getWorld().playSound(c.entity.getLocation(), Sound.ENTITY_ITEM_PICKUP, SoundCategory.PLAYERS, 0.4F, 1.0F);
   }

   private void dropCompanionInventory(EntityDeathEvent event, Companion c) {
      List<ItemStack> drops = event.getDrops();
      EntityEquipment equipment = c.entity.getEquipment();
      if (equipment != null) {
         this.addIfPresent(drops, equipment.getItemInMainHand());
         this.addIfPresent(drops, equipment.getItemInOffHand());
         this.addIfPresent(drops, equipment.getHelmet());
         this.addIfPresent(drops, equipment.getChestplate());
         this.addIfPresent(drops, equipment.getLeggings());
         this.addIfPresent(drops, equipment.getBoots());
      }

      for(ItemStack stored : c.storageContents) {
         this.addIfPresent(drops, stored);
      }

      if (c.storedXp > 0) {
         Location loc = c.entity.getLocation();
         World world = c.entity.getWorld();

         for(int remaining = c.storedXp; remaining > 0; ) {
            final int orbValue = Math.min(remaining, ThreadLocalRandom.current().nextInt(5, 26));
            world.spawn(loc, ExperienceOrb.class, (orb) -> orb.setExperience(orbValue));
            remaining -= orbValue;
         }
      }

   }

   private void addIfPresent(List<ItemStack> drops, ItemStack item) {
      if (item != null && item.getType() != Material.AIR) {
         drops.add(item);
      }

   }

   private boolean tryPearlEscape(Companion c) {
      Mannequin mannequin = c.entity;
      if (mannequin.getHealth() > (double)10.0F) {
         return false;
      } else if (this.tickCounter < c.pearlEscapeCooldownUntilTick) {
         return false;
      } else {
         Location origin = mannequin.getLocation();
         Location destination = this.findPearlEscapeDestination(origin);
         if (destination == null) {
            return false;
         } else if (!this.consumeOneItem(c, Material.ENDER_PEARL)) {
            return false;
         } else {
            World world = origin.getWorld();
            if (world != null) {
               world.playSound(origin, Sound.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0F, 1.0F);
               world.spawnParticle(Particle.PORTAL, origin, 32, 0.3, (double)0.5F, 0.3, 0.05);
            }

            mannequin.teleport(destination);
            if (world != null) {
               world.playSound(destination, Sound.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1.0F, 1.0F);
               world.spawnParticle(Particle.PORTAL, destination, 32, 0.3, (double)0.5F, 0.3, 0.05);
            }

            c.pearlEscapeCooldownUntilTick = this.tickCounter + 200L;
            c.resetPath();
            return true;
         }
      }
   }

   private Location findPearlEscapeDestination(Location origin) {
      World world = origin.getWorld();
      if (world == null) {
         return null;
      } else {
         for(int attempt = 0; attempt < 8; ++attempt) {
            double angle = ThreadLocalRandom.current().nextDouble((double)0.0F, (Math.PI * 2D));
            Location candidateCenter = origin.clone().add(Math.cos(angle) * (double)10.0F, (double)0.0F, Math.sin(angle) * (double)10.0F);
            candidateCenter = this.clampToWorldBorder(candidateCenter);
            int x = candidateCenter.getBlockX();
            int z = candidateCenter.getBlockZ();

            for(int dy = 3; dy >= -3; --dy) {
               int y = origin.getBlockY() + dy;
               if (y >= world.getMinHeight() && y <= world.getMaxHeight() - 2 && this.isWalkable(world, x, y, z)) {
                  return new Location(world, (double)x + (double)0.5F, (double)y, (double)z + (double)0.5F, origin.getYaw(), origin.getPitch());
               }
            }
         }

         return null;
      }
   }

   private boolean consumeOneItem(Companion c, Material material) {
      EntityEquipment equipment = c.entity.getEquipment();
      if (equipment == null) {
         return false;
      } else {
         ItemStack offhand = equipment.getItemInOffHand();
         if (offhand != null && offhand.getType() == material) {
            equipment.setItemInOffHand(this.shrink(offhand));
            return true;
         } else {
            ItemStack mainHand = equipment.getItemInMainHand();
            if (mainHand != null && mainHand.getType() == material) {
               equipment.setItemInMainHand(this.shrink(mainHand));
               return true;
            } else {
               for(int i = 0; i < c.storageContents.length; ++i) {
                  ItemStack stored = c.storageContents[i];
                  if (stored != null && stored.getType() == material) {
                     c.storageContents[i] = this.shrink(stored);
                     return true;
                  }
               }

               return false;
            }
         }
      }
   }

   private void removeAll(Player player, String[] args) {
      this.purgeDeadCompanions();
      if (this.companions.isEmpty()) {
         player.sendMessage(Component.text(MANNEQUIN_LABEL + " doesn't exist.").color(NamedTextColor.RED));
      } else {
         List<Companion> targets = this.resolveTargets(args);
         int count = targets.size();
         String description = this.describeTargets(targets);

         for(Companion c : targets) {
            c.releaseBuild();
            this.fakeJoinManager.leave(c.entity.getUniqueId());
            if (c.tabId != null) {
               this.tabPresence.remove(c.tabId);
               Bukkit.broadcast(Component.text(c.botName + " left the game").color(NamedTextColor.YELLOW));
            }

            this.companions.remove(c.entity.getUniqueId());
            c.entity.remove();
         }

         String var10001 = count == 1 ? description : count + "x " + MANNEQUIN_LABEL;
         player.sendMessage(Component.text(var10001 + " removed.").color(NamedTextColor.GREEN));
      }

   }

   private boolean hasMannequins(Player player) {
      this.purgeDeadCompanions();
      if (this.companions.isEmpty()) {
         player.sendMessage(Component.text(MANNEQUIN_LABEL + " doesn't exist. Use /rpp spawn first.").color(NamedTextColor.RED));
         return false;
      } else {
         return true;
      }
   }

   private List<Companion> resolveTargets(String[] args) {
      for(String arg : args) {
         for(Companion c : this.companions.values()) {
            if (c.botName != null && c.botName.equalsIgnoreCase(arg)) {
               return new ArrayList(List.of(c));
            }
         }
      }

      return new ArrayList(this.companions.values());
   }

   private String describeTargets(List<Companion> targets) {
      if (targets.size() == 1) {
         Companion only = (Companion)targets.get(0);
         return only.botName != null ? only.botName : MANNEQUIN_LABEL;
      } else {
         return targets.size() == this.companions.size() ? MANNEQUIN_LABEL : targets.size() + " bots";
      }
   }

   private void purgeDeadCompanions() {
      this.companions.values().removeIf((c) -> {
         boolean gone = c.entity.isDead() || !c.entity.isValid();
         if (gone) {
            c.releaseBuild();
            this.fakeJoinManager.leave(c.entity.getUniqueId());
            if (c.tabId != null) {
               this.tabPresence.remove(c.tabId);
               String var10000 = c.botName != null ? c.botName : MANNEQUIN_LABEL;
               Bukkit.broadcast(Component.text(var10000 + " left the game").color(NamedTextColor.YELLOW));
            }
         }

         return gone;
      });
   }

   private void ensureTicker() {
      if (!this.tickerStarted) {
         this.tickerStarted = true;
         Bukkit.getGlobalRegionScheduler().runAtFixedRate(this.plugin, (task) -> this.tick(), 1L, 1L);
      }

   }

   private void tick() {
      ++this.tickCounter;
      if (this.tickCounter % 6000L == 0L) {
         this.saveAllAsync();
      }

      if (this.tickCounter % 20L == 0L) {
         this.tickBuildJobs();
      }

      this.tickGhosts();
      this.tickMocapRecorders();
      if (!this.companions.isEmpty()) {
         Map<Companion, Integer> formationRank = Collections.emptyMap();
         int formationSize = 0;
         List<Companion> formationMembers = new ArrayList();

         for(Companion c : this.companions.values()) {
            if (c.formation && !c.entity.isDead() && c.entity.isValid()) {
               formationMembers.add(c);
            }
         }

         if (!formationMembers.isEmpty()) {
            formationMembers.sort(Comparator.comparingInt((m) -> m.formationIndex != null ? m.formationIndex : Integer.MAX_VALUE));
            formationRank = new IdentityHashMap();

            for(int i = 0; i < formationMembers.size(); ++i) {
               formationRank.put((Companion)formationMembers.get(i), i);
            }

            formationSize = formationMembers.size();
         }

         Iterator<Map.Entry<UUID, Companion>> iterator = this.companions.entrySet().iterator();

         while(true) {
            Companion c;
            while(true) {
               if (!iterator.hasNext()) {
                  if (this.companions.size() > 1 && (this.tickCounter & 1L) == 0L) {
                     this.applyBotSeparation();
                  }

                  return;
               }

               c = (Companion)((Map.Entry)iterator.next()).getValue();
               if (!c.entity.isDead() && c.entity.isValid()) {
                  if (this.tickCounter >= c.knockbackUntilTick) {
                     try {
                        if (!this.autoPearlEnabled || c.mocap != null || !this.tryPearlEscape(c)) {
                           break;
                        }
                     } catch (Exception e) {
                        Bukkit.getLogger().severe("[RppCommand] Pearl-escape error: " + e.getMessage());
                        break;
                     }
                  } else {
                     try {
                        this.tickCombatStaggered(c);
                     } catch (Exception e) {
                        Bukkit.getLogger().severe("[RppCommand] Staggered combat error: " + e.getMessage());
                     }
                  }
               } else {
                  c.releaseBuild();
                  iterator.remove();
               }
            }

            try {
               if (c.mocap == null) {
                  this.tickHunger(c);
               }
            } catch (Exception e) {
               Bukkit.getLogger().severe("[RppCommand] Auto-eat error: " + e.getMessage());
            }

            try {
               if (this.autoPickupEnabled && c.mocap == null) {
                  this.tickPickup(c);
               }
            } catch (Exception e) {
               Bukkit.getLogger().severe("[RppCommand] Auto-pickup error: " + e.getMessage());
            }

            if (c.isBaby && this.tickCounter >= c.growUpAtTick) {
               try {
                  this.tickBabyGrowth(c);
               } catch (Exception e) {
                  Bukkit.getLogger().severe("[RppCommand] Baby growth error: " + e.getMessage());
                  c.isBaby = false;
               }
            }

            if (c.mocap != null) {
               try {
                  this.tickMocap(c);
               } catch (Exception e) {
                  Bukkit.getLogger().severe("[RppCommand] Mocap playback error, stopping: " + String.valueOf(e));
                  c.releaseMocap();
               }
            } else if (this.tickCounter < c.eatingUntilTick) {
               Vector v = c.entity.getVelocity();
               this.stopMovement(c, c.entity, v.getY());
               this.applyLookAtTracking(c);
            } else if (c.loveMode) {
               try {
                  this.tickBreeding(c);
               } catch (Exception e) {
                  Bukkit.getLogger().severe("[RppCommand] Breeding error, stopping: " + e.getMessage());
                  c.loveMode = false;
                  c.breedingPartnerId = null;
               }
            } else if (c.building) {
               try {
                  this.tickBuild(c);
               } catch (Exception e) {
                  Bukkit.getLogger().severe("[RppCommand] Build error, stopping: " + String.valueOf(e));
                  c.resetMode();
               }
            } else if (c.roaming) {
               try {
                  this.tickRoam(c);
               } catch (Exception e) {
                  Bukkit.getLogger().severe("[RppCommand] Roam error, stopping: " + e.getMessage());
                  c.resetMode();
               }

               this.applyLookAtTracking(c);
            } else if (c.patrolling) {
               try {
                  this.tickPatrol(c);
               } catch (Exception e) {
                  Bukkit.getLogger().severe("[RppCommand] Patrol error, stopping: " + e.getMessage());
                  c.resetMode();
               }

               this.applyLookAtTracking(c);
            } else if (c.jumping) {
               try {
                  this.tickJumping(c);
               } catch (Exception e) {
                  Bukkit.getLogger().severe("[RppCommand] Jump error, stopping: " + e.getMessage());
                  c.resetMode();
               }

               this.applyLookAtTracking(c);
            } else if (c.formation) {
               try {
                  this.tickFormationFollow(c, (Integer)formationRank.get(c), formationSize);
               } catch (Exception e) {
                  Bukkit.getLogger().severe("[RppCommand] Formation error, stopping: " + e.getMessage());
                  c.resetMode();
               }

               this.applyLookAtTracking(c);
            } else if (!c.following && !c.attacking) {
               this.applyLookAtTracking(c);
            } else if (c.moveTargetId != null) {
               Entity targetEntity = Bukkit.getEntity(c.moveTargetId);
               if (targetEntity instanceof LivingEntity) {
                  LivingEntity target = (LivingEntity)targetEntity;
                  if (!target.isDead() && target.isValid()) {
                     try {
                        Vector spacing = this.groupSpacingOffset(c);
                        Location pathGoal = spacing != null ? target.getLocation().add(spacing) : target.getLocation();
                        this.maybeRecomputePath(c, pathGoal);
                        if (c.attacking) {
                           this.tickCombat(c, target, spacing);
                        } else {
                           this.tickFollow(c, target, spacing);
                           this.applyLookAtTracking(c);
                        }
                     } catch (Exception e) {
                        Bukkit.getLogger().severe("[RppCommand] Movement error, stopping: " + e.getMessage());
                        c.resetMode();
                     }
                  }
               }
            }
         }
      }
   }

   private void applyBotSeparation() {
      List<Companion> list = new ArrayList(this.companions.values());

      for(int i = 0; i < list.size(); ++i) {
         Companion a = (Companion)list.get(i);
         if (!a.entity.isDead() && a.entity.isValid()) {
            Location la = a.entity.getLocation();
            World worldA = la.getWorld();
            if (worldA != null) {
               double pushX = (double)0.0F;
               double pushZ = (double)0.0F;

               for(int j = 0; j < list.size(); ++j) {
                  if (i != j) {
                     Companion b = (Companion)list.get(j);
                     if (!b.entity.isDead() && b.entity.isValid()) {
                        Location lb = b.entity.getLocation();
                        if (worldA.equals(lb.getWorld()) && !(Math.abs(la.getY() - lb.getY()) > (double)1.5F)) {
                           double dx = la.getX() - lb.getX();
                           double dz = la.getZ() - lb.getZ();
                           double distSq = dx * dx + dz * dz;
                           if (!(distSq >= 0.48999999999999994)) {
                              double dist = Math.sqrt(distSq);
                              if (dist < 1.0E-4) {
                                 double angle = ThreadLocalRandom.current().nextDouble((double)0.0F, (Math.PI * 2D));
                                 dx = Math.cos(angle);
                                 dz = Math.sin(angle);
                                 dist = (double)1.0F;
                              }

                              double overlap = (0.7 - dist) / 0.7;
                              pushX += dx / dist * overlap;
                              pushZ += dz / dist * overlap;
                           }
                        }
                     }
                  }
               }

               if (pushX != (double)0.0F || pushZ != (double)0.0F) {
                  Vector current = a.entity.getVelocity();
                  a.entity.setVelocity(current.add(new Vector(pushX * 0.06, (double)0.0F, pushZ * 0.06)));
                  a.motorVel[0] += pushX * 0.06;
                  a.motorVel[1] += pushZ * 0.06;
               }
            }
         }
      }

   }

   private void maybeRecomputePath(Companion c, Location goal) {
      Location start = c.entity.getLocation();
      boolean needsRecompute = c.currentPath == null || c.pathIndex >= c.currentPath.size() || c.lastPathGoal == null || !c.lastPathGoal.getWorld().equals(goal.getWorld()) || c.lastPathGoal.distance(goal) > (double)8.0F || this.tickCounter - c.lastPathComputeTick >= 40L + Math.floorMod((long)c.entity.getEntityId(), 20L);
      if (needsRecompute) {
         c.lastPathComputeTick = this.tickCounter;
         c.lastPathGoal = goal.clone();
         c.currentPath = this.findPath(start, this.clampGoalToPathRange(start, goal));
         c.pathIndex = 0;
      }

   }

   private Location clampGoalToPathRange(Location start, Location goal) {
      double distance = start.distance(goal);
      if (!(distance <= (double)32.0F) && !(distance < 1.0E-6)) {
         double t = (double)32.0F / distance;
         double x = start.getX() + (goal.getX() - start.getX()) * t;
         double z = start.getZ() + (goal.getZ() - start.getZ()) * t;
         World world = start.getWorld();
         Integer groundY = this.findGroundY(world, (int)Math.floor(x), (int)Math.floor(z), start.getBlockY());
         double y = groundY != null ? (double)groundY : start.getY();
         return new Location(world, x, y, z);
      } else {
         return goal;
      }
   }

   private Vector groupSpacingOffset(Companion c) {
      if (c.moveTargetId == null) {
         return null;
      } else {
         boolean attackMode = c.attacking;
         List<Companion> group = new ArrayList();

         for(Companion other : this.companions.values()) {
            if (!other.entity.isDead() && other.entity.isValid() && c.moveTargetId.equals(other.moveTargetId)) {
               boolean sameMode = attackMode ? other.attacking : other.following && !other.attacking;
               if (sameMode) {
                  group.add(other);
               }
            }
         }

         if (group.size() <= 2) {
            return null;
         } else {
            group.sort(Comparator.comparing((m) -> m.entity.getUniqueId()));
            int index = group.indexOf(c);
            if (index < 0) {
               return null;
            } else {
               double angle = (Math.PI * 2D) / (double)group.size() * (double)index;
               double radius = Math.min((double)4.0F, (double)1.5F + 0.15 * (double)group.size());
               return new Vector(Math.cos(angle) * radius, (double)0.0F, Math.sin(angle) * radius);
            }
         }
      }
   }

   private void tickFollow(Companion c, LivingEntity target, Vector spacing) {
      Mannequin mannequin = c.entity;
      Location current = mannequin.getLocation();
      Location targetLoc = target.getLocation();
      Location anchor = spacing != null ? targetLoc.clone().add(spacing) : targetLoc;
      if (current.getWorld() != null && current.getWorld().equals(anchor.getWorld())) {
         if (current.getChunk().isLoaded() && anchor.getChunk().isLoaded()) {
            double distanceToTarget = this.flatDistance(current, anchor);
            double verticalVelocity = this.resolveVerticalVelocity(mannequin);
            double stopDistance = spacing != null ? (double)1.0F : (double)2.0F;
            if (distanceToTarget < stopDistance) {
               this.stopMovement(c, mannequin, verticalVelocity);
               this.faceTarget(mannequin, current, targetLoc);
            } else {
               this.moveAlongPath(c, mannequin, current, anchor, verticalVelocity);
            }
         }
      } else {
         mannequin.teleport(targetLoc);
      }

   }

   private void tickFormationFollow(Companion c, Integer rank, int totalSize) {
      Mannequin mannequin = c.entity;
      if (rank != null && totalSize > 0) {
         Entity targetEntity = Bukkit.getEntity(c.moveTargetId);
         if (targetEntity instanceof Player) {
            Player anchor = (Player)targetEntity;
            if (!anchor.isDead() && anchor.isValid()) {
               Location current = mannequin.getLocation();
               Location anchorLoc = anchor.getLocation();
               if (current.getWorld() != null && current.getWorld().equals(anchorLoc.getWorld())) {
                  if (current.getChunk().isLoaded() && anchorLoc.getChunk().isLoaded()) {
                     Location slot = this.computeFormationSlot(anchor, rank, totalSize);
                     if (slot == null) {
                        return;
                     }

                     double distanceToSlot = this.flatDistance(current, slot);
                     double verticalVelocity = this.resolveVerticalVelocity(mannequin);
                     if (distanceToSlot < (double)1.0F) {
                        this.stopMovement(c, mannequin, verticalVelocity);
                        float newYaw = this.turnToward(current.getYaw(), anchorLoc.getYaw(), 38.0F);
                        float newPitch = this.turnToward(current.getPitch(), 0.0F, 8.0F);
                        mannequin.setRotation(newYaw, newPitch);
                        return;
                     }

                     this.maybeRecomputePath(c, slot);
                     this.moveAlongPath(c, mannequin, current, slot, verticalVelocity);
                     return;
                  }

                  return;
               }

               mannequin.teleport(anchorLoc);
               return;
            }
         }

         this.stopMovement(c, mannequin, this.resolveVerticalVelocity(mannequin));
      }

   }

   private Location computeFormationSlot(Player anchor, int rank, int totalSize) {
      int side = (int)Math.ceil(Math.sqrt((double)totalSize));
      int row = rank / side;
      int col = rank % side;
      double lateral = ((double)col - (double)(side - 1) / (double)2.0F) * (double)2.25F;
      double depth = (double)3.0F + (double)row * (double)2.25F;
      Location anchorLoc = anchor.getLocation();
      double yawRad = Math.toRadians((double)anchorLoc.getYaw());
      double forwardX = -Math.sin(yawRad);
      double forwardZ = Math.cos(yawRad);
      double rightX = WasdMotor.rightX(anchorLoc.getYaw());
      double rightZ = WasdMotor.rightZ(anchorLoc.getYaw());
      double x = anchorLoc.getX() - forwardX * depth + rightX * lateral;
      double z = anchorLoc.getZ() - forwardZ * depth + rightZ * lateral;
      World world = anchorLoc.getWorld();
      Integer groundY = this.findGroundY(world, (int)Math.floor(x), (int)Math.floor(z), anchorLoc.getBlockY());
      return groundY == null ? null : new Location(world, x, (double)groundY, z);
   }

   private void tickRoam(Companion c) {
      Mannequin mannequin = c.entity;
      Location current = mannequin.getLocation();
      double verticalVelocity = this.resolveVerticalVelocity(mannequin);
      if (current.getWorld() != null && current.getChunk().isLoaded()) {
         if (c.roamDestination != null && this.tickCounter >= c.roamPauseUntilTick) {
            if (this.flatDistance(current, c.roamDestination) < (double)2.0F) {
               this.stopMovement(c, mannequin, verticalVelocity);
               c.roamDestination = null;
               c.resetPath();
               c.roamPauseUntilTick = this.tickCounter + this.randomRoamPauseTicks();
            } else {
               this.maybeRecomputePath(c, c.roamDestination);
               this.moveAlongPath(c, mannequin, current, c.roamDestination, verticalVelocity);
            }
         } else {
            this.stopMovement(c, mannequin, verticalVelocity);
            if (c.roamDestination == null && this.tickCounter >= c.roamPauseUntilTick) {
               this.pickNewRoamDestination(c);
            }
         }
      }

   }

   private void pickNewRoamDestination(Companion c) {
      Location center = c.roamCenter;
      World world = center.getWorld();
      if (world == null) {
         c.roamPauseUntilTick = this.tickCounter + 40L;
      } else {
         for(int attempt = 0; attempt < 10; ++attempt) {
            double angle = ThreadLocalRandom.current().nextDouble((double)0.0F, (Math.PI * 2D));
            double dist = ThreadLocalRandom.current().nextDouble((double)0.0F, c.roamRadius);
            int bx = (int)Math.floor(center.getX() + Math.cos(angle) * dist);
            int bz = (int)Math.floor(center.getZ() + Math.sin(angle) * dist);
            Integer groundY = this.findGroundY(world, bx, bz, center.getBlockY());
            if (groundY != null) {
               c.roamDestination = new Location(world, (double)bx + (double)0.5F, (double)groundY, (double)bz + (double)0.5F);
               c.resetPath();
               return;
            }
         }

         c.roamPauseUntilTick = this.tickCounter + 20L;
      }

   }

   private Integer findGroundY(World world, int x, int z, int hintY) {
      int minY = Math.max(world.getMinHeight(), hintY - 20);
      int maxY = Math.min(world.getMaxHeight() - 1, hintY + 20);

      for(int y = maxY; y >= minY; --y) {
         if (this.isWalkable(world, x, y, z)) {
            return y;
         }
      }

      return null;
   }

   private long randomRoamPauseTicks() {
      return ThreadLocalRandom.current().nextLong(40L, 141L);
   }

   private void tickJumping(Companion c) {
      Mannequin mannequin = c.entity;
      double verticalVelocity = this.resolveVerticalVelocity(mannequin);
      if (this.tickCounter >= c.nextJumpTick && mannequin.isOnGround()) {
         c.keys.clearMovement();
         c.keys.jump = true;
         this.driveKeys(c, mannequin, mannequin.getLocation().getYaw(), verticalVelocity, 0.0, 0.0);
         c.nextJumpTick = this.tickCounter + (c.jumpRandom ? ThreadLocalRandom.current().nextLong(12L, 46L) : 20L);
      } else {
         this.stopMovement(c, mannequin, verticalVelocity);
      }

   }

   private void tickCombat(Companion c, LivingEntity target, Vector spacing) {
      this.tickCombat(c, target, spacing, false);
   }

   /**
    * Player-style melee. The bot has a real 1.9+ attack cooldown per weapon, only hits what its crosshair is on
    * and can actually see, jump-crits, sprint-hits (with W-taps), circle-strafes with A/D, keeps spacing with W/S,
    * raises its shield, and runs when hurt. {@code staggered} means it was just knocked back: it can still aim and
    * swing, but its keys are ignored so the knockback is not cancelled.
    */
   private void tickCombat(Companion c, LivingEntity target, Vector spacing, boolean staggered) {
      Mannequin mannequin = c.entity;
      Location current = mannequin.getLocation();
      Location targetLoc = target.getLocation();
      World world = current.getWorld();
      if (world == null || !world.equals(targetLoc.getWorld())) {
         if (!staggered) {
            mannequin.teleport(targetLoc);
         }

         return;
      }

      if (!current.getChunk().isLoaded() || !targetLoc.getChunk().isLoaded()) {
         return;
      }

      if (c.combatTargetId == null || !c.combatTargetId.equals(target.getUniqueId())) {
         ThreadLocalRandom r = ThreadLocalRandom.current();
         c.combatTargetId = target.getUniqueId();
         c.engageReadyTick = this.tickCounter + r.nextLong(4L, 10L);
         c.aimDelay = r.nextInt(1, 3);
         c.attackStyle = -1;
         c.readySince = Long.MIN_VALUE;
         c.critJumped = false;
         Arrays.fill(c.aimHistory, null);
      }

      if (c.attackStyle < 0) {
         this.rollNextAttackStyle(c);
      }

      double verticalVelocity = this.resolveVerticalVelocity(mannequin);
      EntityEquipment equipment = mannequin.getEquipment();
      ItemStack weapon = equipment != null ? equipment.getItemInMainHand() : null;
      double period = this.attackPeriodTicks(weapon);
      double charge = this.attackCharge(c, period);
      double flat = this.flatDistance(current, targetLoc);
      double healthFraction = mannequin.getHealth() / 40.0;

      if (healthFraction <= 0.30) {
         c.fleeing = true;
      } else if (c.fleeing && (healthFraction >= 0.55 || flat > 16.0)) {
         c.fleeing = false;
      }

      if (c.fleeing && !staggered) {
         this.lowerShieldIfUp(c, mannequin);
         if (this.tickFlee(c, mannequin, current, targetLoc, verticalVelocity)) {
            return;
         }
         // cornered: fight back
      }

      Location eye0 = mannequin.getEyeLocation();
      BoundingBox box = target.getBoundingBox();
      Vector center = box.getCenter();
      boolean sight = this.hasClearSight(world, eye0, center);
      if (!sight || flat > 6.0) {
         this.lowerShieldIfUp(c, mannequin);
         if (!staggered) {
            Location approachGoal = spacing != null ? targetLoc.clone().add(spacing) : targetLoc;
            this.moveAlongPath(c, mannequin, current, approachGoal, verticalVelocity);
         }

         return;
      }

      // ---- close combat -------------------------------------------------------------------------------
      ThreadLocalRandom random = ThreadLocalRandom.current();
      if (this.tickCounter >= c.nextAimNoiseTick) {
         c.aimNoiseYaw = random.nextDouble(-1.6, 1.6);
         c.aimNoisePitch = random.nextDouble(-1.0, 1.0);
         c.nextAimNoiseTick = this.tickCounter + random.nextLong(8L, 15L);
      }

      this.aimAt(c, mannequin, this.delayedAimPoint(c, center), 38.0F);
      Location eye = mannequin.getEyeLocation();
      double reachDist = this.eyeToBoxDistance(eye, box);
      this.tickShield(c, mannequin, equipment, charge, target, reachDist);

      boolean grounded = mannequin.isOnGround();
      boolean ready = this.tickCounter >= c.engageReadyTick && charge >= c.chargeThreshold && !c.shieldUp;
      if (ready) {
         if (c.readySince == Long.MIN_VALUE) {
            c.readySince = this.tickCounter;
         }
      }

      long waited = ready ? this.tickCounter - c.readySince : 0L;
      boolean wantsCrit = c.attackStyle == 1 && period >= 10.0 && !this.isInWater(mannequin);
      boolean sprintStyle = c.attackStyle == 2;
      boolean sprintLocked = this.tickCounter < c.sprintLockUntilTick;

      // ---- footwork: W/S for spacing, A/D for circle strafing -----------------------------------------
      if (this.tickCounter >= c.nextStrafeFlipTick) {
         if (random.nextDouble() < 0.7) {
            c.strafeDirection = -c.strafeDirection;
         }

         c.strafeIdle = random.nextDouble() < 0.2;
         c.nextStrafeFlipTick = this.tickCounter + random.nextLong(8L, 31L);
      }

      int forward = 0;
      if (flat > 2.6) {
         forward = 1;
      } else if (flat < 1.6) {
         forward = -1;
      } else if (!ready && !sprintStyle && charge < 0.5 && flat < 2.2) {
         forward = -1;
      }

      if (sprintStyle && charge >= 0.7 && flat > 1.8) {
         forward = 1;
      }

      if (sprintLocked && forward > 0) {
         forward = 0;
      }

      int strafe = c.strafeIdle ? 0 : c.strafeDirection;
      boolean sprintNow = forward > 0 && !sprintLocked && (flat > 3.2 || (sprintStyle && charge >= 0.7));
      if (wantsCrit && (!grounded || ready)) {
         sprintNow = false;
      }

      boolean wantJump = false;
      if (wantsCrit && grounded && !c.critJumped && flat < 3.8 && period - this.ticksSinceAttack(c) <= 8.0) {
         wantJump = true;
         c.critJumped = true;
      }

      if (!staggered) {
         this.setSafeKeys(c, mannequin, current, forward, strafe);
         c.keys.sprint = sprintNow && c.keys.w;
         c.keys.sneak = mannequin.isSneaking();
         boolean stepUp = false;
         if (grounded && c.keys.anyMovement()) {
            WasdMotor.wishDirection(c.keys, mannequin.getLocation().getYaw(), c.wishScratch);
            stepUp = this.isObstacleAhead(world, current, new Vector(c.wishScratch[0], (double)0.0F, c.wishScratch[1]));
         }

         c.keys.jump = wantJump || stepUp || (this.randomHopEnabled && grounded && random.nextDouble() < 0.01);
         this.driveKeys(c, mannequin, mannequin.getLocation().getYaw(), verticalVelocity, PLAYER_WALK_SPEED, SPRINT_SPEED);
      }

      // ---- the swing ----------------------------------------------------------------------------------
      boolean inReach = reachDist <= 3.0;
      boolean onTarget = inReach && this.aimRayHits(eye, box, 3.3);
      if (ready && onTarget) {
         boolean strike;
         if (!wantsCrit) {
            strike = true;
         } else if (!mannequin.isOnGround() && mannequin.getFallDistance() > 0.0F) {
            strike = true;
         } else {
            strike = waited >= 9L;
         }

         if (strike) {
            this.performAttack(c, mannequin, target, weapon, charge);
         }
      }

   }

   private void tickCombatStaggered(Companion c) {
      if (c.attacking && c.moveTargetId != null) {
         Entity te = Bukkit.getEntity(c.moveTargetId);
         if (te instanceof LivingEntity target && !target.isDead() && target.isValid()) {
            this.tickCombat(c, target, null, true);
         }
      }

   }

   private void performAttack(Companion c, Mannequin mannequin, LivingEntity target, ItemStack weapon, double charge) {
      World world = mannequin.getWorld();
      boolean fullStrength = charge > 0.9;
      boolean sprintHit = fullStrength && c.sprintingVisual;
      boolean crit = fullStrength && !mannequin.isOnGround() && mannequin.getFallDistance() > 0.0F && !c.sprintingVisual && !this.isInWater(mannequin);
      double damage = this.weaponDamage(weapon) * (0.2 + charge * charge * 0.8);
      if (crit) {
         damage *= 1.5;
      }

      c.lastAttackTick = this.tickCounter;
      c.readySince = Long.MIN_VALUE;
      c.critJumped = false;
      mannequin.swingMainHand();
      if (world != null) {
         Location hit = target.getLocation();
         if (crit) {
            world.spawnParticle(Particle.CRIT, hit.clone().add((double)0.0F, 1.0, (double)0.0F), 14, 0.3, 0.3, 0.3, 0.1);
            world.playSound(hit, Sound.ENTITY_PLAYER_ATTACK_CRIT, SoundCategory.PLAYERS, 1.0F, 1.0F);
         } else if (sprintHit) {
            world.playSound(hit, Sound.ENTITY_PLAYER_ATTACK_KNOCKBACK, SoundCategory.PLAYERS, 1.0F, 1.0F);
         } else {
            world.playSound(hit, fullStrength ? Sound.ENTITY_PLAYER_ATTACK_STRONG : Sound.ENTITY_PLAYER_ATTACK_WEAK, SoundCategory.PLAYERS, 1.0F, 1.0F);
         }
      }

      target.damage(damage, mannequin);
      if (sprintHit) {
         // vanilla sprint-knockback: extra shove for the victim, and the attacker's sprint is cancelled (hence W-taps)
         if (!this.companions.containsKey(target.getUniqueId())) {
            double yawRad = Math.toRadians((double)mannequin.getLocation().getYaw());
            target.setVelocity(target.getVelocity().add(new Vector(-Math.sin(yawRad) * 0.5, 0.1, Math.cos(yawRad) * 0.5)));
         }

         c.motorVel[0] *= 0.6;
         c.motorVel[1] *= 0.6;
         c.sprintLockUntilTick = this.tickCounter + 3L;
      }

      this.rollNextAttackStyle(c);
      ThreadLocalRandom random = ThreadLocalRandom.current();
      c.chargeThreshold = 0.92 + random.nextDouble(0.0, 0.07);
      c.shieldDefendThisCycle = random.nextDouble() < 0.55;
      if (random.nextDouble() < 0.5) {
         c.nextStrafeFlipTick = this.tickCounter;
      }

   }

   private void rollNextAttackStyle(Companion c) {
      double roll = ThreadLocalRandom.current().nextDouble();
      c.attackStyle = roll < 0.45 ? 1 : (roll < 0.75 ? 2 : 0);
   }

   private double ticksSinceAttack(Companion c) {
      return c.lastAttackTick == Long.MIN_VALUE ? 1000.0 : (double)(this.tickCounter - c.lastAttackTick);
   }

   private double attackCharge(Companion c, double periodTicks) {
      return Math.max(0.0, Math.min(1.0, (this.ticksSinceAttack(c) + 0.5) / periodTicks));
   }

   /** Ticks between full-strength swings, from each weapon's vanilla attack-speed attribute. */
   private double attackPeriodTicks(ItemStack weapon) {
      Material material = weapon == null ? Material.AIR : weapon.getType();
      String name = material.name();
      double speed;
      if (material == Material.AIR) {
         speed = 4.0;
      } else if (name.endsWith("_SWORD")) {
         speed = 1.6;
      } else if (name.endsWith("_AXE")) {
         speed = !name.startsWith("WOODEN_") && !name.startsWith("STONE_") ? (name.startsWith("IRON_") ? 0.9 : 1.0) : 0.8;
      } else if (name.endsWith("_PICKAXE")) {
         speed = 1.2;
      } else if (name.endsWith("_SHOVEL")) {
         speed = 1.0;
      } else if (name.endsWith("_HOE")) {
         speed = name.startsWith("WOODEN_") ? 1.0 : (name.startsWith("STONE_") ? 2.0 : (name.startsWith("IRON_") ? 3.0 : (name.startsWith("GOLDEN_") ? 1.0 : 4.0)));
      } else if (material == Material.TRIDENT) {
         speed = 1.1;
      } else if (material == Material.MACE) {
         speed = 0.6;
      } else {
         speed = 4.0;
      }

      return 20.0 / speed;
   }

   private double eyeToBoxDistance(Location eye, BoundingBox box) {
      double cx = Math.max(box.getMinX(), Math.min(eye.getX(), box.getMaxX()));
      double cy = Math.max(box.getMinY(), Math.min(eye.getY(), box.getMaxY()));
      double cz = Math.max(box.getMinZ(), Math.min(eye.getZ(), box.getMaxZ()));
      double dx = eye.getX() - cx;
      double dy = eye.getY() - cy;
      double dz = eye.getZ() - cz;
      return Math.sqrt(dx * dx + dy * dy + dz * dz);
   }

   private boolean aimRayHits(Location eye, BoundingBox box, double maxDistance) {
      BoundingBox padded = box.clone().expand(0.08);
      return padded.rayTrace(eye.toVector(), eye.getDirection(), maxDistance) != null;
   }

   private boolean hasClearSight(World world, Location eye, Vector to) {
      Vector line = to.clone().subtract(eye.toVector());
      double dist = line.length();
      if (dist < 0.01) {
         return true;
      }

      return world.rayTraceBlocks(eye, line.normalize(), dist, FluidCollisionMode.NEVER, true) == null;
   }

   /** Aim at where the target was a tick or two ago: humans track by sight, they do not read minds. */
   private Vector delayedAimPoint(Companion c, Vector center) {
      int size = c.aimHistory.length;
      int written = c.aimHistoryPos;
      c.aimHistory[written] = center.clone();
      c.aimHistoryPos = (written + 1) % size;
      Vector old = c.aimHistory[Math.floorMod(written - c.aimDelay, size)];
      return old != null ? old : center;
   }

   private void aimAt(Companion c, Mannequin mannequin, Vector point, float turnRateDegrees) {
      Location eye = mannequin.getEyeLocation();
      double dx = point.getX() - eye.getX();
      double dy = point.getY() - eye.getY();
      double dz = point.getZ() - eye.getZ();
      double horizontal = Math.sqrt(dx * dx + dz * dz);
      if (horizontal < 1.0E-6 && Math.abs(dy) < 1.0E-6) {
         return;
      }

      float targetYaw = (float)(Math.toDegrees(Math.atan2(-dx, dz)) + c.aimNoiseYaw);
      float targetPitch = (float)(-Math.toDegrees(Math.atan2(dy, horizontal)) + c.aimNoisePitch);
      targetPitch = Math.max(-90.0F, Math.min(90.0F, targetPitch));
      Location loc = mannequin.getLocation();
      mannequin.setRotation(this.turnToward(loc.getYaw(), targetYaw, turnRateDegrees), this.turnToward(loc.getPitch(), targetPitch, turnRateDegrees));
   }

   private boolean isWallAhead(World world, Location current, Vector direction) {
      int bx = (int)Math.floor(current.getX() + direction.getX() * 0.7);
      int bz = (int)Math.floor(current.getZ() + direction.getZ() * 0.7);
      int by = (int)Math.floor(current.getY() + 0.01);
      return !world.getBlockAt(bx, by, bz).isPassable() && !world.getBlockAt(bx, by + 1, bz).isPassable();
   }

   /** Presses the wanted keys unless they would walk the bot off an edge or into a wall; then tries safer combos. */
   private void setSafeKeys(Companion c, Mannequin mannequin, Location current, int forward, int strafe) {
      World world = mannequin.getWorld();
      float yaw = mannequin.getLocation().getYaw();
      int[][] attempts = new int[][]{{forward, strafe}, {0, strafe}, {0, -strafe}, {forward, 0}, {0, 0}};
      boolean grounded = mannequin.isOnGround();
      for (int[] attempt : attempts) {
         c.keys.setAxes(attempt[0], attempt[1]);
         if (!c.keys.anyMovement() || !grounded) {
            break;
         }

         WasdMotor.wishDirection(c.keys, yaw, c.wishScratch);
         Vector dir = new Vector(c.wishScratch[0], (double)0.0F, c.wishScratch[1]);
         if (!this.isHoleAhead(world, current, dir) && !this.isWallAhead(world, current, dir)) {
            break;
         }

         if (attempt[1] == -strafe && strafe != 0 && attempt[0] == 0) {
            c.strafeDirection = -c.strafeDirection;
         }
      }

   }

   private boolean isFacing(LivingEntity looker, Location at, double maxAngleDegrees) {
      Vector look = looker.getLocation().getDirection().setY(0);
      Vector toward = at.toVector().subtract(looker.getLocation().toVector()).setY(0);
      if (look.lengthSquared() < 1.0E-6 || toward.lengthSquared() < 1.0E-6) {
         return true;
      }

      return Math.toDegrees((double)look.angle(toward)) <= maxAngleDegrees;
   }

   private void tickShield(Companion c, Mannequin mannequin, EntityEquipment equipment, double charge, LivingEntity target, double reachDist) {
      if (equipment == null || this.tickCounter < c.eatingUntilTick) {
         return;
      }

      EquipmentSlot slot = null;
      if (equipment.getItemInOffHand().getType() == Material.SHIELD) {
         slot = EquipmentSlot.OFF_HAND;
      } else if (equipment.getItemInMainHand().getType() == Material.SHIELD) {
         slot = EquipmentSlot.HAND;
      }

      if (slot == null || this.tickCounter < c.shieldDisabledUntilTick) {
         this.lowerShieldIfUp(c, mannequin);
         return;
      }

      boolean threatened = reachDist < 4.3 && this.isFacing(target, mannequin.getLocation(), 70.0);
      boolean wantUp = c.shieldDefendThisCycle && threatened && charge < 0.8;
      if (wantUp) {
         if (!c.shieldUp) {
            if (c.shieldReactAt == Long.MIN_VALUE) {
               c.shieldReactAt = this.tickCounter + ThreadLocalRandom.current().nextLong(2L, 6L);
            }

            if (this.tickCounter >= c.shieldReactAt) {
               mannequin.startUsingItem(slot);
               c.shieldUp = true;
               c.shieldRaisedAt = this.tickCounter;
               c.shieldReactAt = Long.MIN_VALUE;
            }
         } else if (!mannequin.isHandRaised()) {
            mannequin.startUsingItem(slot);
         }
      } else {
         c.shieldReactAt = Long.MIN_VALUE;
         if (c.shieldUp && this.tickCounter - c.shieldRaisedAt >= 4L) {
            this.lowerShieldIfUp(c, mannequin);
         }
      }

   }

   private void lowerShieldIfUp(Companion c, Mannequin mannequin) {
      if (c.shieldUp) {
         c.shieldUp = false;
         c.shieldReactAt = Long.MIN_VALUE;
         if (this.tickCounter >= c.eatingUntilTick) {
            mannequin.clearActiveItem();
         }
      }

   }

   /** Runs away from the target with sprint+W, skipping directions that lead into walls or off ledges. Returns false when cornered. */
   private boolean tickFlee(Companion c, Mannequin mannequin, Location current, Location targetLoc, double verticalVelocity) {
      World world = mannequin.getWorld();
      double ax = current.getX() - targetLoc.getX();
      double az = current.getZ() - targetLoc.getZ();
      double len = Math.sqrt(ax * ax + az * az);
      if (len < 1.0E-4) {
         ax = (double)1.0F;
         az = (double)0.0F;
         len = (double)1.0F;
      }

      ax /= len;
      az /= len;
      double[] swing = new double[]{0.0, 35.0, -35.0, 70.0, -70.0};
      for (double degrees : swing) {
         double rad = Math.toRadians(degrees);
         double dx = ax * Math.cos(rad) - az * Math.sin(rad);
         double dz = ax * Math.sin(rad) + az * Math.cos(rad);
         Vector dir = new Vector(dx, (double)0.0F, dz);
         if (!this.isHoleAhead(world, current, dir) && !this.isWallAhead(world, current, dir)) {
            c.fleeBlockedTicks = 0;
            Location goal = new Location(world, current.getX() + dx * 6.0, current.getY(), current.getZ() + dz * 6.0);
            this.moveToward(c, mannequin, current, goal, verticalVelocity, 5.0);
            return true;
         }
      }

      ++c.fleeBlockedTicks;
      return false;
   }

   private void faceTarget(Mannequin mannequin, Location current, Location targetLoc) {
      this.faceTarget(mannequin, current, targetLoc, 38.0F);
   }

   private void faceTarget(Mannequin mannequin, Location current, Location targetLoc, float turnRateDegrees) {
      double dx = targetLoc.getX() - current.getX();
      double dz = targetLoc.getZ() - current.getZ();
      double horizontalDist = Math.sqrt(dx * dx + dz * dz);
      double dy = targetLoc.getY() + 1.4 - (current.getY() + 1.4);
      if (dx != (double)0.0F || dz != (double)0.0F) {
         Location loc = mannequin.getLocation();
         float targetYaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
         float newYaw = this.turnToward(loc.getYaw(), targetYaw, turnRateDegrees);
         float targetPitch = (float)(-Math.toDegrees(Math.atan2(dy, horizontalDist)));
         float clampedTargetPitch = Math.max(-90.0F, Math.min(90.0F, targetPitch));
         float pitchDelta = clampedTargetPitch - loc.getPitch();
         float cappedPitchDelta = Math.max(-turnRateDegrees, Math.min(turnRateDegrees, pitchDelta));
         float newPitch = loc.getPitch() + cappedPitchDelta;
         mannequin.setRotation(newYaw, newPitch);
      }

   }

   private Player findWatchingPlayer(Mannequin mannequin) {
      World world = mannequin.getWorld();
      if (world == null) {
         return null;
      } else {
         Location head = mannequin.getEyeLocation();
         List<Entity> nearby = mannequin.getNearbyEntities((double)12.0F, (double)12.0F, (double)12.0F);
         List<Player> candidates = null;
         double[] angles = null;
         int count = 0;

         for(Entity e : nearby) {
            if (e instanceof Player) {
               Player p = (Player)e;
               if (p.isValid() && !p.isDead() && p.getGameMode() != GameMode.SPECTATOR) {
                  Location eye = p.getEyeLocation();
                  if (!(eye.distanceSquared(head) > (double)144.0F)) {
                     Vector toMannequin = head.toVector().subtract(eye.toVector());
                     if (!(toMannequin.lengthSquared() < 1.0E-6)) {
                        double angle = Math.toDegrees((double)eye.getDirection().normalize().angle(toMannequin));
                        if (!(angle >= (double)10.0F)) {
                           if (candidates == null) {
                              candidates = new ArrayList(4);
                              angles = new double[4];
                           }

                           if (count == angles.length) {
                              angles = Arrays.copyOf(angles, angles.length * 2);
                           }

                           candidates.add(p);
                           angles[count++] = angle;
                        }
                     }
                  }
               }
            }
         }

         if (candidates == null) {
            return null;
         } else {
            for(int i = 0; i < count; ++i) {
               int minIdx = i;

               for(int j = i + 1; j < count; ++j) {
                  if (angles[j] < angles[minIdx]) {
                     minIdx = j;
                  }
               }

               if (minIdx != i) {
                  double tmpAngle = angles[i];
                  angles[i] = angles[minIdx];
                  angles[minIdx] = tmpAngle;
                  Player tmpPlayer = (Player)candidates.get(i);
                  candidates.set(i, (Player)candidates.get(minIdx));
                  candidates.set(minIdx, tmpPlayer);
               }

               if (((Player)candidates.get(i)).hasLineOfSight(mannequin)) {
                  return (Player)candidates.get(i);
               }
            }

            return null;
         }
      }
   }

   private void applyLookAtTracking(Companion c) {
      try {
         if (this.tickCounter >= c.nextWatcherScanTick) {
            c.cachedWatcher = this.findWatchingPlayer(c.entity);
            long stagger = Math.floorMod((long)c.entity.getEntityId(), 4L);
            c.nextWatcherScanTick = this.tickCounter + 4L + stagger;
         }

         Player watcher = c.cachedWatcher;
         if (watcher != null && watcher.isValid() && !watcher.isDead()) {
            this.faceTarget(c.entity, c.entity.getLocation(), watcher.getLocation(), 25.0F);
         }
      } catch (Exception e) {
         Bukkit.getLogger().severe("[RppCommand] Look-at error: " + e.getMessage());
      }

   }

   private double weaponDamage(ItemStack weapon) {
      if (weapon != null && weapon.getType() != Material.AIR) {
         Material material = weapon.getType();
         String name = material.name();
         String tier = this.tierOf(name);
         double damage;
         if (name.endsWith("_SWORD")) {
            damage = (double)4.0F + (Double)TIER_DAMAGE_BONUS.getOrDefault(tier, (double)0.0F);
         } else if (name.endsWith("_AXE")) {
            damage = (double)7.0F + (Double)AXE_DAMAGE_BONUS.getOrDefault(tier, (double)0.0F);
         } else if (name.endsWith("_PICKAXE")) {
            damage = (double)2.0F + (Double)TIER_DAMAGE_BONUS.getOrDefault(tier, (double)0.0F);
         } else if (name.endsWith("_SHOVEL")) {
            damage = (double)2.5F + (Double)TIER_DAMAGE_BONUS.getOrDefault(tier, (double)0.0F);
         } else if (name.endsWith("_HOE")) {
            damage = (double)1.0F;
         } else if (material == Material.TRIDENT) {
            damage = (double)9.0F;
         } else if (material == Material.MACE) {
            damage = (double)5.0F;
         } else {
            damage = (double)1.0F;
         }

         int sharpness = weapon.getEnchantmentLevel(Enchantment.SHARPNESS);
         if (sharpness > 0) {
            damage += (double)0.5F + (double)0.5F * (double)sharpness;
         }

         return damage;
      } else {
         return (double)1.0F;
      }
   }

   private String tierOf(String materialName) {
      for(String tier : TOOL_TIERS) {
         if (materialName.startsWith(tier + "_")) {
            return tier;
         }
      }

      return null;
   }

   private void moveAlongPath(Companion c, Mannequin mannequin, Location current, Location destination, double verticalVelocity) {
      double distanceToGoal = this.flatDistance(current, destination);
      if (c.currentPath != null && !c.currentPath.isEmpty()) {
         if (c.pathIndex >= c.currentPath.size()) {
            this.stopMovement(c, mannequin, verticalVelocity);
         } else {
            Location waypoint = (Location)c.currentPath.get(c.pathIndex);
            // Advance when we reach the node OR when we have already run past it (cutting a corner), so the bot
            // never circles back to hit a node exactly and never has to stop and pivot.
            while (c.pathIndex < c.currentPath.size()) {
               waypoint = (Location)c.currentPath.get(c.pathIndex);
               if (this.flatDistance(current, waypoint) < 0.6) {
                  ++c.pathIndex;
               } else if (c.pathIndex + 1 < c.currentPath.size() && this.flatDistance(current, waypoint) < 1.6 && this.hasPassedNode(current, waypoint, (Location)c.currentPath.get(c.pathIndex + 1))) {
                  ++c.pathIndex;
               } else {
                  break;
               }
            }

            if (c.pathIndex >= c.currentPath.size()) {
               this.stopMovement(c, mannequin, verticalVelocity);
               return;
            }

            if (this.debugPathEnabled) {
               this.showPathDebug(c, mannequin);
            }

            Location steerTarget = this.lookAheadPoint(c, current);
            this.moveTowardWasd(c, mannequin, current, steerTarget != null ? steerTarget : waypoint, waypoint, verticalVelocity, distanceToGoal);
         }
      } else {
         this.moveTowardWasd(c, mannequin, current, destination, null, verticalVelocity, distanceToGoal);
      }

   }

   private boolean hasPassedNode(Location current, Location node, Location next) {
      double segX = next.getX() - node.getX();
      double segZ = next.getZ() - node.getZ();
      double toNodeX = node.getX() - current.getX();
      double toNodeZ = node.getZ() - current.getZ();
      return segX * toNodeX + segZ * toNodeZ < 0.0;
   }

   private Location lookAheadPoint(Companion c, Location current) {
      List<Location> path = c.currentPath;
      if (path != null && c.pathIndex < path.size()) {
         Location prev = current;
         double remaining = (double)2.75F;
         Location last = null;

         for(int i = c.pathIndex; i < path.size(); ++i) {
            Location next = (Location)path.get(i);
            double segDist = this.flatDistance(prev, next);
            if (segDist < 1.0E-6) {
               prev = next;
               last = next;
            } else {
               if (segDist >= remaining) {
                  double t = remaining / segDist;
                  return new Location(current.getWorld(), prev.getX() + (next.getX() - prev.getX()) * t, prev.getY() + (next.getY() - prev.getY()) * t, prev.getZ() + (next.getZ() - prev.getZ()) * t);
               }

               remaining -= segDist;
               prev = next;
               last = next;
            }
         }

         return last;
      } else {
         return null;
      }
   }

   private void showPathDebug(Companion c, Mannequin mannequin) {
      if (c.currentPath != null && this.tickCounter % 5L == 0L) {
         World world = mannequin.getWorld();

         for(int i = c.pathIndex; i < c.currentPath.size(); ++i) {
            Location point = ((Location)c.currentPath.get(i)).clone().add((double)0.0F, 0.1, (double)0.0F);
            world.spawnParticle(Particle.FLAME, point, 1, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F);
         }
      }

   }

   private void moveTowardAtSpeed(Companion c, Mannequin mannequin, Location current, Location destination, double verticalVelocity, double targetSpeed) {
      double dx = destination.getX() - current.getX();
      double dz = destination.getZ() - current.getZ();
      double horizontalDistance = Math.sqrt(dx * dx + dz * dz);
      if (horizontalDistance < 0.05) {
         this.stopMovement(c, mannequin, verticalVelocity);
      } else {
         float yaw = mannequin.getLocation().getYaw();
         WasdMotor.chooseKeys(c.keys, dx, dz, yaw);
         c.keys.sprint = false;
         c.keys.sneak = mannequin.isSneaking();
         this.driveKeys(c, mannequin, yaw, verticalVelocity, targetSpeed, targetSpeed);
      }

   }

   private void moveToward(Companion c, Mannequin mannequin, Location current, Location destination, double verticalVelocity, double distanceToFinalTarget) {
      this.moveTowardWasd(c, mannequin, current, destination, null, verticalVelocity, distanceToFinalTarget);
   }

   /**
    * Walks toward a point by pressing W/A/S/D. The body turns toward the heading at a human rate, but the keys
    * are chosen against the body's CURRENT yaw, so while the bot is still turning it keeps moving with A/D/S
    * instead of stopping to pivot. {@code fallbackWaypoint} is the exact path node used when a look-ahead point
    * that cuts a corner would send the bot over an edge.
    */
   private void moveTowardWasd(Companion c, Mannequin mannequin, Location current, Location destination, Location fallbackWaypoint, double verticalVelocity, double distanceToFinalTarget) {
      double dx = destination.getX() - current.getX();
      double dz = destination.getZ() - current.getZ();
      double horizontalDistance = Math.sqrt(dx * dx + dz * dz);
      if (horizontalDistance < 0.05) {
         this.stopMovement(c, mannequin, verticalVelocity);
         return;
      }

      World world = mannequin.getWorld();
      this.tryOpenDoorTowards(world, current, destination);
      Vector direction = (new Vector(dx, (double)0.0F, dz)).normalize();
      boolean grounded = mannequin.isOnGround();
      boolean deliberateDrop = destination.getY() < current.getY() - 0.5;
      if (grounded && !deliberateDrop && this.isHoleAhead(world, current, direction)) {
         boolean recovered = false;
         if (fallbackWaypoint != null) {
            double fx = fallbackWaypoint.getX() - current.getX();
            double fz = fallbackWaypoint.getZ() - current.getZ();
            double fl = Math.sqrt(fx * fx + fz * fz);
            if (fl > 0.05) {
               Vector fallbackDir = new Vector(fx / fl, (double)0.0F, fz / fl);
               if (!this.isHoleAhead(world, current, fallbackDir) || fallbackWaypoint.getY() < current.getY() - 0.5) {
                  direction = fallbackDir;
                  destination = fallbackWaypoint;
                  recovered = true;
               }
            }
         }

         if (!recovered) {
            this.stopMovement(c, mannequin, verticalVelocity);
            return;
         }
      }

      double pace = this.paceScale(c, mannequin, distanceToFinalTarget);
      double ownSpeed = Math.sqrt(c.motorVel[0] * c.motorVel[0] + c.motorVel[1] * c.motorVel[1]);
      double brakingDistance = ownSpeed * ownSpeed / Math.max(0.01, 0.34);
      if (distanceToFinalTarget < brakingDistance + 0.65) {
         double ratio = Math.max(0.08, Math.min((double)1.0F, distanceToFinalTarget / Math.max(0.65, brakingDistance + 0.65)));
         pace *= ratio;
      }

      if (this.tickCounter >= c.nextHumanCorrectionTick) {
         ThreadLocalRandom r = ThreadLocalRandom.current();
         c.humanNoiseX = r.nextDouble(-0.035, 0.035);
         c.humanNoiseZ = r.nextDouble(-0.035, 0.035);
         c.nextHumanCorrectionTick = this.tickCounter + 7L + r.nextLong(0L, 5L);
      }

      Vector desiredDirection = direction.clone();
      desiredDirection.setX(desiredDirection.getX() + c.humanNoiseX * 0.2);
      desiredDirection.setZ(desiredDirection.getZ() + c.humanNoiseZ * 0.2);
      desiredDirection.normalize();

      Location here = mannequin.getLocation();
      float targetYaw = (float)Math.toDegrees(Math.atan2(-desiredDirection.getX(), desiredDirection.getZ()));
      float yawDelta = Math.abs(this.wrapDegrees(targetYaw - here.getYaw()));
      float turnRate = yawDelta > 90.0F ? 28.0F : (yawDelta > 35.0F ? 14.0F : 7.0F);
      float newYaw = this.turnToward(here.getYaw(), targetYaw, turnRate);
      double dy = destination.getY() - current.getY();
      float footingPitch = (float)Math.max((double)-20.0F, Math.min((double)20.0F, -dy * (double)25.0F));
      float newPitch = this.turnToward(here.getPitch(), footingPitch, 6.0F);
      mannequin.setRotation(newYaw, newPitch);

      c.keys.sneak = mannequin.isSneaking();
      c.keys.sprint = this.wantsSprintPace(c, mannequin);
      WasdMotor.chooseKeys(c.keys, desiredDirection.getX(), desiredDirection.getZ(), newYaw);

      boolean needsStepUp = grounded && (destination.getY() > current.getY() + (double)0.5F || this.isObstacleAhead(world, current, direction));
      boolean randomHop = this.randomHopEnabled && !needsStepUp && grounded && ThreadLocalRandom.current().nextDouble() < 0.015;
      c.keys.jump = needsStepUp || randomHop;

      this.driveKeys(c, mannequin, newYaw, verticalVelocity, PLAYER_WALK_SPEED * pace, SPRINT_SPEED * pace);
      c.humanTargetYaw = targetYaw;
      c.humanHasTargetYaw = true;
   }

   /**
    * The single place where W/A/S/D turn into motion. Every walking mode (paths, follow, formation, patrol, roam,
    * combat footwork, build walking, mid-air steering) goes through here.
    * Sprinting needs W held (like the real game); direction changes are absorbed by grip, not by stopping.
    */
   private void driveKeys(Companion c, Mannequin mannequin, float yaw, double verticalVelocity, double walkSpeed, double sprintSpeed) {
      WasdKeys keys = c.keys;
      boolean grounded = mannequin.isOnGround();
      Vector real = mannequin.getVelocity();
      double realLen = Math.sqrt(real.getX() * real.getX() + real.getZ() * real.getZ());
      double ownLen = Math.sqrt(c.motorVel[0] * c.motorVel[0] + c.motorVel[1] * c.motorVel[1]);
      // Re-sync with the world when something else moved us (knockback, pearl, teleport) or we ran into a wall.
      if (this.tickCounter - c.lastMotorTick > 1L || (grounded && ownLen > 0.15 && realLen < ownLen * 0.3)) {
         c.motorVel[0] = real.getX();
         c.motorVel[1] = real.getZ();
      }

      c.lastMotorTick = this.tickCounter;
      boolean sprinting = keys.sprint && keys.w && !keys.sneak && this.tickCounter >= c.sprintLockUntilTick;
      double speed = sprinting ? sprintSpeed : walkSpeed;
      boolean held = keys.anyMovement() && speed > 0.0;
      double[] wish = c.wishScratch;
      if (held) {
         WasdMotor.wishDirection(keys, yaw, wish);
      } else {
         wish[0] = 0.0;
         wish[1] = 0.0;
      }

      WasdMotor.integrate(c.motorVel, wish, speed, grounded, held);
      double vy = verticalVelocity;
      if ((keys.jump || c.forceJump) && grounded && !this.isInWater(mannequin)) {
         vy = 0.42;
         if (sprinting && held) {
            c.motorVel[0] += wish[0] * 0.2;
            c.motorVel[1] += wish[1] * 0.2;
         }
      }

      keys.jump = false;
      c.forceJump = false;
      mannequin.setVelocity(new Vector(c.motorVel[0], vy, c.motorVel[1]));
      if (c.sprintingVisual != sprinting) {
         c.sprintingVisual = sprinting;
         this.setMannequinSprinting(mannequin, sprinting);
      }

   }

   private boolean isObstacleAhead(World world, Location current, Vector direction) {
      double aheadX = current.getX() + direction.getX() * 0.6;
      double aheadZ = current.getZ() + direction.getZ() * 0.6;
      int bx = (int)Math.floor(aheadX);
      int by = (int)Math.floor(current.getY() + 0.01);
      int bz = (int)Math.floor(aheadZ);
      Material feetLevel = world.getBlockAt(bx, by, bz).getType();
      if (feetLevel.isSolid() && !this.isOpenableDoor(feetLevel)) {
         Material headLevel = world.getBlockAt(bx, by + 1, bz).getType();
         Material aboveHeadLevel = world.getBlockAt(bx, by + 2, bz).getType();
         return !headLevel.isSolid() && !aboveHeadLevel.isSolid();
      } else {
         return false;
      }
   }

   private boolean isHoleAhead(World world, Location current, Vector direction) {
      double aheadX = current.getX() + direction.getX() * 0.6;
      double aheadZ = current.getZ() + direction.getZ() * 0.6;
      int bx = (int)Math.floor(aheadX);
      int bz = (int)Math.floor(aheadZ);
      int by = (int)Math.floor(current.getY() + 0.01);

      for(int checkY = by; checkY > by - 3; --checkY) {
         Material block = world.getBlockAt(bx, checkY, bz).getType();
         if (this.isHazard(block)) {
            return true;
         }

         if (block.isSolid()) {
            return false;
         }
      }

      return true;
   }

   private void stopMovement(Companion c, Mannequin mannequin, double verticalVelocity) {
      c.keys.clearMovement();
      this.driveKeys(c, mannequin, mannequin.getLocation().getYaw(), verticalVelocity, 0.0, 0.0);
   }

   private boolean wantsSprintPace(Companion c, Mannequin mannequin) {
      boolean activelyChasing = c.following || c.attacking;
      return (activelyChasing || this.alwaysSprintEnabled) && !mannequin.isSneaking();
   }

   private double paceScale(Companion c, Mannequin mannequin, double distanceToFinalTarget) {
      boolean activelyChasing = c.following || c.attacking;
      double scale = 1.0;
      if (activelyChasing && distanceToFinalTarget > (double)10.0F) {
         double overshoot = Math.min(distanceToFinalTarget - (double)10.0F, (double)20.0F);
         // catch-up speed boost removed: bots stay at vanilla player speed
      }

      if (mannequin.isSneaking()) {
         scale *= 0.3;
      } else if (this.isInWater(mannequin)) {
         scale *= 0.3;
      }

      return scale;
   }

   private static Object craftHandle(Entity entity) throws ReflectiveOperationException {
      Method getHandle = entity.getClass().getMethod("getHandle");
      return getHandle.invoke(entity);
   }

   private void setMannequinSprinting(Mannequin mannequin, boolean sprinting) {
      if (!setSharedFlagResolutionFailed) {
         try {
            Object handle = craftHandle(mannequin);
            Method method = setSharedFlagMethod;
            if (method == null) {
               method = findDeclaredMethod(handle.getClass(), "setSharedFlag", Integer.TYPE, Boolean.TYPE);
               method.setAccessible(true);
               setSharedFlagMethod = method;
            }

            method.invoke(handle, 3, sprinting);
         } catch (Exception e) {
            setSharedFlagResolutionFailed = true;
            Bukkit.getLogger().info("[RppCommand] Couldn't set the sprint animation flag on this server build (" + String.valueOf(e) + ") - mannequins will still move at sprint speed, just without the client-side sprint animation.");
         }
      }

   }

   private static Method findDeclaredMethod(Class<?> type, String name, Class<?>... paramTypes) throws NoSuchMethodException {
      for(Class<?> c = type; c != null; c = c.getSuperclass()) {
         try {
            return c.getDeclaredMethod(name, paramTypes);
         } catch (NoSuchMethodException ignored) {
            // Continue searching parent classes.
         }
      }

      String var10002 = type.getName();
      throw new NoSuchMethodException(var10002 + "#" + name);
   }

   private boolean isInWater(Mannequin mannequin) {
      Location loc = mannequin.getLocation();
      World world = loc.getWorld();
      if (world == null) {
         return false;
      } else if (world.getBlockAt(loc.getBlockX(), loc.getBlockY(), loc.getBlockZ()).getType() == Material.WATER) {
         return true;
      } else {
         Location eye = loc.clone().add((double)0.0F, mannequin.getEyeHeight(), (double)0.0F);
         return world.getBlockAt(eye.getBlockX(), eye.getBlockY(), eye.getBlockZ()).getType() == Material.WATER;
      }
   }

   private double resolveVerticalVelocity(Mannequin mannequin) {
      double gravityVelocity = mannequin.getVelocity().getY();
      if (!this.isInWater(mannequin)) {
         return gravityVelocity;
      } else {
         Location loc = mannequin.getLocation();
         World world = loc.getWorld();
         if (world == null) {
            return gravityVelocity;
         } else {
            int bx = loc.getBlockX();
            int bz = loc.getBlockZ();

            int surfaceY;
            for(surfaceY = loc.getBlockY(); world.getBlockAt(bx, surfaceY + 1, bz).getType() == Material.WATER; ++surfaceY) {
            }

            double targetY = (double)surfaceY + (double)1.0F;
            double diff = targetY - loc.getY();
            if (diff > 0.1) {
               return Math.min(diff, 0.04);
            } else {
               return diff < -0.1 ? Math.max(diff, -0.04) : (double)0.0F;
            }
         }
      }
   }

   private float turnToward(float currentYaw, float targetYaw, float maxDelta) {
      float delta = this.wrapDegrees(targetYaw - currentYaw);
      return Math.abs(delta) <= maxDelta ? this.wrapDegrees(targetYaw) : this.wrapDegrees(currentYaw + Math.copySign(maxDelta, delta));
   }

   private float wrapDegrees(float degrees) {
      float wrapped = degrees % 360.0F;
      if (wrapped >= 180.0F) {
         wrapped -= 360.0F;
      } else if (wrapped < -180.0F) {
         wrapped += 360.0F;
      }

      return wrapped;
   }

   private double flatDistance(Location a, Location b) {
      double dx = a.getX() - b.getX();
      double dz = a.getZ() - b.getZ();
      return Math.sqrt(dx * dx + dz * dz);
   }

   private void tryOpenDoorTowards(World world, Location current, Location destination) {
      int cx = current.getBlockX();
      int cy = current.getBlockY();
      int cz = current.getBlockZ();
      this.openDoorIfClosed(world, cx, cy, cz);
      this.openDoorIfClosed(world, cx, cy + 1, cz);
      int dx = destination.getBlockX();
      int dy = destination.getBlockY();
      int dz = destination.getBlockZ();
      if (dx != cx || dz != cz) {
         this.openDoorIfClosed(world, dx, dy, dz);
         this.openDoorIfClosed(world, dx, dy + 1, dz);
      }

   }

   private Location clampToWorldBorder(Location loc) {
      World world = loc.getWorld();
      if (world == null) {
         return loc;
      } else {
         WorldBorder border = world.getWorldBorder();
         double half = Math.max((double)2.0F, border.getSize() / (double)2.0F - (double)1.5F);
         Location center = border.getCenter();
         double minX = center.getX() - half;
         double maxX = center.getX() + half;
         double minZ = center.getZ() - half;
         double maxZ = center.getZ() + half;
         double x = Math.min(Math.max(loc.getX(), minX), maxX);
         double z = Math.min(Math.max(loc.getZ(), minZ), maxZ);
         return x == loc.getX() && z == loc.getZ() ? loc : new Location(world, x, loc.getY(), z);
      }
   }

   private List<Location> findPath(Location startLoc, Location goalLoc) {
      World world = startLoc.getWorld();
      if (world != null && world.equals(goalLoc.getWorld())) {
         goalLoc = this.clampToWorldBorder(goalLoc);
         if (startLoc.distance(goalLoc) > (double)32.0F) {
            return null;
         } else {
            int sx = startLoc.getBlockX();
            int sy = startLoc.getBlockY();
            int sz = startLoc.getBlockZ();
            int gx = goalLoc.getBlockX();
            int gy = goalLoc.getBlockY();
            int gz = goalLoc.getBlockZ();
            PathNode startNode = new PathNode(sx, sy, sz);
            startNode.g = (double)0.0F;
            startNode.f = this.heuristic(sx, sy, sz, gx, gy, gz);
            PriorityQueue<PathNode> open = new PriorityQueue<PathNode>(Comparator.comparingDouble((PathNode n) -> n.f));
            Map<Long, Double> bestG = new HashMap();
            Set<Long> closed = new HashSet();
            open.add(startNode);
            bestG.put(this.encode(sx, sy, sz), (double)0.0F);
            PathNode goalNode = null;
            PathNode bestNode = startNode;
            double bestH = this.heuristic(sx, sy, sz, gx, gy, gz);
            int expansions = 0;

            while(!open.isEmpty() && expansions < 3000) {
               PathNode current = (PathNode)open.poll();
               long currentKey = this.encode(current.x, current.y, current.z);
               if (!closed.contains(currentKey)) {
                  closed.add(currentKey);
                  ++expansions;
                  double currentH = this.heuristic(current.x, current.y, current.z, gx, gy, gz);
                  if (currentH < bestH) {
                     bestH = currentH;
                     bestNode = current;
                  }

                  if (Math.abs(current.x - gx) <= 1 && Math.abs(current.y - gy) <= 1 && Math.abs(current.z - gz) <= 1) {
                     goalNode = current;
                     break;
                  }

                  for(int[] offset : HORIZONTAL_OFFSETS) {
                     int dxOff = offset[0];
                     int dzOff = offset[1];

                     for(int dy = -1; dy <= 1; ++dy) {
                        int nx = current.x + dxOff;
                        int ny = current.y + dy;
                        int nz = current.z + dzOff;
                        if (this.isWalkable(world, nx, ny, nz) && (dxOff == 0 || dzOff == 0 || this.isWalkable(world, current.x + dxOff, ny, current.z) && this.isWalkable(world, current.x, ny, current.z + dzOff))) {
                           long key = this.encode(nx, ny, nz);
                           if (!closed.contains(key)) {
                              double moveCost = dxOff != 0 && dzOff != 0 ? 1.4142 : (double)1.0F;
                              if (dy > 0) {
                                 moveCost += 0.6;
                              } else if (dy < 0) {
                                 moveCost += 0.2;
                              }

                              moveCost += this.terrainPenalty(world, nx, ny, nz);
                              double tentativeG = current.g + moveCost;
                              Double knownG = (Double)bestG.get(key);
                              if (knownG == null || !(tentativeG >= knownG)) {
                                 PathNode neighbor = new PathNode(nx, ny, nz);
                                 neighbor.g = tentativeG;
                                 neighbor.f = tentativeG + this.heuristic(nx, ny, nz, gx, gy, gz);
                                 neighbor.parent = current;
                                 bestG.put(key, tentativeG);
                                 open.add(neighbor);
                              }
                           }
                        }
                     }
                  }

                  for(int[] jump : JUMP_OFFSETS) {
                     int jdx = jump[0] / 2;
                     int jdz = jump[1] / 2;
                     int midX = current.x + jdx;
                     int midZ = current.z + jdz;
                     int farX = current.x + jump[0];
                     int farZ = current.z + jump[1];
                     if (!this.isWalkable(world, midX, current.y, midZ) && (this.isWalkable(world, midX, current.y + 1, midZ) || world.getBlockAt(midX, current.y + 1, midZ).isEmpty()) && this.isWalkable(world, farX, current.y, farZ)) {
                        long jumpKey = this.encode(farX, current.y, farZ);
                        if (!closed.contains(jumpKey)) {
                           double tentativeJumpG = current.g + 1.8 + this.terrainPenalty(world, farX, current.y, farZ);
                           Double knownJumpG = (Double)bestG.get(jumpKey);
                           if (knownJumpG == null || !(tentativeJumpG >= knownJumpG)) {
                              PathNode jumpNeighbor = new PathNode(farX, current.y, farZ);
                              jumpNeighbor.g = tentativeJumpG;
                              jumpNeighbor.f = tentativeJumpG + this.heuristic(farX, current.y, farZ, gx, gy, gz);
                              jumpNeighbor.parent = current;
                              bestG.put(jumpKey, tentativeJumpG);
                              open.add(jumpNeighbor);
                           }
                        }
                     }
                  }

                  for(int[] offset : CARDINAL_OFFSETS) {
                     int dxOff = offset[0];
                     int dzOff = offset[1];
                     int nx = current.x + dxOff;
                     int nz = current.z + dzOff;
                     if (!this.isWalkable(world, nx, current.y, nz) && !this.isWalkable(world, nx, current.y - 1, nz) && !this.isWalkable(world, nx, current.y + 1, nz)) {
                        for(int fall = 2; fall <= 3; ++fall) {
                           int ny = current.y - fall;
                           boolean blocked = false;

                           for(int checkY = current.y; checkY > ny; --checkY) {
                              if (world.getBlockAt(nx, checkY, nz).getType().isSolid()) {
                                 blocked = true;
                                 break;
                              }
                           }

                           if (blocked) {
                              break;
                           }

                           if (this.isWalkable(world, nx, ny, nz)) {
                              long dropKey = this.encode(nx, ny, nz);
                              if (closed.contains(dropKey)) {
                                 break;
                              }

                              double tentativeDropG = current.g + (double)1.0F + 0.15 * (double)fall + this.terrainPenalty(world, nx, ny, nz);
                              Double knownDropG = (Double)bestG.get(dropKey);
                              if (knownDropG == null || !(tentativeDropG >= knownDropG)) {
                                 PathNode dropNeighbor = new PathNode(nx, ny, nz);
                                 dropNeighbor.g = tentativeDropG;
                                 dropNeighbor.f = tentativeDropG + this.heuristic(nx, ny, nz, gx, gy, gz);
                                 dropNeighbor.parent = current;
                                 bestG.put(dropKey, tentativeDropG);
                                 open.add(dropNeighbor);
                              }
                              break;
                           }
                        }
                     }
                  }
               }
            }

            PathNode resultNode = goalNode != null ? goalNode : bestNode;
            if (resultNode == startNode) {
               return null;
            } else {
               List<Location> path = new ArrayList();

               for(PathNode walker = resultNode; walker != null; walker = walker.parent) {
                  path.add(new Location(world, (double)walker.x + (double)0.5F, (double)walker.y, (double)walker.z + (double)0.5F));
               }

               Collections.reverse(path);
               if (!path.isEmpty()) {
                  path.remove(0);
               }

               return this.smoothPath(world, startLoc, path);
            }
         }
      } else {
         return null;
      }
   }

   private List<Location> smoothPath(World world, Location start, List<Location> path) {
      if (path.size() <= 2) {
         return path;
      } else {
         List<Location> smoothed = new ArrayList();
         Location anchor = start;

         int farthest;
         for(int i = 0; i < path.size(); i = farthest + 1) {
            farthest = i;

            for(int j = path.size() - 1; j > i; --j) {
               if (this.hasClearLine(world, anchor, (Location)path.get(j))) {
                  farthest = j;
                  break;
               }
            }

            smoothed.add((Location)path.get(farthest));
            anchor = (Location)path.get(farthest);
         }

         return smoothed;
      }
   }

   private boolean hasClearLine(World world, Location from, Location to) {
      if (Math.abs(from.getY() - to.getY()) > (double)1.0F) {
         return false;
      } else {
         double dx = to.getX() - from.getX();
         double dz = to.getZ() - from.getZ();
         double distance = Math.sqrt(dx * dx + dz * dz);
         if (distance < 1.0E-6) {
            return true;
         } else {
            int samples = Math.max(1, (int)Math.ceil(distance / (double)0.5F));
            int y = (int)Math.floor(Math.min(from.getY(), to.getY()));

            for(int s = 1; s <= samples; ++s) {
               double t = (double)s / (double)samples;
               int x = (int)Math.floor(from.getX() + dx * t);
               int z = (int)Math.floor(from.getZ() + dz * t);
               if (!this.isWalkable(world, x, y, z) && !this.isWalkable(world, x, y + 1, z)) {
                  return false;
               }
            }

            return true;
         }
      }
   }

   private double heuristic(int x1, int y1, int z1, int x2, int y2, int z2) {
      double dx = (double)(x2 - x1);
      double dy = (double)(y2 - y1);
      double dz = (double)(z2 - z1);
      return Math.sqrt(dx * dx + dy * dy + dz * dz);
   }

   private boolean isWalkable(World world, int x, int y, int z) {
      if (!world.isChunkLoaded(x >> 4, z >> 4)) {
         return false;
      } else {
         Material floor = world.getBlockAt(x, y - 1, z).getType();
         Material feet = world.getBlockAt(x, y, z).getType();
         Material head = world.getBlockAt(x, y + 1, z).getType();
         if (!floor.isSolid()) {
            return false;
         } else if ((!feet.isSolid() || this.isOpenableDoor(feet)) && (!head.isSolid() || this.isOpenableDoor(head))) {
            return !this.isHazard(floor) && !this.isHazard(feet);
         } else {
            return false;
         }
      }
   }

   private boolean isOpenableDoor(Material material) {
      if (material != Material.IRON_DOOR && material != Material.IRON_TRAPDOOR) {
         String name = material.name();
         return name.endsWith("_DOOR") || name.endsWith("_GATE") || name.endsWith("_TRAPDOOR");
      } else {
         return false;
      }
   }

   private void openDoorIfClosed(World world, int x, int y, int z) {
      Block block = world.getBlockAt(x, y, z);
      if (this.isOpenableDoor(block.getType())) {
         BlockData data = block.getBlockData();
         if (data instanceof Openable) {
            Openable openable = (Openable)data;
            if (!openable.isOpen()) {
               openable.setOpen(true);
               block.setBlockData(data);
               if (data instanceof Door && data instanceof Bisected) {
                  Bisected bisected = (Bisected)data;
                  Block otherHalf = bisected.getHalf() == Half.BOTTOM ? block.getRelative(BlockFace.UP) : block.getRelative(BlockFace.DOWN);
                  BlockData otherData = otherHalf.getBlockData();
                  if (otherData instanceof Door) {
                     Door otherDoor = (Door)otherData;
                     if (!otherDoor.isOpen()) {
                        otherDoor.setOpen(true);
                        otherHalf.setBlockData(otherData);
                     }
                  }
               }

               String name = block.getType().name();
               Sound sound = name.endsWith("_GATE") ? Sound.BLOCK_FENCE_GATE_OPEN : (name.endsWith("_TRAPDOOR") ? Sound.BLOCK_WOODEN_TRAPDOOR_OPEN : Sound.BLOCK_WOODEN_DOOR_OPEN);
               world.playSound(block.getLocation(), sound, SoundCategory.BLOCKS, 1.0F, 1.0F);
               return;
            }
         }
      }

   }

   private double terrainPenalty(World world, int x, int y, int z) {
      double penalty = (double)0.0F;
      Material feet = world.getBlockAt(x, y, z).getType();
      if (feet == Material.WATER) {
         penalty += (double)4.0F;
      }

      if (world.getBlockAt(x, y - 1, z).getType().name().contains("LEAVES")) {
         penalty += (double)2.0F;
      }

      if (this.isOpenableDoor(feet)) {
         BlockData data = world.getBlockAt(x, y, z).getBlockData();
         if (data instanceof Openable) {
            Openable openable = (Openable)data;
            if (!openable.isOpen()) {
               penalty += (double)0.5F;
            }
         }
      }

      for(int[] side : CARDINAL_OFFSETS) {
         Material sideFeet = world.getBlockAt(x + side[0], y, z + side[1]).getType();
         Material sideGround = world.getBlockAt(x + side[0], y - 1, z + side[1]).getType();
         if (sideFeet == Material.LAVA || sideGround == Material.LAVA) {
            penalty += (double)4.0F;
            break;
         }
      }

      return penalty;
   }

   private boolean isHazard(Material material) {
      return material == Material.LAVA || material == Material.FIRE || material == Material.SOUL_FIRE || material == Material.MAGMA_BLOCK || material == Material.CACTUS || material == Material.CAMPFIRE || material == Material.SOUL_CAMPFIRE;
   }

   private long encode(int x, int y, int z) {
      long ex = (long)x + 40000000L;
      long ey = (long)y + 4096L;
      long ez = (long)z + 40000000L;
      return (ex * 100000L + ey) * 100000000L + ez;
   }

   private String normalizeSchemName(String name) {
      return name.toLowerCase().replace(' ', '_');
   }

   private String stripSchemExtension(String name) {
      String lower = name.toLowerCase();
      if (lower.endsWith(".schem")) {
         return name.substring(0, name.length() - ".schem".length());
      } else {
         return lower.endsWith(".litematic") ? name.substring(0, name.length() - ".litematic".length()) : name;
      }
   }

   private boolean isSchematicFile(File f) {
      String n = f.getName().toLowerCase();
      return f.isFile() && (n.endsWith(".schem") || n.endsWith(".litematic"));
   }

   private File findSchematicFile(String name) {
      File[] files = this.schematicsDir.listFiles();
      if (files == null) {
         return null;
      } else {
         String wanted = this.normalizeSchemName(name);

         for(File f : files) {
            if (this.isSchematicFile(f)) {
               String base = this.normalizeSchemName(this.stripSchemExtension(f.getName()));
               if (base.equals(wanted) || this.normalizeSchemName(f.getName()).equals(wanted)) {
                  return f;
               }
            }
         }

         return null;
      }
   }

   private List<String> listSchematicTokens() {
      File[] files = this.schematicsDir.listFiles();
      List<String> names = new ArrayList();
      if (files != null) {
         for(File f : files) {
            if (this.isSchematicFile(f)) {
               names.add(this.stripSchemExtension(f.getName()).replace(' ', '_'));
            }
         }
      }

      return names;
   }

   private LoadedSchematic lookupLoaded(String name) {
      return (LoadedSchematic)this.loadedSchematics.get(this.normalizeSchemName(this.stripSchemExtension(name)));
   }

   private void messagePlayer(UUID playerId, String text, NamedTextColor color) {
      Player p = Bukkit.getPlayer(playerId);
      if (p != null) {
         p.sendMessage(Component.text(text).color(color));
      }

   }

   private void handleSchemSubcommand(Player player, String[] args) {
      if (args.length >= 3 && SCHEM_ACTIONS.contains(args[2].toLowerCase())) {
         String name = args[1];
         switch (args[2].toLowerCase()) {
            case "load" -> this.loadSchematic(player, name);
            case "remove" -> this.removeSchematic(player, name);
            case "rotate" -> this.rotateSchematic(player, name, args.length > 3 ? args[3] : null);
            default -> this.centerSchematic(player, name);
         }

      } else {
         player.sendMessage(Component.text("Usage: /rpp schem <name> <load|remove|center|rotate [90|180|270]>").color(NamedTextColor.YELLOW));
         List<String> available = this.listSchematicTokens();
         if (!available.isEmpty()) {
            player.sendMessage(Component.text("Schematics: " + String.join(", ", available)).color(NamedTextColor.GRAY));
         }

      }
   }

   private void tickGhosts() {
      for(LoadedSchematic loaded : this.loadedSchematics.values()) {
         if (loaded.previewVisible && loaded.hasOrigin()) {
            loaded.ghost.tick(loaded);
         } else {
            loaded.ghost.clear();
         }
      }

   }

   private boolean handleSchematicCommand(Player player, String[] args) {
      String name = args[0];
      if (args.length == 1) {
         if (this.findSchematicFile(name) == null && this.lookupLoaded(name) == null) {
            return false;
         } else {
            player.sendMessage(Component.text("Usage: /rpp schem " + name + " <load|remove|center|rotate>   then   /rpp build " + name).color(NamedTextColor.YELLOW));
            return true;
         }
      } else {
         String action = args[1].toLowerCase();
         if (!SCHEM_ACTIONS.contains(action)) {
            return false;
         } else {
            switch (action) {
               case "load" -> this.loadSchematic(player, name);
               case "remove" -> this.removeSchematic(player, name);
               case "rotate" -> this.rotateSchematic(player, name, args.length > 2 ? args[2] : null);
               default -> this.centerSchematic(player, name);
            }

            return true;
         }
      }
   }

   private void loadSchematic(Player player, String name) {
      File file = this.findSchematicFile(name);
      if (file == null) {
         player.sendMessage(Component.text("No .schem or .litematic named \"" + name + "\" in plugins/RppBot/schematics.").color(NamedTextColor.RED));
      } else {
         String base = this.stripSchemExtension(file.getName());
         String key = this.normalizeSchemName(base);
         UUID playerId = player.getUniqueId();
         player.sendMessage(Component.text("Loading \"" + base + "\"...").color(NamedTextColor.GRAY));
         Bukkit.getAsyncScheduler().runNow(this.plugin, (task) -> {
            Schematic parsed;
            try {
               parsed = SchematicLoader.load(file, base);
            } catch (RuntimeException | OutOfMemoryError | IOException e) {
               String reason = ((Throwable)e).getMessage() != null ? ((Throwable)e).getMessage() : e.getClass().getSimpleName();
               Bukkit.getGlobalRegionScheduler().run(this.plugin, (t) -> this.messagePlayer(playerId, "Couldn't load \"" + base + "\": " + reason, NamedTextColor.RED));
               return;
            }

            Bukkit.getGlobalRegionScheduler().run(this.plugin, (t) -> this.finishSchematicLoad(playerId, key, base, parsed));
         });
      }
   }

   private void finishSchematicLoad(UUID playerId, String key, String base, Schematic parsed) {
      LoadedSchematic loaded = LoadedSchematic.create(base, parsed);
      LoadedSchematic old = (LoadedSchematic)this.loadedSchematics.put(key, loaded);
      if (old != null) {
         this.cancelBuilds(old);
         loaded.inheritOrigin(old);
         loaded.previewVisible = old.previewVisible;
         old.ghost.clear();
      }

      String size = parsed.width + "x" + parsed.height + "x" + parsed.length;
      String message = "Loaded \"" + base + "\" (" + size + ", " + loaded.buildableBlocks + " blocks to build";
      if (loaded.unsupportedBlocks > 0) {
         message = message + ", " + loaded.unsupportedBlocks + " unsupported blocks will be skipped";
      }

      message = message + ").";
      this.messagePlayer(playerId, message, NamedTextColor.GREEN);
      if (!loaded.hasOrigin()) {
         this.messagePlayer(playerId, "Stand where you want it and run /rpp schem " + key + " center, then /rpp build " + key + ".", NamedTextColor.GRAY);
      }

   }

   private void removeSchematic(Player player, String name) {
      LoadedSchematic loaded = (LoadedSchematic)this.loadedSchematics.remove(this.normalizeSchemName(this.stripSchemExtension(name)));
      if (loaded == null) {
         player.sendMessage(Component.text("\"" + name + "\" isn't loaded.").color(NamedTextColor.RED));
      } else {
         loaded.ghost.clear();
         int stopped = this.cancelBuilds(loaded);
         String extra = stopped > 0 ? " and stopped " + stopped + " bot" + (stopped == 1 ? "" : "s") + " that were building it" : "";
         player.sendMessage(Component.text("Removed \"" + loaded.name + "\"" + extra + ". (The file in the schematics folder wasn't touched.)").color(NamedTextColor.GREEN));
      }
   }

   private void centerSchematic(Player player, String name) {
      LoadedSchematic loaded = this.lookupLoaded(name);
      if (loaded == null) {
         player.sendMessage(Component.text("\"" + name + "\" isn't loaded. Use /rpp schem " + name + " load first.").color(NamedTextColor.RED));
      } else if (this.isBeingBuilt(loaded)) {
         player.sendMessage(Component.text("\"" + loaded.name + "\" is being built right now - use /rpp stop first.").color(NamedTextColor.RED));
      } else {
         loaded.setCenter(player.getLocation());
         loaded.previewVisible = true;
         this.ensureTicker();
         player.sendMessage(Component.text(String.format("Origin set for \"%s\": it will be built centered on you, spanning x %d..%d, y %d..%d, z %d..%d.", loaded.name, loaded.minX(), loaded.maxX(), loaded.minY(), loaded.maxY(), loaded.minZ(), loaded.maxZ())).color(NamedTextColor.GREEN));
         World world = loaded.world();
         if (world != null && (loaded.minY() < world.getMinHeight() || loaded.maxY() >= world.getMaxHeight())) {
            player.sendMessage(Component.text("Warning: that sticks out of the world's height limits - move to a better spot and run center again.").color(NamedTextColor.RED));
         }

         this.reportPreview(player, loaded);
      }
   }

   private void reportPreview(Player player, LoadedSchematic loaded) {
      loaded.ghost.rebuild(loaded);
      int var10000 = loaded.ghost.plannedCount();
      String text = "Preview: showing " + var10000 + " display blocks. Use /rpp schem " + loaded.name.replace(' ', '_') + " rotate to turn it.";
      player.sendMessage(Component.text(text).color(NamedTextColor.GRAY));
      if (loaded.ghost.truncated()) {
         player.sendMessage(Component.text("The preview is capped at 8000 blocks, so only the lowest layers are shown. The build itself is not affected.").color(NamedTextColor.YELLOW));
      }

   }

   private void rotateSchematic(Player player, String name, String amount) {
      LoadedSchematic loaded = this.lookupLoaded(name);
      if (loaded == null) {
         player.sendMessage(Component.text("\"" + name + "\" isn't loaded. Use /rpp schem " + name + " load first.").color(NamedTextColor.RED));
      } else if (this.isBeingBuilt(loaded)) {
         player.sendMessage(Component.text("\"" + loaded.name + "\" is being built right now - use /rpp stop first.").color(NamedTextColor.RED));
      } else {
         int turns = this.parseQuarterTurns(amount);
         if (turns < 0) {
            player.sendMessage(Component.text("Usage: /rpp schem " + name + " rotate [90|180|270]   (clockwise, default 90; you can also use left/right)").color(NamedTextColor.YELLOW));
         } else {
            loaded.rotate(turns);
            String heading = "Rotated \"" + loaded.name + "\" " + turns * 90 + " degrees clockwise (now " + loaded.rotationTurns * 90 + " degrees from the file).";
            player.sendMessage(Component.text(heading).color(NamedTextColor.GREEN));
            if (loaded.hasOrigin()) {
               loaded.previewVisible = true;
               this.ensureTicker();
               player.sendMessage(Component.text(String.format("It now spans x %d..%d, y %d..%d, z %d..%d.", loaded.minX(), loaded.maxX(), loaded.minY(), loaded.maxY(), loaded.minZ(), loaded.maxZ())).color(NamedTextColor.GRAY));
               this.reportPreview(player, loaded);
            } else {
               player.sendMessage(Component.text("Stand where you want it and run /rpp schem " + name + " center to see the preview.").color(NamedTextColor.GRAY));
            }

         }
      }
   }

   private int parseQuarterTurns(String amount) {
      if (amount != null && !amount.isBlank()) {
         byte var10000;
         switch (amount.toLowerCase()) {
            case "90":
            case "cw":
            case "right":
               var10000 = 1;
               break;
            case "180":
               var10000 = 2;
               break;
            case "270":
            case "-90":
            case "ccw":
            case "left":
               var10000 = 3;
               break;
            default:
               var10000 = -1;
         }

         return var10000;
      } else {
         return 1;
      }
   }

   private boolean isBeingBuilt(LoadedSchematic loaded) {
      for(Companion c : this.companions.values()) {
         if (c.buildJob != null && c.buildJob.schem == loaded) {
            return true;
         }
      }

      return false;
   }

   private int cancelBuilds(LoadedSchematic loaded) {
      int stopped = 0;

      for(Companion c : this.companions.values()) {
         if (c.buildJob != null && c.buildJob.schem == loaded) {
            c.resetMode();
            ++stopped;
         }
      }

      this.activeJobs.remove(this.normalizeSchemName(loaded.name));
      return stopped;
   }

   private boolean jobHasBuilders(BuildJob job) {
      for(Companion c : this.companions.values()) {
         if (c.buildJob == job) {
            return true;
         }
      }

      return false;
   }

   private void startBuild(Player player, String[] args) {
      if (args.length < 2) {
         player.sendMessage(Component.text("Usage: /rpp build <schematic> [BotName]").color(NamedTextColor.YELLOW));
      } else {
         LoadedSchematic loaded = this.lookupLoaded(args[1]);
         if (loaded == null) {
            if (this.findSchematicFile(args[1]) != null) {
               player.sendMessage(Component.text("\"" + args[1] + "\" isn't loaded yet - run /rpp schem " + args[1] + " load first.").color(NamedTextColor.RED));
            } else {
               player.sendMessage(Component.text("No schematic named \"" + args[1] + "\" is loaded. Put a .schem/.litematic in plugins/RppBot/schematics and run /rpp schem <name> load.").color(NamedTextColor.RED));
            }

         } else if (!loaded.hasOrigin()) {
            player.sendMessage(Component.text("\"" + loaded.name + "\" has no origin yet - stand where you want it and run /rpp schem " + args[1] + " center.").color(NamedTextColor.RED));
         } else if (loaded.buildableBlocks <= 0) {
            player.sendMessage(Component.text("\"" + loaded.name + "\" has no blocks this server can build.").color(NamedTextColor.RED));
         } else {
            World world = loaded.world();
            if (loaded.minY() >= world.getMinHeight() && loaded.maxY() < world.getMaxHeight()) {
               if (this.hasMannequins(player)) {
                  List<Companion> builders = new ArrayList();

                  for(Companion c : this.resolveTargets(args)) {
                     if (world.equals(c.entity.getWorld())) {
                        builders.add(c);
                     }
                  }

                  if (builders.isEmpty()) {
                     String var10001 = world.getName();
                     player.sendMessage(Component.text("None of the selected bots are in the world \"" + var10001 + "\" where " + loaded.name + " is set up.").color(NamedTextColor.RED));
                  } else {
                     String key = this.normalizeSchemName(loaded.name);
                     BuildJob job = (BuildJob)this.activeJobs.get(key);
                     boolean joined = job != null && job.schem == loaded && this.jobHasBuilders(job);
                     if (!joined) {
                        job = new BuildJob(loaded, player.getUniqueId());
                        this.activeJobs.put(key, job);
                     }

                     loaded.previewVisible = false;

                     for(Companion c : builders) {
                        c.resetMode();
                        c.building = true;
                        c.buildJob = job;
                        c.buildPhase = 1;
                     }

                     this.ensureTicker();
                     String who = this.describeTargets(builders);
                     String verb = joined ? " joined the build of \"" : " will build \"";
                     player.sendMessage(Component.text(who + verb + loaded.name + "\" (" + job.total + " blocks). They'll fetch what they need from the nearest chest.").color(NamedTextColor.GREEN));
                  }
               }
            } else {
               player.sendMessage(Component.text("\"" + loaded.name + "\" would go outside the world's height limits - run /rpp schem " + args[1] + " center from a better spot.").color(NamedTextColor.RED));
            }
         }
      }
   }

   private void tickBuildJobs() {
      if (!this.activeJobs.isEmpty()) {
         Iterator<Map.Entry<String, BuildJob>> it = this.activeJobs.entrySet().iterator();

         while(it.hasNext()) {
            BuildJob job = (BuildJob)((Map.Entry)it.next()).getValue();
            if (!this.jobHasBuilders(job)) {
               it.remove();
               this.announceBuildResult(job);
            }
         }

      }
   }

   private void announceBuildResult(BuildJob job) {
      int left = job.remaining();
      StringBuilder sb = new StringBuilder();
      sb.append(left > 0 ? "Stopped building \"" : "Finished building \"").append(job.schem.name).append("\": placed ").append(job.placed).append(" block").append(job.placed == 1 ? "" : "s");
      if (job.alreadyCorrect > 0) {
         sb.append(", ").append(job.alreadyCorrect).append(" already in place");
      }

      if (job.skippedMissing > 0) {
         List<Map.Entry<Material, Integer>> entries = new ArrayList(job.missingCounts().entrySet());
         entries.sort((a, b) -> Integer.compare((Integer)b.getValue(), (Integer)a.getValue()));
         sb.append(", skipped ").append(job.skippedMissing).append(" (not in the chest: ");

         for(int i = 0; i < Math.min(5, entries.size()); ++i) {
            if (i > 0) {
               sb.append(", ");
            }

            sb.append(((Material)((Map.Entry)entries.get(i)).getKey()).name()).append(" x").append(((Map.Entry)entries.get(i)).getValue());
         }

         if (entries.size() > 5) {
            sb.append(", ...");
         }

         sb.append(")");
      }

      if (job.skippedUnreachable > 0) {
         sb.append(", couldn't reach ").append(job.skippedUnreachable);
      }

      if (left > 0) {
         sb.append(", ").append(left).append(" not built yet");
      }

      sb.append(".");
      this.messagePlayer(job.owner, sb.toString(), left > 0 ? NamedTextColor.YELLOW : NamedTextColor.GREEN);
   }

   private void tickBuild(Companion c) {
      BuildJob job = c.buildJob;
      if (job == null) {
         c.resetMode();
      } else {
         Mannequin mannequin = c.entity;
         Location current = mannequin.getLocation();
         if (current.getWorld() != null) {
            double verticalVelocity = this.resolveVerticalVelocity(mannequin);
            switch (c.buildPhase) {
               case 1 -> this.buildClaim(c, job);
               case 2 -> this.buildPlan(c, job);
               case 3 -> this.buildWalkToChest(c, mannequin, current, verticalVelocity);
               case 4 -> this.buildAtChest(c, job, mannequin, current, verticalVelocity);
               case 5 -> this.buildPlace(c, job, mannequin, current, verticalVelocity);
               default -> c.buildPhase = 1;
            }

         }
      }
   }

   private void buildClaim(Companion c, BuildJob job) {
      int[] batch = job.claimBatch(256);
      if (batch.length == 0) {
         c.resetMode();
      } else {
         c.buildBatch = batch;
         c.buildBatchPos = 0;
         c.buildProgressTick = this.tickCounter;
         c.buildStuckStage = 0;
         c.buildPhase = 2;
      }
   }

   private void buildPlan(Companion c, BuildJob job) {
      LoadedSchematic loaded = job.schem;
      Map<Material, Integer> needed = new LinkedHashMap();

      for(int idx : c.buildBatch) {
         BlockCost.ItemCost cost = loaded.costs[loaded.schematic.blocks[idx]];
         if (cost != null && cost.count() > 0 && !job.isUnavailable(cost.item())) {
            needed.merge(cost.item(), cost.count(), Integer::sum);
         }
      }

      Map<Material, Integer> deficit = new LinkedHashMap();

      for(Map.Entry<Material, Integer> e : needed.entrySet()) {
         int have = this.countInStorage(c, (Material)e.getKey());
         if (have < (Integer)e.getValue()) {
            deficit.put((Material)e.getKey(), (Integer)e.getValue() - have);
         }
      }

      if (deficit.isEmpty()) {
         c.buildPhase = 5;
      } else {
         Location chest = c.buildChestLoc;
         if (chest == null || !this.isChestBlock(chest)) {
            chest = this.findNearestChest(c.entity.getLocation());
            c.buildChestLoc = chest;
         }

         if (chest == null) {
            if (!job.noChestReported) {
               job.noChestReported = true;
               this.messagePlayer(job.owner, "No chest found near " + this.displayName(c) + " - it will only place blocks it's already carrying.", NamedTextColor.YELLOW);
            }

            c.buildPhase = 5;
         } else {
            c.buildDeficit = deficit;
            c.buildPhaseStartTick = this.tickCounter;
            c.resetPath();
            c.buildPhase = 3;
         }
      }
   }

   private void buildWalkToChest(Companion c, Mannequin mannequin, Location current, double verticalVelocity) {
      Location chest = c.buildChestLoc;
      if (chest != null && chest.getWorld() != null && chest.getWorld().equals(current.getWorld()) && this.isChestBlock(chest)) {
         Location center = chest.clone().add((double)0.5F, (double)0.5F, (double)0.5F);
         if (mannequin.getEyeLocation().distance(center) <= 3.2) {
            this.stopMovement(c, mannequin, verticalVelocity);

            try {
               BlockState var9 = chest.getBlock().getState();
               if (var9 instanceof Chest) {
                  Chest lidded = (Chest)var9;
                  lidded.open();
                  c.openChestLoc = chest;
               }
            } catch (Exception e) {
               Bukkit.getLogger().warning("[RppCommand] Couldn't open the chest lid: " + e.getMessage());
            }

            mannequin.swingMainHand();
            c.buildWaitUntilTick = this.tickCounter + 40L;
            c.buildPhase = 4;
         } else if (this.tickCounter - c.buildPhaseStartTick <= 600L) {
            this.pathTowards(c, mannequin, current, center, verticalVelocity);
         } else {
            c.resetPath();
            Location alternative = this.findNearestChest(current);
            if (alternative != null && !alternative.equals(c.buildChestLoc)) {
               c.buildChestLoc = alternative;
               c.buildPhaseStartTick = this.tickCounter;
               c.buildStuckStage = 0;
            } else if (c.buildStuckStage == 0) {
               c.buildStuckStage = 1;
               c.buildPhaseStartTick = this.tickCounter;
            } else {
               c.buildDeficit = null;
               c.buildPhase = 5;
               c.buildStuckStage = 0;
            }

         }
      } else {
         c.buildChestLoc = null;
         c.buildPhase = 2;
      }
   }

   private void buildAtChest(Companion c, BuildJob job, Mannequin mannequin, Location current, double verticalVelocity) {
      Location chest = c.buildChestLoc;
      this.stopMovement(c, mannequin, verticalVelocity);
      if (chest != null) {
         this.faceTarget(mannequin, current, chest.clone().add((double)0.5F, (double)0.5F, (double)0.5F));
      }

      if (this.tickCounter >= c.buildWaitUntilTick) {
         try {
            if (chest != null) {
               this.takeItemsFromChest(c, job, chest);
            }
         } catch (Exception e) {
            Bukkit.getLogger().severe("[RppCommand] Error while taking items from the chest: " + e.getMessage());
         }

         if (c.openChestLoc != null) {
            closeChestQuietly(c.openChestLoc);
            c.openChestLoc = null;
         }

         c.buildDeficit = null;
         c.buildProgressTick = this.tickCounter;
         c.buildStuckStage = 0;
         c.buildPhase = 5;
      }
   }

   private void takeItemsFromChest(Companion c, BuildJob job, Location chestLoc) {
      Map<Material, Integer> deficit = c.buildDeficit;
      if (deficit != null) {
         BlockState var6 = chestLoc.getBlock().getState();
         if (var6 instanceof Chest) {
            Chest chest = (Chest)var6;
            Inventory var19 = chest.getInventory();
            boolean full = false;

            for(Map.Entry<Material, Integer> e : deficit.entrySet()) {
               Material mat = (Material)e.getKey();
               int want = (Integer)e.getValue();
               int taken = 0;
               boolean chestHadSome = false;

               for(int slot = 0; slot < var19.getSize() && taken < want && !full; ++slot) {
                  ItemStack stack = var19.getItem(slot);
                  if (stack != null && stack.getType() == mat && stack.getAmount() > 0) {
                     chestHadSome = true;
                     int take = Math.min(Math.min(want - taken, stack.getAmount()), mat.getMaxStackSize());
                     ItemStack leftover = this.tryStoreItem(c, new ItemStack(mat, take));
                     int moved = take - (leftover == null ? 0 : leftover.getAmount());
                     if (moved > 0) {
                        taken += moved;
                        if (moved >= stack.getAmount()) {
                           var19.setItem(slot, (ItemStack)null);
                        } else {
                           stack.setAmount(stack.getAmount() - moved);
                           var19.setItem(slot, stack);
                        }
                     }

                     if (moved < take) {
                        full = true;
                     }
                  }
               }

               if (!chestHadSome && this.countInStorage(c, mat) == 0 && job.markUnavailable(mat)) {
                  this.messagePlayer(job.owner, "The chest has no " + mat.name() + " - blocks that need it will be skipped.", NamedTextColor.YELLOW);
               }
            }

            if (full) {
               this.messagePlayer(job.owner, this.displayName(c) + "'s inventory is full - some blocks may be skipped.", NamedTextColor.YELLOW);
            }

            return;
         }
      }

   }

   private void buildPlace(Companion c, BuildJob job, Mannequin mannequin, Location current, double verticalVelocity) {
      LoadedSchematic loaded = job.schem;
      World world = loaded.world();
      int[] batch = c.buildBatch;
      if (world != null && batch != null) {
         while(c.buildBatchPos < batch.length) {
            int idx = batch[c.buildBatchPos];
            int paletteIdx = loaded.schematic.blocks[idx];
            BlockData target = loaded.states[paletteIdx];
            BlockCost.ItemCost cost = loaded.costs[paletteIdx];
            if (target != null && cost != null) {
               int x = loaded.worldX(idx);
               int y = loaded.worldY(idx);
               int z = loaded.worldZ(idx);
               Block block = world.getBlockAt(x, y, z);
               if (!block.getBlockData().equals(target)) {
                  if (cost.count() <= 0 || this.countInStorage(c, cost.item()) >= cost.count()) {
                     Location center = new Location(world, (double)x + (double)0.5F, (double)y + (double)0.5F, (double)z + (double)0.5F);
                     if (mannequin.getEyeLocation().distanceSquared(center) > (double)20.25F) {
                        if (this.buildWatchdog(c, job, center)) {
                           return;
                        } else {
                           this.pathTowards(c, mannequin, current, center, verticalVelocity);
                           return;
                        }
                     } else if (target.getMaterial().isSolid() && mannequin.getBoundingBox().overlaps(BoundingBox.of(block))) {
                        if (this.buildWatchdog(c, job, center)) {
                           return;
                        } else {
                           Vector away = current.toVector().subtract(center.toVector()).setY(0);
                           if (away.lengthSquared() < 1.0E-4) {
                              away = new Vector(1, 0, 0);
                           }

                           float awayYaw = mannequin.getLocation().getYaw();
                           WasdMotor.chooseKeys(c.keys, away.getX(), away.getZ(), awayYaw);
                           c.keys.sprint = false;
                           c.keys.sneak = false;
                           this.driveKeys(c, mannequin, awayYaw, verticalVelocity, (double)0.25F, (double)0.25F);
                           return;
                        }
                     } else {
                        this.stopMovement(c, mannequin, verticalVelocity);
                        BlockFace supportFace = this.findPlacementFace(world, block);
                        Location interactionPoint = center.clone();
                        if (supportFace != null) {
                           Block support = block.getRelative(supportFace);
                           interactionPoint = support.getLocation().add((double)0.5F, (double)0.5F, (double)0.5F);
                        }

                        this.faceTarget(mannequin, current, interactionPoint);
                        if (this.tickCounter < c.nextPlaceTick) {
                           return;
                        } else {
                           if (cost.count() > 0) {
                              this.takeFromStorage(c, cost.item(), cost.count());
                           }

                           block.setBlockData(target, false);
                           ++job.placed;
                           mannequin.swingMainHand();
                           world.playSound(center, target.getSoundGroup().getPlaceSound(), SoundCategory.BLOCKS, 0.8F, 0.9F);
                           c.nextPlaceTick = this.tickCounter + ThreadLocalRandom.current().nextLong(4L, 8L);
                           this.advanceBuild(c);
                           return;
                        }
                     }
                  }

                  job.recordMissing(cost.item());
                  this.advanceBuild(c);
               } else {
                  ++job.alreadyCorrect;
                  this.advanceBuild(c);
               }
            } else {
               this.advanceBuild(c);
            }
         }

         c.buildBatch = null;
         c.buildBatchPos = 0;
         c.buildPhase = 1;
      } else {
         c.resetMode();
      }
   }

   private void advanceBuild(Companion c) {
      ++c.buildBatchPos;
      c.buildProgressTick = this.tickCounter;
      c.buildStuckStage = 0;
   }

   private BlockFace findPlacementFace(World world, Block block) {
      BlockFace[] faces = new BlockFace[]{BlockFace.DOWN, BlockFace.NORTH, BlockFace.SOUTH, BlockFace.WEST, BlockFace.EAST, BlockFace.UP};

      for(BlockFace face : faces) {
         if (block.getRelative(face).getType().isSolid()) {
            return face;
         }
      }

      return null;
   }

   private boolean buildWatchdog(Companion c, BuildJob job, Location blockCenter) {
      if (this.tickCounter - c.buildProgressTick < 100L) {
         return false;
      } else {
         c.buildProgressTick = this.tickCounter;
         if (c.buildStuckStage == 0) {
            c.buildStuckStage = 1;
            c.resetPath();
            c.forceJump = true;

            return false;
         } else {
            c.buildStuckStage = 0;
            job.defer(c.buildBatch[c.buildBatchPos]);
            ++c.buildBatchPos;
            return true;
         }
      }
   }

   private void pathTowards(Companion c, Mannequin mannequin, Location current, Location goal, double verticalVelocity) {
      boolean followingPath = c.currentPath != null && c.pathIndex < c.currentPath.size();
      if (followingPath || c.currentPath == null || this.tickCounter - c.lastPathComputeTick >= 10L) {
         this.maybeRecomputePath(c, goal);
      }

      this.moveAlongPath(c, mannequin, current, goal, verticalVelocity);
   }

   private boolean teleportNear(Companion c, Location target, double maxReach) {
      World world = target.getWorld();
      if (world == null) {
         return false;
      } else {
         Location me = c.entity.getLocation();
         int tx = target.getBlockX();
         int ty = target.getBlockY();
         int tz = target.getBlockZ();
         Location best = null;
         double bestDist = Double.MAX_VALUE;

         for(int dx = -3; dx <= 3; ++dx) {
            for(int dz = -3; dz <= 3; ++dz) {
               for(int dy = -3; dy <= 2; ++dy) {
                  if (dx != 0 || dz != 0 || dy != 0 && dy != -1) {
                     int x = tx + dx;
                     int y = ty + dy;
                     int z = tz + dz;
                     if (this.isWalkable(world, x, y, z)) {
                        Location stand = new Location(world, (double)x + (double)0.5F, (double)y, (double)z + (double)0.5F, me.getYaw(), me.getPitch());
                        double reachSq = stand.clone().add((double)0.0F, 1.62, (double)0.0F).distanceSquared(target);
                        if (!(reachSq > maxReach * maxReach)) {
                           double dist = stand.distanceSquared(me);
                           if (dist < bestDist) {
                              bestDist = dist;
                              best = stand;
                           }
                        }
                     }
                  }
               }
            }
         }

         if (best == null) {
            return false;
         } else {
            c.entity.teleport(best);
            c.resetPath();
            return true;
         }
      }
   }

   private boolean isChestBlock(Location loc) {
      World world = loc.getWorld();
      if (world != null && world.isChunkLoaded(loc.getBlockX() >> 4, loc.getBlockZ() >> 4)) {
         Material type = loc.getBlock().getType();
         return type == Material.CHEST || type == Material.TRAPPED_CHEST;
      } else {
         return false;
      }
   }

   private Location findNearestChest(Location from) {
      World world = from.getWorld();
      if (world == null) {
         return null;
      } else {
         int cx = from.getBlockX() >> 4;
         int cz = from.getBlockZ() >> 4;
         Location best = null;
         double bestDist = Double.MAX_VALUE;

         for(int dx = -3; dx <= 3; ++dx) {
            for(int dz = -3; dz <= 3; ++dz) {
               if (world.isChunkLoaded(cx + dx, cz + dz)) {
                  Chunk chunk = world.getChunkAt(cx + dx, cz + dz);

                  for(BlockState state : chunk.getTileEntities()) {
                     if (state instanceof Chest) {
                        Location loc = state.getLocation();
                        double dist = loc.distanceSquared(from);
                        if (dist < bestDist) {
                           bestDist = dist;
                           best = loc;
                        }
                     }
                  }
               }
            }
         }

         return best;
      }
   }

   private static void closeChestQuietly(Location loc) {
      try {
         World world = loc.getWorld();
         if (world != null && world.isChunkLoaded(loc.getBlockX() >> 4, loc.getBlockZ() >> 4)) {
            BlockState var3 = loc.getBlock().getState();
            if (var3 instanceof Chest) {
               Chest chest = (Chest)var3;
               chest.close();
            }
         }
      } catch (Exception var4) {
      }

   }

   private int countInStorage(Companion c, Material mat) {
      int total = 0;

      for(ItemStack stack : c.storageContents) {
         if (stack != null && stack.getType() == mat) {
            total += stack.getAmount();
         }
      }

      return total;
   }

   private void takeFromStorage(Companion c, Material mat, int amount) {
      for(int i = 0; i < c.storageContents.length && amount > 0; ++i) {
         ItemStack stack = c.storageContents[i];
         if (stack != null && stack.getType() == mat) {
            if (stack.getAmount() <= amount) {
               amount -= stack.getAmount();
               c.storageContents[i] = null;
            } else {
               stack.setAmount(stack.getAmount() - amount);
               amount = 0;
            }
         }
      }

   }

   private void handleMocapCommand(Player player, String[] args) {
      switch (args.length >= 2 ? args[1].toLowerCase() : "") {
         case "start" -> this.startMocap(player);
         case "stop" -> this.stopMocap(player);
         case "cancel" -> this.cancelMocap(player);
         default -> player.sendMessage(Component.text("Usage: /rpp mocap <start|stop|cancel>").color(NamedTextColor.YELLOW));
      }

   }

   private void startMocap(Player player) {
      if (this.mocapRecorders.containsKey(player.getUniqueId())) {
         player.sendMessage(Component.text("You're already recording. Use /rpp mocap stop to finish or /rpp mocap cancel to throw it away.").color(NamedTextColor.RED));
      } else {
         MocapRecorder recorder = new MocapRecorder(player);
         recorder.sample();
         this.mocapRecorders.put(player.getUniqueId(), recorder);
         this.ensureTicker();
         player.sendMessage(Component.text("Mocap recording started. Walk around, swing, use your offhand, build or break blocks, shoot bows and crossbows, throw tridents/pearls/potions, open chests and barrels, use doors and levers, glide with an elytra and fire rockets - then /rpp mocap stop (or /rpp mocap cancel). Anything you build or break gets reverted when you stop, and the bot redoes it.").color(NamedTextColor.GREEN));
      }
   }

   private void stopMocap(Player player) {
      MocapRecorder recorder = (MocapRecorder)this.mocapRecorders.remove(player.getUniqueId());
      if (recorder == null) {
         player.sendMessage(Component.text("You're not recording. Use /rpp mocap start first.").color(NamedTextColor.RED));
      } else {
         this.finishMocap(player, recorder);
      }
   }

   private void cancelMocap(Player player) {
      MocapRecorder recorder = (MocapRecorder)this.mocapRecorders.remove(player.getUniqueId());
      if (recorder == null) {
         player.sendMessage(Component.text("You're not recording, so there's nothing to cancel.").color(NamedTextColor.RED));
      } else {
         player.sendActionBar(Component.empty());
         int undone = recorder.changeCount();
         recorder.revertAll();
         String var10001 = undone > 0 ? " Reverted " + undone + " block change" + (undone == 1 ? "" : "s") + "." : "";
         player.sendMessage(Component.text("Mocap cancelled - recording discarded, no bot spawned." + var10001).color(NamedTextColor.YELLOW));
      }
   }

   private void finishMocap(Player player, MocapRecorder recorder) {
      player.sendActionBar(Component.empty());
      int blockChanges = recorder.changeCount();
      recorder.revertAll();
      if (recorder.frameCount() < 10) {
         player.sendMessage(Component.text("That recording was under half a second long, so nothing was spawned.").color(NamedTextColor.RED));
      } else {
         MocapRecording recording = recorder.finish();
         Location start = recording.startLocation();
         if (start == null) {
            player.sendMessage(Component.text("The world that recording was made in isn't loaded anymore.").color(NamedTextColor.RED));
         } else {
            List<Companion> spawned = this.spawnSquad(player, 1, start);
            if (spawned.isEmpty()) {
               player.sendMessage(Component.text("Couldn't spawn a bot for the recording.").color(NamedTextColor.RED));
            } else {
               Companion bot = (Companion)spawned.get(0);
               bot.resetMode();
               MocapRecorder.applyEquipment(bot.entity.getEquipment(), recording.frame(0).equipment());
               bot.mocap = new MocapPlayback(recording);
               this.refillMocapInventory(bot, recording);
               String built = blockChanges > 0 ? " Reverted " + blockChanges + " block change" + (blockChanges == 1 ? "" : "s") + " - the bot will redo them." : "";
               String var10001 = String.format("Mocap saved (%.1fs). %s is now looping it.", recording.seconds(), bot.botName);
               player.sendMessage(Component.text(var10001 + built).color(NamedTextColor.GREEN));
            }
         }
      }
   }

   private void tickMocapRecorders() {
      if (!this.mocapRecorders.isEmpty()) {
         Iterator<Map.Entry<UUID, MocapRecorder>> it = this.mocapRecorders.entrySet().iterator();

         while(it.hasNext()) {
            MocapRecorder recorder = (MocapRecorder)((Map.Entry)it.next()).getValue();
            Player p = recorder.player();
            if (!p.isOnline()) {
               it.remove();
               recorder.revertAll();
            } else if (!recorder.stillInWorld()) {
               it.remove();
               p.sendMessage(Component.text("You changed worlds, so the recording was ended at that point.").color(NamedTextColor.YELLOW));
               this.finishMocap(p, recorder);
            } else {
               recorder.sample();
               int frames = recorder.frameCount();
               if (recorder.isFull()) {
                  it.remove();
                  p.sendMessage(Component.text("Hit the 10 minute recording limit - stopping automatically.").color(NamedTextColor.YELLOW));
                  this.finishMocap(p, recorder);
               } else if (frames % 20 == 0) {
                  int seconds = frames / 20;
                  p.sendActionBar(Component.text(String.format("● REC %d:%02d", seconds / 60, seconds % 60)).color(NamedTextColor.RED));
               }
            }
         }

      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onMocapArmSwing(PlayerAnimationEvent event) {
      MocapRecorder recorder = (MocapRecorder)this.mocapRecorders.get(event.getPlayer().getUniqueId());
      if (recorder != null) {
         boolean offHand = event.getAnimationType().name().contains("OFF");
         if (!offHand) {
            try {
               Object hand = event.getClass().getMethod("getHand").invoke(event);
               offHand = hand != null && hand.toString().contains("OFF");
            } catch (ReflectiveOperationException var5) {
            }
         }

         recorder.noteSwing(offHand);
      }
   }

   @EventHandler
   public void onMocapPlayerQuit(PlayerQuitEvent event) {
      MocapRecorder recorder = (MocapRecorder)this.mocapRecorders.remove(event.getPlayer().getUniqueId());
      if (recorder != null) {
         recorder.revertAll();
      }

   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onMocapBlockPlace(BlockPlaceEvent event) {
      MocapRecorder recorder = (MocapRecorder)this.mocapRecorders.get(event.getPlayer().getUniqueId());
      if (recorder != null) {
         List var10000;
         if (event instanceof BlockMultiPlaceEvent) {
            BlockMultiPlaceEvent multi = (BlockMultiPlaceEvent)event;
            var10000 = multi.getReplacedBlockStates();
         } else {
            var10000 = List.of(event.getBlockReplacedState());
         }

         List<BlockState> befores = var10000;
         Material item = event.getItemInHand().getType();
         int frame = recorder.frameCount();
         boolean first = true;

         for(BlockState before : befores) {
            recorder.recordChange(frame, before, before.getBlock().getBlockData(), first ? item : null);
            first = false;
         }

      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onMocapBlockBreak(BlockBreakEvent event) {
      UUID playerId = event.getPlayer().getUniqueId();
      MocapRecorder recorder = (MocapRecorder)this.mocapRecorders.get(playerId);
      if (recorder != null) {
         Block block;
         boolean var10000;
         label29: {
            block = event.getBlock();
            BlockData old = block.getBlockData();
            if (old instanceof Waterlogged) {
               Waterlogged w = (Waterlogged)old;
               if (w.isWaterlogged()) {
                  var10000 = true;
                  break label29;
               }
            }

            var10000 = false;
         }

         boolean waterlogged = var10000;
         int frame = recorder.frameCount();
         recorder.recordChange(frame, block.getState(), (waterlogged ? Material.WATER : Material.AIR).createBlockData(), (Material)null);
         Map<Block, BlockState> neighbours = new HashMap();

         for(BlockFace face : new BlockFace[]{BlockFace.UP, BlockFace.DOWN, BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST}) {
            Block neighbour = block.getRelative(face);
            neighbours.put(neighbour, neighbour.getState());
         }

         Bukkit.getGlobalRegionScheduler().runDelayed(this.plugin, (task) -> {
            if (this.mocapRecorders.get(playerId) == recorder) {
               for(Map.Entry<Block, BlockState> entry : neighbours.entrySet()) {
                  BlockData now = ((Block)entry.getKey()).getBlockData();
                  if (!now.equals(((BlockState)entry.getValue()).getBlockData())) {
                     recorder.recordChange(frame, (BlockState)entry.getValue(), now, (Material)null);
                  }
               }

            }
         }, 1L);
      }
   }

   private void refillMocapInventory(Companion c, MocapRecording recording) {
      for(Map.Entry<Material, Integer> need : recording.requiredItems().entrySet()) {
         Material mat = (Material)need.getKey();
         int missing = (Integer)need.getValue() - this.countInStorage(c, mat);

         while(missing > 0) {
            int amount = Math.min(missing, mat.getMaxStackSize());
            missing -= amount;
            if (this.tryStoreItem(c, new ItemStack(mat, amount)) != null) {
               break;
            }
         }
      }

   }

   private static void revertMocapChanges(MocapPlayback pb) {
      for(Entity shot : pb.spawnedProjectiles) {
         if (shot.isValid()) {
            shot.remove();
         }
      }

      pb.spawnedProjectiles.clear();

      for(Location lid : pb.openLids) {
         MocapRecorder.setLid(lid, false);
      }

      pb.openLids.clear();
      pb.actionCursor = 0;
      List<MocapBlockChange> changes = pb.recording.changes();

      for(int i = Math.min(pb.changeCursor, changes.size()) - 1; i >= 0; --i) {
         try {
            ((MocapBlockChange)changes.get(i)).revert();
         } catch (Exception e) {
            Bukkit.getLogger().warning("[RppCommand] Couldn't revert a mocap block change: " + String.valueOf(e));
         }
      }

      pb.changeCursor = 0;
   }

   private void applyMocapChange(Companion c, MocapBlockChange change) {
      Block block = change.before().getBlock();
      World world = block.getWorld();
      BlockData old = block.getBlockData();
      change.apply();
      Location centre = block.getLocation().add((double)0.5F, (double)0.5F, (double)0.5F);

      try {
         if (!change.after().getMaterial().isAir() && change.after().getMaterial() != Material.WATER) {
            world.playSound(centre, change.after().getSoundGroup().getPlaceSound(), SoundCategory.BLOCKS, 1.0F, 0.8F);
         } else {
            world.spawnParticle(Particle.BLOCK, centre, 20, (double)0.25F, (double)0.25F, (double)0.25F, old);
            world.playSound(centre, old.getSoundGroup().getBreakSound(), SoundCategory.BLOCKS, 1.0F, 0.8F);
         }
      } catch (Exception var8) {
      }

      if (change.item() != null) {
         this.takeFromStorage(c, change.item(), 1);
      }

   }

   private static ItemStack copyItem(ItemStack stack) {
      return stack != null && !stack.getType().isAir() ? stack.clone() : null;
   }

   private void giveAll(Player player, String[] args) {
      if (this.hasMannequins(player)) {
         List<Companion> targets = this.resolveTargets(args);
         PlayerInventory inv = player.getInventory();
         int given = 0;
         int skippedMocap = 0;

         for(Companion c : targets) {
            if (c.mocap != null) {
               ++skippedMocap;
            } else {
               EntityEquipment equipment = c.entity.getEquipment();
               if (equipment != null) {
                  equipment.setItemInMainHand(copyItem(inv.getItemInMainHand()));
                  equipment.setItemInOffHand(copyItem(inv.getItemInOffHand()));
                  equipment.setHelmet(copyItem(inv.getHelmet()));
                  equipment.setChestplate(copyItem(inv.getChestplate()));
                  equipment.setLeggings(copyItem(inv.getLeggings()));
                  equipment.setBoots(copyItem(inv.getBoots()));
               }

               for(int i = 0; i < c.storageContents.length; ++i) {
                  c.storageContents[i] = i < 36 ? copyItem(inv.getItem(i)) : null;
               }

               ++given;
            }
         }

         String text = "Gave your inventory and gear to " + given + " bot" + (given == 1 ? "" : "s") + ".";
         if (skippedMocap > 0) {
            text = text + " (" + skippedMocap + " mocap bot" + (skippedMocap == 1 ? "" : "s") + " skipped - their gear comes from the recording.)";
         }

         player.sendMessage(Component.text(text).color(given > 0 ? NamedTextColor.GREEN : NamedTextColor.YELLOW));
      }
   }

   private void setSkin(Player player, String[] args) {
      if (args.length < 3) {
         player.sendMessage(Component.text("Usage: /rpp setskin <@a|BotName[,BotName...]> <PlayerName>").color(NamedTextColor.YELLOW));
      } else if (this.hasMannequins(player)) {
         String skinName = args[2];
         if (!skinName.matches("[A-Za-z0-9_]{1,16}")) {
            player.sendMessage(Component.text("\"" + skinName + "\" isn't a valid Minecraft username.").color(NamedTextColor.RED));
         } else {
            List<Companion> targets = new ArrayList();

            for(String token : args[1].split(",")) {
               if (!token.isEmpty()) {
                  if (token.equalsIgnoreCase("@a")) {
                     targets = new ArrayList(this.companions.values());
                     break;
                  }

                  Companion found = null;

                  for(Companion c : this.companions.values()) {
                     if (c.botName != null && c.botName.equalsIgnoreCase(token)) {
                        found = c;
                        break;
                     }
                  }

                  if (found == null) {
                     player.sendMessage(Component.text("No bot named \"" + token + "\". Use @a or a bot name from /rpp list.").color(NamedTextColor.RED));
                     return;
                  }

                  if (!targets.contains(found)) {
                     targets.add(found);
                  }
               }
            }

            if (targets.isEmpty()) {
               player.sendMessage(Component.text("Usage: /rpp setskin <@a|BotName[,BotName...]> <PlayerName>").color(NamedTextColor.YELLOW));
            } else {
               List<UUID> ids = new ArrayList();

               for(Companion c : targets) {
                  ids.add(c.entity.getUniqueId());
               }

               UUID playerId = player.getUniqueId();
               player.sendMessage(Component.text("Looking up " + skinName + "'s skin...").color(NamedTextColor.GRAY));
               Bukkit.getAsyncScheduler().runNow(this.plugin, (task) -> {
                  PlayerProfile lookup = Bukkit.createProfile(skinName);

                  boolean resolvedTmp;
                  try {
                     resolvedTmp = lookup.complete();
                  } catch (Exception e) {
                     Bukkit.getLogger().warning("[RppCommand] Skin lookup for '" + skinName + "' failed: " + e.getMessage());
                     resolvedTmp = false;
                  }
                  final boolean resolved = resolvedTmp;

                  Bukkit.getGlobalRegionScheduler().run(this.plugin, (mainTask) -> {
                     if (!resolved) {
                        this.messagePlayer(playerId, "Couldn't find a Minecraft player named \"" + skinName + "\" (or Mojang couldn't be reached).", NamedTextColor.RED);
                     } else {
                        int applied = 0;

                        for(UUID id : ids) {
                           Entity entity = Bukkit.getEntity(id);
                           if (entity instanceof Mannequin) {
                              Mannequin mannequin = (Mannequin)entity;
                              if (mannequin.isValid()) {
                                 try {
                                    mannequin.setProfile(ResolvableProfile.resolvableProfile(lookup));
                                    ++applied;
                                 } catch (Exception e) {
                                    Bukkit.getLogger().warning("[RppCommand] Failed to apply skin '" + skinName + "': " + e.getMessage());
                                 }
                              }
                           }
                        }

                        this.messagePlayer(playerId, "Set the skin of " + applied + " bot" + (applied == 1 ? "" : "s") + " to " + skinName + "'s.", applied > 0 ? NamedTextColor.GREEN : NamedTextColor.RED);
                     }
                  });
               });
            }
         }
      }
   }

   private void tickMocap(Companion c) {
      MocapPlayback pb = c.mocap;
      Mannequin bot = c.entity;
      MocapRecording recording = pb.recording;
      Location start = recording.startLocation();
      if (start != null && recording.size() != 0) {
         bot.setVelocity(new Vector((double)0.0F, (double)0.0F, (double)0.0F));
         if (pb.index >= recording.size()) {
            if (!pb.waitingToReset) {
               pb.waitingToReset = true;
               if (pb.sprinting) {
                  pb.sprinting = false;
                  c.sprintingVisual = false;
                  this.setMannequinSprinting(bot, false);
               }
            }

            if (this.tickCounter >= pb.nextWatchScanTick) {
               boolean watched = this.isMocapSpotWatched(bot.getLocation()) || this.isMocapSpotWatched(start);
               if (!watched && pb.changeCursor > 0) {
                  double[] midBlock = new double[]{(double)0.5F};

                  for(Location spot : recording.changeSpots(8)) {
                     if (this.isMocapSpotWatched(spot, midBlock)) {
                        watched = true;
                        break;
                     }
                  }
               }

               pb.watchedLastScan = watched;
               pb.nextWatchScanTick = this.tickCounter + 3L;
            }

            if (pb.watchedLastScan) {
               return;
            }

            pb.waitingToReset = false;
            pb.index = 0;
            revertMocapChanges(pb);
            this.refillMocapInventory(c, recording);
         }

         MocapFrame frame = recording.frame(pb.index);
         World world = start.getWorld();
         if (world.isChunkLoaded((int)Math.floor(frame.x()) >> 4, (int)Math.floor(frame.z()) >> 4)) {
            int frameNumber = pb.index++;
            bot.teleport(new Location(world, frame.x(), frame.y(), frame.z(), frame.yaw(), frame.pitch()));
            bot.setRotation(frame.yaw(), frame.pitch());
            Pose desired = Pose.STANDING;
            if (frame.sneaking()) {
               desired = Pose.SNEAKING;
            } else if (MocapRecorder.isFancyPose(frame.pose()) && Mannequin.validPoses().contains(frame.pose())) {
               desired = frame.pose();
            }

            if (desired != pb.pose) {
               pb.pose = desired;
               if (desired == Pose.SNEAKING) {
                  this.setMannequinSneaking(bot, true);
               } else if (desired == Pose.STANDING) {
                  this.setMannequinSneaking(bot, false);
               } else {
                  bot.setSneaking(false);
                  bot.setPose(desired);
               }
            }

            boolean sprint = frame.sprinting() && desired == Pose.STANDING;
            if (sprint != pb.sprinting) {
               pb.sprinting = sprint;
               c.sprintingVisual = sprint;
               this.setMannequinSprinting(bot, sprint);
            }

            if (frame.equipment() != null) {
               MocapRecorder.applyEquipment(bot.getEquipment(), frame.equipment());
            }

            this.applyMocapItemUse(bot, pb, frame);
            if (frame.swingMain()) {
               bot.swingMainHand();
            }

            if (frame.swingOff()) {
               bot.swingOffHand();
            }

            List<MocapBlockChange> changes = recording.changes();

            while(pb.changeCursor < changes.size() && ((MocapBlockChange)changes.get(pb.changeCursor)).frame() <= frameNumber) {
               MocapBlockChange change = (MocapBlockChange)changes.get(pb.changeCursor++);

               try {
                  this.applyMocapChange(c, change);
               } catch (Exception e) {
                  Bukkit.getLogger().warning("[RppCommand] Couldn't make a mocap block change: " + String.valueOf(e));
               }
            }

            List<MocapAction> actions = recording.actions();

            while(pb.actionCursor < actions.size() && ((MocapAction)actions.get(pb.actionCursor)).frame() <= frameNumber) {
               MocapAction action = (MocapAction)actions.get(pb.actionCursor++);

               try {
                  this.applyMocapAction(c, pb, action);
               } catch (Exception e) {
                  Logger var10000 = Bukkit.getLogger();
                  String var10001 = action.getClass().getSimpleName();
                  var10000.warning("[RppCommand] Couldn't replay a mocap action (" + var10001 + "): " + String.valueOf(e));
               }
            }

         }
      } else {
         c.releaseMocap();
      }
   }

   private void applyMocapItemUse(Mannequin bot, MocapPlayback pb, MocapFrame frame) {
      EquipmentSlot using = frame.usingHand();
      if (using != pb.usingHand) {
         pb.usingHand = using;
         if (using == null) {
            bot.clearActiveItem();
         } else {
            bot.startUsingItem(using);
         }
      } else if (using != null && bot.getActiveItemRemainingTime() <= 2) {
         bot.clearActiveItem();
         bot.startUsingItem(using);
      }

      if (frame.gliding() != pb.gliding) {
         pb.gliding = frame.gliding();
         bot.setGliding(pb.gliding);
      } else if (pb.gliding && !bot.isGliding()) {
         bot.setGliding(true);
      }

      if (frame.riptiding() != pb.riptiding) {
         pb.riptiding = frame.riptiding();
         bot.setRiptiding(pb.riptiding);
      }

   }

   private void applyMocapAction(Companion c, MocapPlayback pb, MocapAction action) {
      Objects.requireNonNull(action);
      byte var5 = 0;
      //$FF: var5->value
      //0->com/rppbot/plugin/mocap/MocapAction$Projectile
      //1->com/rppbot/plugin/mocap/MocapAction$ContainerOpen
      //2->com/rppbot/plugin/mocap/MocapAction$ContainerClose
      if (action instanceof MocapAction.Projectile shot) {
         this.replayMocapProjectile(c, pb, shot);
      } else if (action instanceof MocapAction.ContainerOpen open) {
         MocapRecorder.setLid(open.location(), true);
         pb.openLids.add(open.location());
         c.entity.swingMainHand();
      } else if (action instanceof MocapAction.ContainerClose close) {
         MocapRecorder.setLid(close.location(), false);
         pb.openLids.removeIf((l) -> l.getWorld() == close.location().getWorld() && l.getBlockX() == close.location().getBlockX() && l.getBlockY() == close.location().getBlockY() && l.getBlockZ() == close.location().getBlockZ());
      }

   }

   private void replayMocapProjectile(Companion c, MocapPlayback pb, MocapAction.Projectile shot) {
      Location at = shot.at().clone();
      World world = at.getWorld();
      Class<? extends Entity> type = shot.type().getEntityClass();
      if (world != null && type != null) {
         Mannequin bot = c.entity;
         Consumer<Entity> setup = (entity) -> {
            entity.getPersistentDataContainer().set(this.mocapShotKey, PersistentDataType.BYTE, (byte)1);
            entity.setPersistent(false);
            entity.setVelocity(shot.velocity().clone());
            if (entity instanceof Projectile projectile) {
               if (shot.type() != EntityType.ENDER_PEARL) {
                  projectile.setShooter(bot);
               }
            }

            if (entity instanceof AbstractArrow arrow) {
               if (shot.item() != null) {
                  arrow.setItemStack(shot.item().clone());
               }

               arrow.setCritical(shot.critical());
               arrow.setShotFromCrossbow(shot.fromCrossbow());
               arrow.setPierceLevel(shot.pierceLevel());
               arrow.setPickupStatus(PickupStatus.DISALLOWED);
            } else if (entity instanceof ThrownPotion potion) {
               if (shot.item() != null) {
                  potion.setItem(shot.item().clone());
               }
            } else if (entity instanceof ThrowableProjectile thrown) {
               if (shot.item() != null) {
                  thrown.setItem(shot.item().clone());
               }
            } else if (entity instanceof Firework rocket) {
               FireworkMeta meta = shot.fireworkMeta();
               if (meta != null) {
                  rocket.setFireworkMeta(meta.clone());
               }

               if (shot.attachedToShooter()) {
                  rocket.setAttachedTo(bot);
               }
            }

         };
         Entity spawned = world.spawn(at, type, setup);
         pb.spawnedProjectiles.add(spawned);
         if (pb.spawnedProjectiles.size() > 64) {
            pb.spawnedProjectiles.removeIf((e) -> !e.isValid());
         }

         String sound = (String)MOCAP_LAUNCH_SOUNDS.get(shot.type());
         if (sound != null) {
            world.playSound(at, sound, SoundCategory.PLAYERS, 1.0F, 1.0F);
         }

      }
   }

   private boolean isMocapShot(Entity entity) {
      return entity != null && entity.getPersistentDataContainer().has(this.mocapShotKey, PersistentDataType.BYTE);
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onMocapShotHit(ProjectileHitEvent event) {
      if (!this.mocapHarmEnabled && this.isMocapShot(event.getEntity()) && event.getHitEntity() instanceof Player) {
         event.setCancelled(true);
      }

   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onMocapPotionSplash(PotionSplashEvent event) {
      if (!this.mocapHarmEnabled && this.isMocapShot(event.getEntity())) {
         for(LivingEntity affected : new ArrayList<LivingEntity>(event.getAffectedEntities())) {
            if (affected instanceof Player) {
               event.setIntensity(affected, (double)0.0F);
            }
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onMocapFireworkDamage(EntityDamageByEntityEvent event) {
      if (!this.mocapHarmEnabled && event.getEntity() instanceof Player && event.getDamager() instanceof Firework && this.isMocapShot(event.getDamager())) {
         event.setCancelled(true);
      }

   }

   private Player mocapProjectileOwner(Projectile projectile) {
      ProjectileSource var3 = projectile.getShooter();
      if (var3 instanceof Player shooter) {
         return shooter;
      } else {
         Player var10000;
         if (projectile instanceof Firework rocket) {
            LivingEntity var4 = rocket.getAttachedTo();
            if (var4 instanceof Player rider) {
               var10000 = rider;
               return var10000;
            }
         }

         var10000 = null;
         return var10000;
      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onMocapProjectileLaunch(ProjectileLaunchEvent event) {
      if (!this.mocapRecorders.isEmpty()) {
         Player owner = this.mocapProjectileOwner(event.getEntity());
         MocapRecorder recorder = owner == null ? null : (MocapRecorder)this.mocapRecorders.get(owner.getUniqueId());
         if (recorder != null) {
            recorder.recordProjectile(event.getEntity());
         }

      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onMocapInventoryOpen(InventoryOpenEvent event) {
      MocapRecorder recorder = (MocapRecorder)this.mocapRecorders.get(event.getPlayer().getUniqueId());
      if (recorder != null) {
         recorder.recordContainerOpen(event.getInventory());
      }

   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onMocapInventoryClose(InventoryCloseEvent event) {
      MocapRecorder recorder = (MocapRecorder)this.mocapRecorders.get(event.getPlayer().getUniqueId());
      if (recorder != null) {
         recorder.recordContainerClose();
      }

   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = false
   )
   public void onMocapInteract(PlayerInteractEvent event) {
      if (event.getAction() == Action.RIGHT_CLICK_BLOCK && event.getHand() == EquipmentSlot.HAND) {
         MocapRecorder recorder = (MocapRecorder)this.mocapRecorders.get(event.getPlayer().getUniqueId());
         Block clicked = event.getClickedBlock();
         if (recorder != null && clicked != null && event.useInteractedBlock() != Result.DENY) {
            recorder.noteClickedBlock(clicked);
            this.captureMocapStateChanges(event.getPlayer().getUniqueId(), recorder, List.of(clicked, clicked.getRelative(BlockFace.UP), clicked.getRelative(BlockFace.DOWN)));
         }
      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onMocapBucketEmpty(PlayerBucketEmptyEvent event) {
      MocapRecorder recorder = (MocapRecorder)this.mocapRecorders.get(event.getPlayer().getUniqueId());
      if (recorder != null) {
         this.captureMocapStateChanges(event.getPlayer().getUniqueId(), recorder, List.of(event.getBlock(), event.getBlockClicked()));
      }

   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onMocapBucketFill(PlayerBucketFillEvent event) {
      MocapRecorder recorder = (MocapRecorder)this.mocapRecorders.get(event.getPlayer().getUniqueId());
      if (recorder != null) {
         this.captureMocapStateChanges(event.getPlayer().getUniqueId(), recorder, List.of(event.getBlock(), event.getBlockClicked()));
      }

   }

   private void captureMocapStateChanges(UUID playerId, MocapRecorder recorder, List<Block> blocks) {
      Map<Block, BlockState> watched = new LinkedHashMap();

      for(Block block : blocks) {
         watched.putIfAbsent(block, block.getState());
      }

      int startFrame = recorder.frameCount();

      for(long delay : new long[]{1L, 45L}) {
         Bukkit.getGlobalRegionScheduler().runDelayed(this.plugin, (task) -> {
            if (this.mocapRecorders.get(playerId) == recorder) {
               int frame = delay == 1L ? startFrame : recorder.frameCount();

               for(Map.Entry<Block, BlockState> entry : watched.entrySet()) {
                  BlockData now = ((Block)entry.getKey()).getBlockData();
                  BlockState was = (BlockState)entry.getValue();
                  if (!now.equals(was.getBlockData()) && (delay != 1L || !recorder.hasChangeAt(((Block)entry.getKey()).getLocation(), startFrame))) {
                     recorder.recordChange(frame, was, now, (Material)null);
                     entry.setValue(((Block)entry.getKey()).getState());
                  }
               }

            }
         }, delay);
      }

   }

   private boolean isMocapSpotWatched(Location spot) {
      return this.isMocapSpotWatched(spot, new double[]{0.3, (double)1.0F, 1.7});
   }

   private boolean isMocapSpotWatched(Location spot, double[] heights) {
      World world = spot.getWorld();
      if (world == null) {
         return false;
      } else {
         for(Player p : world.getPlayers()) {
            if (p.isValid() && !p.isDead() && p.getGameMode() != GameMode.SPECTATOR) {
               Location eye = p.getEyeLocation();
               Vector look = eye.getDirection().normalize();

               for(double h : heights) {
                  Vector to = (new Vector(spot.getX(), spot.getY() + h, spot.getZ())).subtract(eye.toVector());
                  double dist = to.length();
                  if (!(dist > (double)96.0F)) {
                     if (dist < 1.0E-4) {
                        return true;
                     }

                     double angle = Math.toDegrees((double)look.angle(to));
                     if (!(angle > (double)65.0F) && world.rayTraceBlocks(eye, to.clone().normalize(), dist, FluidCollisionMode.NEVER, true) == null) {
                        return true;
                     }
                  }
               }
            }
         }

         return false;
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
      if (args.length == 1) {
         String partial = args[0].toLowerCase();
         return SUBCOMMANDS.stream().filter((s) -> s.startsWith(partial)).toList();
      } else {
         if (args.length == 2) {
            if (args[0].equalsIgnoreCase("setskin")) {
               String partial = args[1].toLowerCase();
               List<String> options = new ArrayList();
               if ("@a".startsWith(partial)) {
                  options.add("@a");
               }

               for(Companion c : this.companions.values()) {
                  if (c.botName != null && c.botName.toLowerCase().startsWith(partial)) {
                     options.add(c.botName);
                  }
               }

               return options;
            }

            if (args[0].equalsIgnoreCase("mocap")) {
               String partial = args[1].toLowerCase();
               return List.of("start", "stop", "cancel").stream().filter((s) -> s.startsWith(partial)).toList();
            }

            if (args[0].equalsIgnoreCase("attack")) {
               String partial = args[1].toLowerCase();
               List<String> options = new ArrayList();
               if ("@a".startsWith(partial)) {
                  options.add("@a");
               }

               Stream<String> var10000 = Bukkit.getOnlinePlayers().stream().map(Player::getName).filter((name) -> name.toLowerCase().startsWith(partial));
               Objects.requireNonNull(options);
               Objects.requireNonNull(options);
               var10000.forEach(options::add);
               return options;
            }

            if (args[0].equalsIgnoreCase("spawn")) {
               String partial = args[1];
               return List.of("1", "5", "10").stream().filter((s) -> s.startsWith(partial)).toList();
            }

            if (args[0].equalsIgnoreCase("roam")) {
               String partial = args[1];
               return List.of("20", "50", "100").stream().filter((s) -> s.startsWith(partial)).toList();
            }

            if (args[0].equalsIgnoreCase("waypoint")) {
               String partial = args[1].toLowerCase();
               return WAYPOINT_ACTIONS.stream().filter((s) -> s.startsWith(partial)).toList();
            }

            if (args[0].equalsIgnoreCase("patrol")) {
               String partial = args[1].toLowerCase();
               return this.waypointNetworks.values().stream().map((n) -> n.name).filter((n) -> n.toLowerCase().startsWith(partial)).toList();
            }

            if (args[0].equalsIgnoreCase("jump")) {
               String partial = args[1].toLowerCase();
               return List.of("--random").stream().filter((s) -> s.startsWith(partial)).toList();
            }

            if (args[0].equalsIgnoreCase("load")) {
               String partial = args[1].toLowerCase();
               return this.listPresetNames().stream().filter((s) -> s.toLowerCase().startsWith(partial)).toList();
            }

            if (args[0].equalsIgnoreCase("formation")) {
               String partial = args[1].toLowerCase();
               return List.of("follow", "stop").stream().filter((s) -> s.startsWith(partial)).toList();
            }

            if (args[0].equalsIgnoreCase("schem")) {
               String partial = args[1].toLowerCase();
               return this.listSchematicTokens().stream().filter((n) -> n.toLowerCase().startsWith(partial)).toList();
            }

            if (args[0].equalsIgnoreCase("build")) {
               String partial = args[1].toLowerCase();
               return this.loadedSchematics.values().stream().map((l) -> l.name.replace(' ', '_')).filter((n) -> n.toLowerCase().startsWith(partial)).toList();
            }

            if (this.findSchematicFile(args[0]) != null || this.lookupLoaded(args[0]) != null) {
               String partial = args[1].toLowerCase();
               return SCHEM_ACTIONS.stream().filter((s) -> s.startsWith(partial)).toList();
            }
         }

         if (args.length == 3 && args[0].equalsIgnoreCase("setskin")) {
            String partial = args[2].toLowerCase();
            return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter((n) -> n.toLowerCase().startsWith(partial)).toList();
         } else if (args.length == 4 && args[0].equalsIgnoreCase("schem") && args[2].equalsIgnoreCase("rotate")) {
            String partial = args[3].toLowerCase();
            return ROTATE_AMOUNTS.stream().filter((s) -> s.startsWith(partial)).toList();
         } else if (args.length == 3 && args[0].equalsIgnoreCase("schem")) {
            String partial = args[2].toLowerCase();
            return SCHEM_ACTIONS.stream().filter((s) -> s.startsWith(partial)).toList();
         } else if (args.length != 3 || !args[1].equalsIgnoreCase("rotate") || this.findSchematicFile(args[0]) == null && this.lookupLoaded(args[0]) == null) {
            if (args.length == 3 && args[0].equalsIgnoreCase("waypoint")) {
               String action = args[1].toLowerCase();
               if (action.equals("delete") || action.equals("addpoint") || action.equals("removepoint") || action.equals("connect") || action.equals("disconnect") || action.equals("rename") || action.equals("list")) {
                  String partial = args[2].toLowerCase();
                  return this.waypointNetworks.values().stream().map((n) -> n.name).filter((n) -> n.toLowerCase().startsWith(partial)).toList();
               }
            }

            if (args.length >= 2 && BOT_TARGETABLE_SUBCOMMANDS.contains(args[0].toLowerCase())) {
               String partial = args[args.length - 1].toLowerCase();
               List<String> names = this.companions.values().stream().map((cx) -> cx.botName).filter((n) -> n != null && n.toLowerCase().startsWith(partial)).toList();
               if (!names.isEmpty()) {
                  return names;
               }
            }

            return List.of();
         } else {
            String partial = args[2].toLowerCase();
            return ROTATE_AMOUNTS.stream().filter((s) -> s.startsWith(partial)).toList();
         }
      }
   }

   static {
      MOCAP_LAUNCH_SOUNDS = Map.ofEntries(Map.entry(EntityType.ARROW, "entity.arrow.shoot"), Map.entry(EntityType.SPECTRAL_ARROW, "entity.arrow.shoot"), Map.entry(EntityType.TRIDENT, "item.trident.throw"), Map.entry(EntityType.SNOWBALL, "entity.snowball.throw"), Map.entry(EntityType.EGG, "entity.egg.throw"), Map.entry(EntityType.ENDER_PEARL, "entity.ender_pearl.throw"), Map.entry(EntityType.EXPERIENCE_BOTTLE, "entity.experience_bottle.throw"), Map.entry(EntityType.SPLASH_POTION, "entity.splash_potion.throw"), Map.entry(EntityType.LINGERING_POTION, "entity.lingering_potion.throw"), Map.entry(EntityType.WIND_CHARGE, "entity.wind_charge.throw"));
      AUTO_REFILL_FOOD = Material.BREAD;
      HORIZONTAL_OFFSETS = new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}};
      JUMP_OFFSETS = new int[][]{{2, 0}, {-2, 0}, {0, 2}, {0, -2}};
      TOOL_TIERS = new String[]{"WOODEN", "GOLDEN", "STONE", "IRON", "DIAMOND", "NETHERITE"};
      TIER_DAMAGE_BONUS = Map.of("WOODEN", (double)0.0F, "GOLDEN", (double)0.0F, "STONE", (double)1.0F, "IRON", (double)2.0F, "DIAMOND", (double)3.0F, "NETHERITE", (double)4.0F);
      AXE_DAMAGE_BONUS = Map.of("WOODEN", (double)0.0F, "GOLDEN", (double)0.0F, "STONE", (double)2.0F, "IRON", (double)2.0F, "DIAMOND", (double)2.0F, "NETHERITE", (double)3.0F);
      HEADER_EDITABLE_SLOTS = Set.of(0, 1, 3, 4, 5, 6);
      FOOD_RESTORE_AMOUNTS = Map.ofEntries(Map.entry(Material.BREAD, (double)5.0F), Map.entry(Material.COOKED_BEEF, (double)8.0F), Map.entry(Material.COOKED_PORKCHOP, (double)8.0F), Map.entry(Material.COOKED_CHICKEN, (double)6.0F), Map.entry(Material.COOKED_MUTTON, (double)6.0F), Map.entry(Material.COOKED_RABBIT, (double)5.0F), Map.entry(Material.COOKED_COD, (double)5.0F), Map.entry(Material.COOKED_SALMON, (double)6.0F), Map.entry(Material.APPLE, (double)4.0F), Map.entry(Material.GOLDEN_APPLE, (double)4.0F), Map.entry(Material.GOLDEN_CARROT, (double)6.0F), Map.entry(Material.CARROT, (double)3.0F), Map.entry(Material.BAKED_POTATO, (double)5.0F), Map.entry(Material.PUMPKIN_PIE, (double)8.0F), Map.entry(Material.COOKIE, (double)2.0F), Map.entry(Material.MUSHROOM_STEW, (double)6.0F), Map.entry(Material.RABBIT_STEW, (double)10.0F), Map.entry(Material.BEETROOT_SOUP, (double)6.0F), Map.entry(Material.SWEET_BERRIES, (double)2.0F), Map.entry(Material.HONEY_BOTTLE, (double)6.0F));
   }

   private static final class WaypointNode {
      final int id;
      Location location;
      final Set<Integer> connections = new HashSet();

      WaypointNode(int id, Location location) {
         this.id = id;
         this.location = location;
      }
   }

   private static final class WaypointNetwork {
      String name;
      final Map<Integer, WaypointNode> nodes = new LinkedHashMap();
      int nextId = 1;

      WaypointNetwork(String name) {
         this.name = name;
      }

      WaypointNode addPoint(Location loc) {
         WaypointNode node = new WaypointNode(this.nextId++, loc.clone());
         this.nodes.put(node.id, node);
         return node;
      }

      boolean removePoint(int id) {
         WaypointNode removed = (WaypointNode)this.nodes.remove(id);
         if (removed == null) {
            return false;
         } else {
            for(WaypointNode node : this.nodes.values()) {
               node.connections.remove(id);
            }

            return true;
         }
      }

      boolean connect(int a, int b) {
         WaypointNode nodeA = (WaypointNode)this.nodes.get(a);
         WaypointNode nodeB = (WaypointNode)this.nodes.get(b);
         if (nodeA != null && nodeB != null && a != b) {
            nodeA.connections.add(b);
            nodeB.connections.add(a);
            return true;
         } else {
            return false;
         }
      }

      boolean disconnect(int a, int b) {
         WaypointNode nodeA = (WaypointNode)this.nodes.get(a);
         WaypointNode nodeB = (WaypointNode)this.nodes.get(b);
         if (nodeA != null && nodeB != null) {
            boolean removed = nodeA.connections.remove(b);
            nodeB.connections.remove(a);
            return removed;
         } else {
            return false;
         }
      }

      WaypointNode nearest(Location from) {
         WaypointNode best = null;
         double bestDist = Double.MAX_VALUE;

         for(WaypointNode node : this.nodes.values()) {
            if (node.location.getWorld() != null && node.location.getWorld().equals(from.getWorld())) {
               double dist = node.location.distance(from);
               if (dist < bestDist) {
                  bestDist = dist;
                  best = node;
               }
            }
         }

         return best;
      }

      WaypointNode nextNode(int currentId, Integer previousId, boolean random) {
         WaypointNode current = (WaypointNode)this.nodes.get(currentId);
         if (current != null && !current.connections.isEmpty()) {
            if (random) {
               List<Integer> options = new ArrayList(current.connections);
               return (WaypointNode)this.nodes.get(options.get(ThreadLocalRandom.current().nextInt(options.size())));
            } else {
               List<Integer> forwardOptions = new ArrayList(current.connections);
               if (previousId != null) {
                  forwardOptions.remove(previousId);
               }

               if (forwardOptions.isEmpty()) {
                  forwardOptions = new ArrayList(current.connections);
               }

               int next = -1;

               for(int candidate : forwardOptions) {
                  if (next == -1 || candidate < next) {
                     next = candidate;
                  }
               }

               return (WaypointNode)this.nodes.get(next);
            }
         } else {
            return null;
         }
      }
   }

   private static final class MannequinRecord {
      boolean following;
      boolean attacking;
      boolean roaming;
      UUID moveTargetId;
      Location roamCenter;
      double roamRadius;
      boolean patrolling;
      String patrolNetwork;
      Integer patrolCurrentNodeId;
      Integer patrolTargetNodeId;
      boolean patrolRandom;
      boolean jumping;
      boolean jumpRandom;
      boolean formation;
      Integer formationIndex;
      double hunger = (double)20.0F;
      ItemStack[] storageContents;
      int storedXp;
      String botName;
   }

   private static final class Companion {
      final Mannequin entity;
      boolean following;
      boolean attacking;
      boolean roaming;
      UUID moveTargetId;
      long lastAttackTick = Long.MIN_VALUE;
      long knockbackUntilTick = Long.MIN_VALUE;
      boolean sprintingVisual = false;
      Location roamCenter;
      double roamRadius;
      Location roamDestination;
      long roamPauseUntilTick = Long.MIN_VALUE;
      boolean patrolling;
      String patrolNetwork;
      Integer patrolCurrentNodeId;
      Integer patrolTargetNodeId;
      Integer patrolPreviousNodeId;
      boolean patrolRandom;
      boolean jumping;
      boolean jumpRandom;
      long nextJumpTick = Long.MIN_VALUE;
      boolean formation;
      Integer formationIndex;
      List<Location> currentPath;
      int pathIndex;
      Location lastPathGoal;
      long lastPathComputeTick = Long.MIN_VALUE;
      final ItemStack[] storageContents = new ItemStack[45];
      int storedXp = 0;
      double hunger = (double)20.0F;
      long eatingUntilTick = Long.MIN_VALUE;
      ItemStack preEatMainHand;
      double pendingHungerRestore = (double)0.0F;
      Material eatingFoodType;
      long pearlEscapeCooldownUntilTick = Long.MIN_VALUE;
      int strafeDirection = 1;
      double strafeRadialBias = (double)0.0F;
      long nextStrafeFlipTick = Long.MIN_VALUE;
      String botName;
      UUID tabId;
      Player cachedWatcher;
      long nextWatcherScanTick = Long.MIN_VALUE;
      boolean loveMode = false;
      long loveModeUntilTick = Long.MIN_VALUE;
      UUID breedingPartnerId;
      long breedingBeginTick = Long.MIN_VALUE;
      boolean isBaby = false;
      long growUpAtTick = Long.MIN_VALUE;
      boolean building = false;
      BuildJob buildJob;
      int buildPhase;
      int[] buildBatch;
      int buildBatchPos;
      Location buildChestLoc;
      Location openChestLoc;
      Map<Material, Integer> buildDeficit;
      long buildPhaseStartTick = Long.MIN_VALUE;
      long buildWaitUntilTick = Long.MIN_VALUE;
      long nextPlaceTick = Long.MIN_VALUE;
      long buildProgressTick = Long.MIN_VALUE;
      int buildStuckStage;
      double humanNoiseX;
      double humanNoiseZ;
      long nextHumanCorrectionTick = Long.MIN_VALUE;
      float humanTargetYaw;
      boolean humanHasTargetYaw;
      MocapPlayback mocap;
      final WasdKeys keys = new WasdKeys();
      final double[] motorVel = new double[2];
      final double[] wishScratch = new double[2];
      long lastMotorTick = Long.MIN_VALUE / 2L;
      boolean forceJump;
      long sprintLockUntilTick = Long.MIN_VALUE;
      UUID combatTargetId;
      long engageReadyTick = Long.MIN_VALUE;
      int aimDelay = 1;
      int attackStyle = -1;
      long readySince = Long.MIN_VALUE;
      boolean critJumped;
      final Vector[] aimHistory = new Vector[3];
      int aimHistoryPos;
      double aimNoiseYaw;
      double aimNoisePitch;
      long nextAimNoiseTick = Long.MIN_VALUE;
      double chargeThreshold = 0.95;
      boolean strafeIdle;
      boolean shieldUp;
      long shieldRaisedAt = Long.MIN_VALUE;
      long shieldReactAt = Long.MIN_VALUE;
      long shieldDisabledUntilTick = Long.MIN_VALUE;
      boolean shieldDefendThisCycle = true;
      boolean fleeing;
      int fleeBlockedTicks;
      long lastHitTakenTick = Long.MIN_VALUE;

      Companion(Mannequin entity) {
         this.entity = entity;
      }

      Companion(Mannequin entity, String botName) {
         this.entity = entity;
         this.botName = botName;
      }

      void resetPath() {
         this.currentPath = null;
         this.pathIndex = 0;
         this.lastPathGoal = null;
         this.lastPathComputeTick = Long.MIN_VALUE;
      }

      void releaseMocap() {
         if (this.mocap != null) {
            if (this.mocap.usingHand != null) {
               this.entity.clearActiveItem();
            }

            if (this.mocap.gliding) {
               this.entity.setGliding(false);
            }

            if (this.mocap.riptiding) {
               this.entity.setRiptiding(false);
            }

            RppCommand.revertMocapChanges(this.mocap);
            this.mocap = null;
         }

      }

      void releaseBuild() {
         this.releaseMocap();
         if (this.openChestLoc != null) {
            RppCommand.closeChestQuietly(this.openChestLoc);
            this.openChestLoc = null;
         }

         if (this.buildJob != null && this.buildBatch != null && this.buildBatchPos < this.buildBatch.length) {
            this.buildJob.giveBack(this.buildBatch, this.buildBatchPos);
         }

         this.building = false;
         this.buildJob = null;
         this.buildPhase = 0;
         this.buildBatch = null;
         this.buildBatchPos = 0;
         this.buildChestLoc = null;
         this.buildDeficit = null;
         this.buildStuckStage = 0;
      }

      void resetMode() {
         if (this.shieldUp) {
            this.shieldUp = false;
            this.entity.clearActiveItem();
         }

         this.fleeing = false;
         this.combatTargetId = null;
         this.releaseBuild();
         this.mocap = null;
         this.following = false;
         this.attacking = false;
         this.roaming = false;
         this.moveTargetId = null;
         this.roamCenter = null;
         this.roamDestination = null;
         this.roamPauseUntilTick = Long.MIN_VALUE;
         this.patrolling = false;
         this.patrolNetwork = null;
         this.patrolCurrentNodeId = null;
         this.patrolTargetNodeId = null;
         this.patrolPreviousNodeId = null;
         this.patrolRandom = false;
         this.jumping = false;
         this.jumpRandom = false;
         this.nextJumpTick = Long.MIN_VALUE;
         this.formation = false;
         this.formationIndex = null;
         this.loveMode = false;
         this.breedingPartnerId = null;
         this.breedingBeginTick = Long.MIN_VALUE;
         this.resetPath();
      }
   }

   private static final class CompanionGuiHolder implements InventoryHolder {
      private final UUID mannequinId;
      private Inventory inventory;

      private CompanionGuiHolder(UUID mannequinId) {
         this.mannequinId = mannequinId;
      }

      public Inventory getInventory() {
         return this.inventory;
      }

      private void setInventory(Inventory inventory) {
         this.inventory = inventory;
      }
   }

   private static record SettingsToggle(int slot, Material icon, String label, String description, boolean enabled) {
   }

   private static final class SettingsGuiHolder implements InventoryHolder {
      private Inventory inventory;

      public Inventory getInventory() {
         return this.inventory;
      }

      private void setInventory(Inventory inventory) {
         this.inventory = inventory;
      }
   }

   private static final class PathNode {
      final int x;
      final int y;
      final int z;
      double g;
      double f;
      PathNode parent;

      PathNode(int x, int y, int z) {
         this.x = x;
         this.y = y;
         this.z = z;
      }
   }
}
