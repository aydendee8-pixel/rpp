package com.rppbot.plugin;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

/** Owner-only RPP administration. Server revocations stored here are local to this installation. */
public final class AdminRppCommand implements CommandExecutor, TabCompleter {
    private static final List<String> OWNERS = List.of("mrracgoon", "f_pp");
    private static final Pattern IPV4 = Pattern.compile("^(?:(?:25[0-5]|2[0-4]\\d|1?\\d?\\d)\\.){3}(?:25[0-5]|2[0-4]\\d|1?\\d?\\d)$");
    private final JavaPlugin plugin;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(4)).build();

    public AdminRppCommand(JavaPlugin plugin) { this.plugin = plugin; }

    private boolean allowed(CommandSender sender) {
        if (sender instanceof org.bukkit.entity.Player p && OWNERS.contains(p.getName().toLowerCase(Locale.ROOT))) return true;
        sender.sendMessage("You are not authorized to use RPP administration.");
        return false;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!allowed(sender)) return true;
        if (args.length == 1 && args[0].equalsIgnoreCase("identify")) {
            sender.sendMessage("RPP installation ID: " + plugin.getConfig().getString("installation-id", "not generated"));
            sender.sendMessage("Detecting public IP...");
            Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
                String result;
                try {
                    HttpRequest request = HttpRequest.newBuilder(URI.create("https://api.ipify.org")).timeout(Duration.ofSeconds(5)).GET().build();
                    result = http.send(request, HttpResponse.BodyHandlers.ofString()).body().trim();
                    if (!IPV4.matcher(result).matches()) result = "could not verify IPv4 address";
                } catch (Exception ex) { result = "unavailable (check internet access)"; }
                String ip = result;
                Bukkit.getScheduler().runTask(plugin, () -> sender.sendMessage("Detected public IPv4: " + ip));
            });
            return true;
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("serverban")) {
            String ip = args[1].trim();
            if (!IPV4.matcher(ip).matches()) {
                sender.sendMessage("Usage: /adminrpp serverban <IPv4 address>");
                return true;
            }
            List<String> bans = plugin.getConfig().getStringList("server-bans");
            if (bans.stream().anyMatch(ip::equalsIgnoreCase)) {
                sender.sendMessage("That IP is already in this installation's server-ban list.");
                return true;
            }
            bans.add(ip);
            plugin.getConfig().set("server-bans", bans);
            plugin.saveConfig();
            sender.sendMessage("Added " + ip + " to this installation's RPP server-ban list.");
            sender.sendMessage("Note: this local list does not revoke RPP on remote servers; global bans require a shared authorization host.");
            return true;
        }
        sender.sendMessage("RPP admin commands: /adminrpp identify, /adminrpp serverban <IP>");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!allowed(sender)) return List.of();
        if (args.length == 1) return List.of("identify", "serverban").stream().filter(s -> s.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();
        return List.of();
    }
}
