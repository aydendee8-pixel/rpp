package com.rppbot.plugin.schematic;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

public final class Nbt {
   private static final int MAX_ARRAY_BYTES = 536870912;
   private static final int MAX_DEPTH = 512;

   private Nbt() {
   }

   public static Map<String, Object> readFile(File file) throws IOException {
      InputStream raw = new BufferedInputStream(new FileInputStream(file));

      Map var7;
      try {
         raw.mark(2);
         int b1 = raw.read();
         int b2 = raw.read();
         raw.reset();
         InputStream in = (InputStream)(b1 == 31 && b2 == 139 ? new GZIPInputStream(raw, 65536) : raw);
         DataInputStream data = new DataInputStream(new BufferedInputStream(in, 65536));

         try {
            int type = data.readUnsignedByte();
            if (type != 10) {
               throw new IOException("Not an NBT file (root tag is not a compound).");
            }

            data.readUTF();
            var7 = readCompound(data, 0);
         } catch (Throwable var10) {
            try {
               data.close();
            } catch (Throwable var9) {
               var10.addSuppressed(var9);
            }

            throw var10;
         }

         data.close();
      } catch (Throwable var11) {
         try {
            raw.close();
         } catch (Throwable var8) {
            var11.addSuppressed(var8);
         }

         throw var11;
      }

      raw.close();
      return var7;
   }

   private static Map<String, Object> readCompound(DataInputStream in, int depth) throws IOException {
      if (depth > 512) {
         throw new IOException("NBT nesting too deep.");
      } else {
         Map<String, Object> map = new LinkedHashMap();

         while(true) {
            int type = in.readUnsignedByte();
            if (type == 0) {
               return map;
            }

            String name = in.readUTF();
            map.put(name, readPayload(in, type, depth + 1));
         }
      }
   }

   private static Object readPayload(DataInputStream in, int type, int depth) throws IOException {
      switch (type) {
         case 1:
            return in.readByte();
         case 2:
            return in.readShort();
         case 3:
            return in.readInt();
         case 4:
            return in.readLong();
         case 5:
            return in.readFloat();
         case 6:
            return in.readDouble();
         case 7: {
            int len = checkLength(in.readInt(), 1);
            byte[] arr = new byte[len];
            in.readFully(arr);
            return arr;
         }
         case 8:
            return in.readUTF();
         case 9: {
            int elementType = in.readUnsignedByte();
            int len = in.readInt();
            if (len < 0) {
               throw new IOException("Negative NBT list length.");
            }

            List<Object> list = new ArrayList(Math.min(len, 1024));

            for(int i = 0; i < len; ++i) {
               list.add(readPayload(in, elementType, depth + 1));
            }

            return list;
         }
         case 10:
            return readCompound(in, depth + 1);
         case 11: {
            int len = checkLength(in.readInt(), 4);
            int[] arr = new int[len];

            for(int i = 0; i < len; ++i) {
               arr[i] = in.readInt();
            }

            return arr;
         }
         case 12: {
            int len = checkLength(in.readInt(), 8);
            long[] arr = new long[len];

            for(int i = 0; i < len; ++i) {
               arr[i] = in.readLong();
            }

            return arr;
         }
         default:
            throw new IOException("Unknown NBT tag type " + type);
      }
   }

   private static int checkLength(int len, int elementBytes) throws IOException {
      if (len >= 0 && (long)len * (long)elementBytes <= 536870912L) {
         return len;
      } else {
         throw new IOException("NBT array too large (" + len + " elements).");
      }
   }

   public static Map<String, Object> compound(Map<String, Object> parent, String key) {
      Object o = parent.get(key);
      return o instanceof Map ? (Map)o : null;
   }

   public static List<Object> list(Map<String, Object> parent, String key) {
      Object o = parent.get(key);
      return o instanceof List ? (List)o : null;
   }

   public static int intValue(Map<String, Object> parent, String key, int fallback) {
      Object o = parent.get(key);
      int var10000;
      if (o instanceof Number n) {
         var10000 = n.intValue();
      } else {
         var10000 = fallback;
      }

      return var10000;
   }

   public static String string(Map<String, Object> parent, String key) {
      Object o = parent.get(key);
      String var10000;
      if (o instanceof String s) {
         var10000 = s;
      } else {
         var10000 = null;
      }

      return var10000;
   }
}
