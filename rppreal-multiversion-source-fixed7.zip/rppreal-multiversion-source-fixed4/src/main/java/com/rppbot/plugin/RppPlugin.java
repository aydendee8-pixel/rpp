package com.rppbot.plugin;

import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class RppPlugin extends JavaPlugin {
   private RppCommand rppCommand;
   private AdminRppCommand adminRppCommand;

   public void onEnable() {
      if (this.getResource("config.yml") != null) {
         this.saveDefaultConfig();
      } else {
         this.getDataFolder().mkdirs();
      }
      if (!this.getConfig().contains("installation-id")) {
         this.getConfig().set("installation-id", java.util.UUID.randomUUID().toString());
         this.saveConfig();
      }
      this.rppCommand = new RppCommand(this);
      this.adminRppCommand = new AdminRppCommand(this);
      PluginCommand adminCommand = this.getCommand("adminrpp");
      if (adminCommand == null) {
         this.getLogger().severe("Could not find the adminrpp command in plugin.yml.");
         Bukkit.getPluginManager().disablePlugin(this);
         return;
      }
      adminCommand.setExecutor(this.adminRppCommand);
      adminCommand.setTabCompleter(this.adminRppCommand);
      PluginCommand command = this.getCommand("rpp");
      if (command == null) {
         this.getLogger().severe("Could not find the 'rpp' command - check plugin.yml.");
         Bukkit.getPluginManager().disablePlugin(this);
      } else {
         command.setExecutor(this.rppCommand);
         command.setTabCompleter(this.rppCommand);
         Bukkit.getPluginManager().registerEvents(this.rppCommand, this);
         this.getLogger().info("RPP enabled.");
      }

   }

   public void onDisable() {
      if (this.rppCommand != null) {
         this.rppCommand.shutdown();
      }

      this.getLogger().info("RPP disabled.");
   }
}
