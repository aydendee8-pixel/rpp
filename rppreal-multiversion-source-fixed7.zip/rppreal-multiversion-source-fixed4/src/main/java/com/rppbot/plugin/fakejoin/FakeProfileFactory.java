package com.rppbot.plugin.fakejoin;

import com.destroystokyo.paper.profile.PlayerProfile;
import com.destroystokyo.paper.profile.ProfileProperty;
import java.lang.reflect.Method;
import java.util.UUID;
import org.bukkit.Bukkit;

final class FakeProfileFactory {
   private FakeProfileFactory() {
   }

   static Object resolve(String fakeName, UUID fakeId, String skinName) {
      Object emptyProfile = buildBareGameProfile(fakeName, fakeId);

      try {
         PlayerProfile lookup = Bukkit.createProfile(skinName);
         boolean resolved = lookup.complete();
         if (!resolved) {
            return emptyProfile;
         }

         Object skinProperty = firstTexturesProperty(lookup);
         if (skinProperty == null) {
            return emptyProfile;
         }

         addProperty(emptyProfile, skinProperty);
      } catch (Exception e) {
         NmsBridge.warn("Skin lookup for '" + skinName + "' failed, joining with no skin", e);
      }

      return emptyProfile;
   }

   static Object buildBareGameProfile(String fakeName, UUID fakeId) {
      try {
         Class<?> gameProfileClass = Class.forName("com.mojang.authlib.GameProfile");
         return gameProfileClass.getConstructor(UUID.class, String.class).newInstance(fakeId, fakeName);
      } catch (ReflectiveOperationException e) {
         throw new IllegalStateException("com.mojang.authlib.GameProfile is not on the server classpath", e);
      }
   }

   private static Object firstTexturesProperty(PlayerProfile paperProfile) throws ReflectiveOperationException {
      for(ProfileProperty paperProperty : paperProfile.getProperties()) {
         if ("textures".equals(paperProperty.getName())) {
            Class<?> propertyClass = Class.forName("com.mojang.authlib.properties.Property");

            try {
               return propertyClass.getConstructor(String.class, String.class, String.class).newInstance(paperProperty.getName(), paperProperty.getValue(), paperProperty.getSignature());
            } catch (NoSuchMethodException var5) {
               return propertyClass.getConstructor(String.class, String.class).newInstance(paperProperty.getName(), paperProperty.getValue());
            }
         }
      }

      return null;
   }

   private static void addProperty(Object gameProfile, Object property) throws ReflectiveOperationException {
      Method getProperties = gameProfile.getClass().getMethod("getProperties");
      Object propertyMap = getProperties.invoke(gameProfile);
      Method put = findPutMethod(propertyMap.getClass());
      put.invoke(propertyMap, "textures", property);
   }

   private static Method findPutMethod(Class<?> propertyMapClass) throws NoSuchMethodException {
      for(Method m : propertyMapClass.getMethods()) {
         if (m.getName().equals("put") && m.getParameterCount() == 2) {
            return m;
         }
      }

      throw new NoSuchMethodException(propertyMapClass.getName() + "#put(Object, Object)");
   }
}
