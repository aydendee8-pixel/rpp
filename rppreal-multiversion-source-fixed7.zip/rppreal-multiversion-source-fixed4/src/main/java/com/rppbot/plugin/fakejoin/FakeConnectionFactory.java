package com.rppbot.plugin.fakejoin;

import io.netty.channel.ChannelPipeline;
import io.netty.channel.embedded.EmbeddedChannel;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.InetSocketAddress;

final class FakeConnectionFactory {
   private FakeConnectionFactory() {
   }

   static Object create(InetAddress fakeAddress) throws ReflectiveOperationException {
      Class<?> connectionClass = Class.forName("net.minecraft.network.Connection");
      Class<?> packetFlowClass = Class.forName("net.minecraft.network.protocol.PacketFlow");
      Object serverboundFlow = packetFlowEnumConstant(packetFlowClass, "SERVERBOUND");
      Constructor<?> ctor = connectionClass.getDeclaredConstructor(packetFlowClass);
      ctor.setAccessible(true);
      Object connection = ctor.newInstance(serverboundFlow);
      EmbeddedChannel channel = new EmbeddedChannel();
      tryConfigureSerialization(connectionClass, packetFlowClass, channel, serverboundFlow);
      setField(connection, connectionClass, "channel", channel);
      setField(connection, connectionClass, "address", new InetSocketAddress(fakeAddress, 0));
      return connection;
   }

   private static Object packetFlowEnumConstant(Class<?> packetFlowClass, String name) {
      for(Object constant : packetFlowClass.getEnumConstants()) {
         if (((Enum)constant).name().equals(name)) {
            return constant;
         }
      }

      throw new IllegalStateException("PacketFlow has no constant named " + name);
   }

   private static void tryConfigureSerialization(Class<?> connectionClass, Class<?> packetFlowClass, EmbeddedChannel channel, Object flow) {
      for(String methodName : new String[]{"configureSerialization", "setupPipeline"}) {
         try {
            Method method = connectionClass.getDeclaredMethod(methodName, ChannelPipeline.class, packetFlowClass, Boolean.TYPE, Class.forName("net.minecraft.network.protocol.BundlerInfo"));
            method.setAccessible(true);
            method.invoke((Object)null, channel.pipeline(), flow, false, null);
            return;
         } catch (ReflectiveOperationException var9) {
         }
      }

   }

   private static void setField(Object target, Class<?> declaringHierarchyRoot, String fieldName, Object value) throws NoSuchFieldException, IllegalAccessException {
      Field field = NmsBridge.findField(declaringHierarchyRoot, fieldName);
      field.set(target, value);
   }
}
