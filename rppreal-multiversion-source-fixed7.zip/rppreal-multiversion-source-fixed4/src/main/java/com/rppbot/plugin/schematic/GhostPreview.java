package com.rppbot.plugin.schematic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

public final class GhostPreview {
   public static final int MAX_DISPLAYS = 8000;
   private static final int SPAWN_PER_TICK = 250;
   private static final float SCALE = 0.99F;
   private static final String TAG = "rppbot_ghost";
   private final List<BlockDisplay> displays = new ArrayList();
   private final List<Integer> displayIndex = new ArrayList();
   private final List<Integer> retry = new ArrayList();
   private int[] plan = new int[0];
   private int cursor;
   private int builtVersion = -1;
   private int planned;
   private boolean truncated;
   private long ticks;

   public int plannedCount() {
      return this.planned;
   }

   public boolean truncated() {
      return this.truncated;
   }

   public void tick(LoadedSchematic s) {
      if (this.builtVersion != s.previewVersion) {
         this.rebuild(s);
      }

      World world = s.world();
      if (world != null) {
         ++this.ticks;
         if (this.ticks % 100L == 0L) {
            this.requeueLost();
         }

         int spawned = 0;

         while(this.cursor < this.plan.length && spawned < 250) {
            int idx = this.plan[this.cursor++];
            int x = s.worldX(idx);
            int y = s.worldY(idx);
            int z = s.worldZ(idx);
            if (!world.isChunkLoaded(x >> 4, z >> 4)) {
               this.retry.add(idx);
            } else {
               BlockData data = s.states[s.schematic.blocks[idx]];
               if (data != null) {
                  this.spawn(world, x, y, z, data, idx);
                  ++spawned;
               }
            }
         }

         if (this.cursor >= this.plan.length && !this.retry.isEmpty() && this.ticks % 40L == 0L) {
            this.plan = this.retry.stream().mapToInt(Integer::intValue).toArray();
            this.retry.clear();
            this.cursor = 0;
         }

      }
   }

   public void clear() {
      for(BlockDisplay d : this.displays) {
         if (d.isValid()) {
            d.remove();
         }
      }

      this.displays.clear();
      this.displayIndex.clear();
      this.retry.clear();
      this.plan = new int[0];
      this.cursor = 0;
      this.builtVersion = -1;
   }

   public void rebuild(LoadedSchematic s) {
      this.clear();
      this.builtVersion = s.previewVersion;
      Schematic sc = s.schematic;
      int w = sc.width;
      int h = sc.height;
      int l = sc.length;
      boolean[] drawable = new boolean[sc.palette.length];
      boolean[] occluding = new boolean[sc.palette.length];

      for(int i = 0; i < drawable.length; ++i) {
         drawable[i] = s.costs[i] != null && s.states[i] != null;
         occluding[i] = drawable[i] && s.states[i].getMaterial().isOccluding();
      }

      int[] tmp = new int[Math.min(sc.volume(), 8000)];
      int n = 0;
      int total = 0;

      for(int y = 0; y < h; ++y) {
         for(int z = 0; z < l; ++z) {
            for(int x = 0; x < w; ++x) {
               int idx = sc.index(x, y, z);
               if (drawable[sc.blocks[idx]]) {
                  boolean hidden = x > 0 && x < w - 1 && y > 0 && y < h - 1 && z > 0 && z < l - 1 && occluding[sc.blocks[sc.index(x - 1, y, z)]] && occluding[sc.blocks[sc.index(x + 1, y, z)]] && occluding[sc.blocks[sc.index(x, y - 1, z)]] && occluding[sc.blocks[sc.index(x, y + 1, z)]] && occluding[sc.blocks[sc.index(x, y, z - 1)]] && occluding[sc.blocks[sc.index(x, y, z + 1)]];
                  if (!hidden) {
                     ++total;
                     if (n < tmp.length) {
                        tmp[n++] = idx;
                     }
                  }
               }
            }
         }
      }

      this.plan = n == tmp.length ? tmp : Arrays.copyOf(tmp, n);
      this.planned = n;
      this.truncated = total > n;
      this.cursor = 0;
   }

   private void spawn(World world, int x, int y, int z, BlockData data, int idx) {
      float offset = 0.004999995F;
      Transformation transformation = new Transformation(new Vector3f(offset, offset, offset), new AxisAngle4f(0.0F, 0.0F, 0.0F, 1.0F), new Vector3f(0.99F, 0.99F, 0.99F), new AxisAngle4f(0.0F, 0.0F, 0.0F, 1.0F));
      BlockDisplay display = (BlockDisplay)world.spawn(new Location(world, (double)x, (double)y, (double)z), BlockDisplay.class, (d) -> {
         d.setBlock(data);
         d.setTransformation(transformation);
         d.setBrightness(new Display.Brightness(15, 15));
         d.setPersistent(false);
         d.setInvulnerable(true);
         d.addScoreboardTag("rppbot_ghost");
      });
      this.displays.add(display);
      this.displayIndex.add(idx);
   }

   private void requeueLost() {
      for(int i = this.displays.size() - 1; i >= 0; --i) {
         if (!((BlockDisplay)this.displays.get(i)).isValid()) {
            this.retry.add((Integer)this.displayIndex.get(i));
            this.displays.remove(i);
            this.displayIndex.remove(i);
         }
      }

   }
}
