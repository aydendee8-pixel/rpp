package com.rppbot.plugin.schematic;

public final class Schematic {
   public final String name;
   public final String format;
   public final int width;
   public final int height;
   public final int length;
   public final String[] palette;
   public final int[] blocks;

   public Schematic(String name, String format, int width, int height, int length, String[] palette, int[] blocks) {
      this.name = name;
      this.format = format;
      this.width = width;
      this.height = height;
      this.length = length;
      this.palette = palette;
      this.blocks = blocks;
   }

   public int volume() {
      return this.blocks.length;
   }

   public int index(int x, int y, int z) {
      return (y * this.length + z) * this.width + x;
   }

   public int countSolid() {
      boolean[] air = new boolean[this.palette.length];

      for(int i = 0; i < this.palette.length; ++i) {
         air[i] = isAirState(this.palette[i]);
      }

      int count = 0;

      for(int b : this.blocks) {
         if (!air[b]) {
            ++count;
         }
      }

      return count;
   }

   public static boolean isAirState(String state) {
      return state.equals("minecraft:air") || state.startsWith("minecraft:air[") || state.equals("minecraft:cave_air") || state.equals("minecraft:void_air");
   }
}
