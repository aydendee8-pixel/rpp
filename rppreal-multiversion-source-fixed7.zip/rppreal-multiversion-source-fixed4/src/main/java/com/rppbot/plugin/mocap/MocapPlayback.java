package com.rppbot.plugin.mocap;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Pose;
import org.bukkit.inventory.EquipmentSlot;

public final class MocapPlayback {
   public final MocapRecording recording;
   public int index = 0;
   public int changeCursor = 0;
   public int actionCursor = 0;
   public final List<Entity> spawnedProjectiles = new ArrayList();
   public final List<Location> openLids = new ArrayList();
   public boolean waitingToReset = false;
   public long nextWatchScanTick = Long.MIN_VALUE;
   public boolean watchedLastScan = false;
   public boolean sneaking = false;
   public boolean sprinting = false;
   public Pose pose;
   public EquipmentSlot usingHand;
   public boolean gliding;
   public boolean riptiding;

   public MocapPlayback(MocapRecording recording) {
      this.pose = Pose.STANDING;
      this.usingHand = null;
      this.gliding = false;
      this.riptiding = false;
      this.recording = recording;
   }
}
