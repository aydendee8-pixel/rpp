package com.rppbot.plugin.fakejoin;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.RecordComponent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.Plugin;

public final class TabListPresence implements Listener {
   private final Plugin plugin;
   private final Map<UUID, Object> entriesById = new ConcurrentHashMap();

   public TabListPresence(Plugin plugin) {
      this.plugin = plugin;
      Bukkit.getPluginManager().registerEvents(this, plugin);
   }

   public void add(UUID id, String name) {
      try {
         Object entry = buildEntry(id, name);
         this.entriesById.put(id, entry);
         Object packet = buildAddPacket(List.of(entry));

         for(Player p : Bukkit.getOnlinePlayers()) {
            send(p, packet);
         }
      } catch (Exception e) {
         NmsBridge.warn("Adding '" + name + "' to the tab list failed", e);
      }

   }

   public void remove(UUID id) {
      Object removed = this.entriesById.remove(id);
      if (removed != null) {
         try {
            Object packet = buildRemovePacket(List.of(id));

            for(Player p : Bukkit.getOnlinePlayers()) {
               send(p, packet);
            }
         } catch (Exception e) {
            NmsBridge.warn("Removing a bot from the tab list failed", e);
         }

      }
   }

   public void removeAll() {
      for(UUID id : (UUID[])this.entriesById.keySet().toArray(new UUID[0])) {
         this.remove(id);
      }

   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onJoin(PlayerJoinEvent event) {
      if (!this.entriesById.isEmpty()) {
         try {
            Object packet = buildAddPacket(new ArrayList(this.entriesById.values()));
            send(event.getPlayer(), packet);
         } catch (Exception e) {
            NmsBridge.warn("Sending existing bots' tab entries to " + event.getPlayer().getName() + " failed", e);
         }

      }
   }

   private static Object buildEntry(UUID id, String name) throws Exception {
      Object gameProfile = FakeProfileFactory.buildBareGameProfile(name, id);
      Class<?> entryClass = Class.forName("net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket$Entry");
      Class<?> gameTypeClass = Class.forName("net.minecraft.world.level.GameType");
      Object survival = gameTypeClass.getField("SURVIVAL").get((Object)null);
      RecordComponent[] components = entryClass.getRecordComponents();
      Class<?>[] paramTypes = new Class[components.length];
      Object[] args = new Object[components.length];

      for(int i = 0; i < components.length; ++i) {
         String name0 = components[i].getName();
         paramTypes[i] = components[i].getType();
         switch (name0) {
            case "profileId":
               args[i] = id;
               break;
            case "profile":
               args[i] = gameProfile;
               break;
            case "listed":
               args[i] = Boolean.TRUE;
               break;
            case "showHat":
               args[i] = Boolean.TRUE;
               break;
            case "latency":
               args[i] = 0;
               break;
            case "listOrder":
               args[i] = 0;
               break;
            case "gameMode":
               args[i] = survival;
               break;
            default:
               args[i] = null;
         }
      }

      Constructor<?> ctor = entryClass.getDeclaredConstructor(paramTypes);
      ctor.setAccessible(true);
      return ctor.newInstance(args);
   }

   private static Object buildAddPacket(List<Object> entries) throws Exception {
      Class<?> packetClass = Class.forName("net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket");
      Class<?> actionClass = Class.forName("net.minecraft.network.protocol.game.ClientboundPlayerInfoUpdatePacket$Action");
      Object actions = wantedActions(actionClass, "ADD_PLAYER", "UPDATE_LISTED", "UPDATE_LATENCY", "UPDATE_GAME_MODE");

      for(Constructor<?> ctor : packetClass.getDeclaredConstructors()) {
         Class<?>[] p = ctor.getParameterTypes();
         if (p.length == 2 && p[0].isAssignableFrom(actions.getClass()) && p[1].isAssignableFrom(entries.getClass())) {
            ctor.setAccessible(true);
            return ctor.newInstance(actions, entries);
         }
      }

      throw new NoSuchMethodException(packetClass.getName() + " has no (EnumSet, List) constructor");
   }

   private static Object buildRemovePacket(List<UUID> ids) throws Exception {
      Class<?> packetClass = Class.forName("net.minecraft.network.protocol.game.ClientboundPlayerInfoRemovePacket");
      Constructor<?> ctor = packetClass.getDeclaredConstructor(List.class);
      ctor.setAccessible(true);
      return ctor.newInstance(ids);
   }

   private static Object wantedActions(Class<?> actionClass, String... names) throws Exception {
      Method noneOf = EnumSet.class.getMethod("noneOf", Class.class);
      Object set = noneOf.invoke((Object)null, actionClass);
      Method add = Collection.class.getMethod("add", Object.class);

      for(Object constant : actionClass.getEnumConstants()) {
         String constantName = ((Enum)constant).name();

         for(String wanted : names) {
            if (constantName.equals(wanted)) {
               add.invoke(set, constant);
            }
         }
      }

      return set;
   }

   private static void send(Player player, Object packet) throws Exception {
      Object serverPlayer = NmsBridge.serverPlayerHandle(player);
      Object connection = connectionOf(serverPlayer);
      Method sendMethod = sendMethodOf(connection.getClass());
      sendMethod.invoke(connection, packet);
   }

   private static Object connectionOf(Object serverPlayer) throws Exception {
      for(String fieldName : new String[]{"connection", "networkManager", "c"}) {
         try {
            Field f = NmsBridge.findField(serverPlayer.getClass(), fieldName);
            Object value = f.get(serverPlayer);
            if (value != null) {
               return value;
            }
         } catch (NoSuchFieldException var7) {
         }
      }

      throw new NoSuchFieldException(serverPlayer.getClass().getName() + " has no recognizable connection field");
   }

   private static Method sendMethodOf(Class<?> connectionClass) throws NoSuchMethodException {
      for(Method m : connectionClass.getMethods()) {
         if ((m.getName().equals("send") || m.getName().equals("sendPacket")) && m.getParameterCount() == 1) {
            return m;
         }
      }

      throw new NoSuchMethodException(connectionClass.getName() + " has no send(Packet) method");
   }
}
