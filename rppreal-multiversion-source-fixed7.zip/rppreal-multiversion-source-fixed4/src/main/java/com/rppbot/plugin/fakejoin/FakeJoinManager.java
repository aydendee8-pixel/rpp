package com.rppbot.plugin.fakejoin;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.InetAddress;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.Consumer;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

public final class FakeJoinManager {
   private final Plugin plugin;
   private final Map<UUID, ActiveJoin> activeByMannequinId = new ConcurrentHashMap();

   public FakeJoinManager(Plugin plugin) {
      this.plugin = plugin;
   }

   public void join(UUID mannequinId, World world, String skinName, Consumer<Boolean> onResult) {
      String fakeName = this.uniqueFakeName(skinName);
      UUID fakeId = NmsBridge.offlineUuidFor(fakeName);
      Bukkit.getAsyncScheduler().runNow(this.plugin, (asyncTask) -> {
         Object gameProfile;
         try {
            gameProfile = FakeProfileFactory.resolve(fakeName, fakeId, skinName);
         } catch (Exception e) {
            NmsBridge.warn("Building fake profile for '" + fakeName + "' failed", e);
            this.runOnMain(() -> onResult.accept(false));
            return;
         }

         this.runOnMain(() -> {
            boolean ok = this.joinOnMainThread(mannequinId, world, fakeName, fakeId, gameProfile);
            onResult.accept(ok);
         });
      });
   }

   public void leave(UUID mannequinId) {
      ActiveJoin join = (ActiveJoin)this.activeByMannequinId.remove(mannequinId);
      if (join != null) {
         try {
            Object playerList = NmsBridge.playerList();
            Method remove = this.firstWorkingRemoveMethod(playerList.getClass(), join.serverPlayerHandle());
            remove.invoke(playerList, join.serverPlayerHandle());
         } catch (Exception e) {
            NmsBridge.warn("Removing fake join '" + join.fakeName() + "' from PlayerList failed", e);
         }
      }

   }

   public void leaveAll() {
      for(UUID id : (UUID[])this.activeByMannequinId.keySet().toArray(new UUID[0])) {
         this.leave(id);
      }

   }

   public boolean isJoined(UUID mannequinId) {
      return this.activeByMannequinId.containsKey(mannequinId);
   }

   private boolean joinOnMainThread(UUID mannequinId, World world, String fakeName, UUID fakeId, Object gameProfile) {
      try {
         Object connection = FakeConnectionFactory.create(this.loopbackAddress());
         Object serverPlayer = this.buildServerPlayer(world, gameProfile);
         this.placeNewPlayer(connection, serverPlayer);
         this.activeByMannequinId.put(mannequinId, new ActiveJoin(serverPlayer, fakeId, fakeName));
         return true;
      } catch (Exception e) {
         NmsBridge.warn("Fake network join for '" + fakeName + "' failed - continuing with mannequin only", e);
         return false;
      }
   }

   private Object buildServerPlayer(World world, Object gameProfile) throws Exception {
      Object minecraftServer = NmsBridge.minecraftServer();
      Object serverLevel = NmsBridge.serverLevel(world);
      Class<?> serverPlayerClass = Class.forName("net.minecraft.server.level.ServerPlayer");
      Class<?> minecraftServerClass = Class.forName("net.minecraft.server.MinecraftServer");

      try {
         Class<?> clientInfoClass = Class.forName("net.minecraft.server.level.ClientInformation");
         Object defaultClientInfo = this.defaultClientInformation(clientInfoClass);
         Constructor<?> ctor = serverPlayerClass.getDeclaredConstructor(minecraftServerClass, serverLevel.getClass(), Class.forName("com.mojang.authlib.GameProfile"), clientInfoClass);
         ctor.setAccessible(true);
         return ctor.newInstance(minecraftServer, serverLevel, gameProfile, defaultClientInfo);
      } catch (ReflectiveOperationException var10) {
         Constructor<?> ctor = NmsBridge.findConstructorByArity(serverPlayerClass, 3);
         return ctor.newInstance(minecraftServer, serverLevel, gameProfile);
      }
   }

   private Object defaultClientInformation(Class<?> clientInfoClass) throws ReflectiveOperationException {
      for(String methodName : new String[]{"createDefault"}) {
         try {
            Method m = clientInfoClass.getDeclaredMethod(methodName);
            m.setAccessible(true);
            return m.invoke((Object)null);
         } catch (NoSuchMethodException var7) {
         }
      }

      throw new NoSuchMethodException(clientInfoClass.getName() + "#createDefault()");
   }

   private void placeNewPlayer(Object connection, Object serverPlayer) throws Exception {
      Object playerList = NmsBridge.playerList();

      try {
         Class<?> cookieClass = Class.forName("net.minecraft.server.network.CommonListenerCookie");
         Object cookie = this.buildCookie(cookieClass, serverPlayer);
         Method m = NmsBridge.findMethod(playerList.getClass(), "placeNewPlayer", connection.getClass(), serverPlayer.getClass(), cookieClass);
         m.invoke(playerList, connection, serverPlayer, cookie);
      } catch (Exception var7) {
         Method m = NmsBridge.findMethod(playerList.getClass(), "placeNewPlayer", connection.getClass(), serverPlayer.getClass());
         m.invoke(playerList, connection, serverPlayer);
      }

   }

   private Object buildCookie(Class<?> cookieClass, Object serverPlayer) throws Exception {
      Class<?> gameProfileClass = Class.forName("com.mojang.authlib.GameProfile");
      Method getGameProfile = NmsBridge.findMethod(serverPlayer.getClass(), "getGameProfile");
      Object profile = getGameProfile.invoke(serverPlayer);

      for(Method m : cookieClass.getDeclaredMethods()) {
         if (Modifier.isStatic(m.getModifiers())) {
            Class<?>[] params = m.getParameterTypes();
            Object[] args = new Object[params.length];

            for(int i = 0; i < params.length; ++i) {
               if (params[i].isAssignableFrom(gameProfileClass)) {
                  args[i] = profile;
               } else if (params[i] == Boolean.TYPE) {
                  args[i] = false;
               } else if (params[i] == Integer.TYPE) {
                  args[i] = 0;
               } else {
                  args[i] = null;
               }
            }

            m.setAccessible(true);

            try {
               return m.invoke((Object)null, args);
            } catch (Exception var13) {
            }
         }
      }

      throw new NoSuchMethodException("Could not build " + cookieClass.getName() + " via any static factory method");
   }

   private void runOnMain(Runnable task) {
      Bukkit.getGlobalRegionScheduler().run(this.plugin, (t) -> task.run());
   }

   private Method firstWorkingRemoveMethod(Class<?> playerListClass, Object serverPlayer) throws NoSuchMethodException {
      for(String name : new String[]{"remove", "disconnect"}) {
         try {
            return NmsBridge.findMethod(playerListClass, name, serverPlayer.getClass());
         } catch (NoSuchMethodException var8) {
         }
      }

      throw new NoSuchMethodException(playerListClass.getName() + " has neither remove(ServerPlayer) nor disconnect(ServerPlayer)");
   }

   private InetAddress loopbackAddress() {
      return InetAddress.getLoopbackAddress();
   }

   private String uniqueFakeName(String seed) {
      String base = seed.replaceAll("[^A-Za-z0-9_]", "");
      if (base.isEmpty()) {
         base = "RppBot";
      }

      if (base.length() > 12) {
         base = base.substring(0, 12);
      }

      for(int attempt = 0; attempt < 50; ++attempt) {
         String candidate = base + ThreadLocalRandom.current().nextInt(1000, 9999);
         if (candidate.length() > 16) {
            candidate = candidate.substring(0, 16);
         }

         if (this.isNameFree(candidate)) {
            return candidate;
         }
      }

      return base + System.nanoTime() % 10000L;
   }

   private boolean isNameFree(String candidate) {
      for(ActiveJoin join : this.activeByMannequinId.values()) {
         if (join.fakeName().equalsIgnoreCase(candidate)) {
            return false;
         }
      }

      for(Player p : Bukkit.getOnlinePlayers()) {
         if (p.getName().equalsIgnoreCase(candidate)) {
            return false;
         }
      }

      return true;
   }

   private static record ActiveJoin(Object serverPlayerHandle, UUID fakeProfileId, String fakeName) {
   }
}
