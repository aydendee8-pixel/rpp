package com.rppbot.plugin.mocap;

import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.util.Vector;

public sealed interface MocapAction {
   int frame();

   MocapAction withFrame(int var1);

   public static record Projectile(int frame, EntityType type, Location at, Vector velocity, ItemStack item, FireworkMeta fireworkMeta, boolean attachedToShooter, boolean critical, boolean fromCrossbow, int pierceLevel) implements MocapAction {
      public MocapAction withFrame(int newFrame) {
         return new Projectile(newFrame, this.type, this.at, this.velocity, this.item, this.fireworkMeta, this.attachedToShooter, this.critical, this.fromCrossbow, this.pierceLevel);
      }
   }

   public static record ContainerOpen(int frame, Location location) implements MocapAction {
      public MocapAction withFrame(int newFrame) {
         return new ContainerOpen(newFrame, this.location);
      }
   }

   public static record ContainerClose(int frame, Location location) implements MocapAction {
      public MocapAction withFrame(int newFrame) {
         return new ContainerClose(newFrame, this.location);
      }
   }
}
