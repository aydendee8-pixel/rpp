package com.rppbot.plugin.motion;

/**
 * A virtual keyboard for one bot. Every kind of bot movement (path walking,
 * formations, patrol, roam, combat strafing, build walking, mid-air steering)
 * is expressed as a set of held keys, exactly like a real player's input.
 */
public final class WasdKeys {
   public boolean w;
   public boolean a;
   public boolean s;
   public boolean d;
   public boolean jump;
   public boolean sprint;
   public boolean sneak;

   public void clearMovement() {
      this.w = false;
      this.a = false;
      this.s = false;
      this.d = false;
      this.jump = false;
      this.sprint = false;
   }

   public boolean anyMovement() {
      return this.w || this.a || this.s || this.d;
   }

   /** +1 forward (W), -1 backward (S). */
   public int forwardAxis() {
      return (this.w ? 1 : 0) - (this.s ? 1 : 0);
   }

   /** +1 right (D), -1 left (A). */
   public int strafeAxis() {
      return (this.d ? 1 : 0) - (this.a ? 1 : 0);
   }

   /** Sets the keys from two axes: forward +1 = W / -1 = S, strafe +1 = D / -1 = A. */
   public void setAxes(int forward, int strafe) {
      this.w = forward > 0;
      this.s = forward < 0;
      this.d = strafe > 0;
      this.a = strafe < 0;
   }

   /** Sector 0..7 clockwise from straight ahead (W, W+D, D, S+D, S, S+A, A, W+A); -1 when no keys held. */
   public int sector() {
      int f = this.forwardAxis();
      int r = this.strafeAxis();
      if (f == 0 && r == 0) {
         return -1;
      } else if (f > 0) {
         return r > 0 ? 1 : (r < 0 ? 7 : 0);
      } else if (f < 0) {
         return r > 0 ? 3 : (r < 0 ? 5 : 4);
      } else {
         return r > 0 ? 2 : 6;
      }
   }

   public void setSector(int sector) {
      this.w = false;
      this.a = false;
      this.s = false;
      this.d = false;
      switch (sector) {
         case 0 -> this.w = true;
         case 1 -> {
            this.w = true;
            this.d = true;
         }
         case 2 -> this.d = true;
         case 3 -> {
            this.s = true;
            this.d = true;
         }
         case 4 -> this.s = true;
         case 5 -> {
            this.s = true;
            this.a = true;
         }
         case 6 -> this.a = true;
         case 7 -> {
            this.w = true;
            this.a = true;
         }
         default -> {
         }
      }
   }

   @Override
   public String toString() {
      StringBuilder sb = new StringBuilder();
      if (this.w) sb.append('W');
      if (this.a) sb.append('A');
      if (this.s) sb.append('S');
      if (this.d) sb.append('D');
      if (this.jump) sb.append("+JUMP");
      if (this.sprint) sb.append("+SPRINT");
      if (this.sneak) sb.append("+SNEAK");
      return sb.length() == 0 ? "-" : sb.toString();
   }
}
