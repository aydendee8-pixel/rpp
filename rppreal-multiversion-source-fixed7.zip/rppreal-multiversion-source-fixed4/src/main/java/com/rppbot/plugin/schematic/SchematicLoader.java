package com.rppbot.plugin.schematic;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class SchematicLoader {
   public static final long MAX_VOLUME = 32000000L;

   private SchematicLoader() {
   }

   public static Schematic load(File file, String name) throws IOException {
      String lower = file.getName().toLowerCase();
      Map<String, Object> root = Nbt.readFile(file);
      if (lower.endsWith(".litematic")) {
         return loadLitematic(root, name);
      } else if (lower.endsWith(".schem")) {
         return loadSponge(root, name);
      } else {
         throw new IOException("Unsupported file type (use .schem or .litematic).");
      }
   }

   private static Schematic loadSponge(Map<String, Object> root, String name) throws IOException {
      Map<String, Object> s = Nbt.compound(root, "Schematic");
      if (s == null) {
         s = root;
      }

      int width = Nbt.intValue(s, "Width", -1) & '\uffff';
      int height = Nbt.intValue(s, "Height", -1) & '\uffff';
      int length = Nbt.intValue(s, "Length", -1) & '\uffff';
      if (width > 0 && height > 0 && length > 0) {
         checkVolume((long)width * (long)height * (long)length);
         Map<String, Object> blocksTag = Nbt.compound(s, "Blocks");
         Map<String, Object> paletteTag;
         Object dataObj;
         if (blocksTag != null) {
            paletteTag = Nbt.compound(blocksTag, "Palette");
            dataObj = blocksTag.get("Data");
         } else {
            paletteTag = Nbt.compound(s, "Palette");
            dataObj = s.get("BlockData");
         }

         if (paletteTag != null && dataObj instanceof byte[]) {
            byte[] data = (byte[])dataObj;
            int maxId = 0;

            for(Object v : paletteTag.values()) {
               if (v instanceof Number) {
                  Number n = (Number)v;
                  maxId = Math.max(maxId, n.intValue());
               }
            }

            String[] palette = new String[maxId + 1];

            for(Map.Entry<String, Object> e : paletteTag.entrySet()) {
               Object var15 = e.getValue();
               if (var15 instanceof Number) {
                  Number n = (Number)var15;
                  palette[n.intValue()] = (String)e.getKey();
               }
            }

            for(int i = 0; i < palette.length; ++i) {
               if (palette[i] == null) {
                  palette[i] = "minecraft:air";
               }
            }

            int volume = width * height * length;
            int[] blocks = new int[volume];
            int pos = 0;
            int i = 0;

            label69:
            while(i < volume) {
               int value = 0;
               int shift = 0;

               while(pos < data.length) {
                  int b = data[pos++];
                  value |= (b & 127) << shift;
                  if ((b & 128) == 0) {
                     if (value < 0 || value >= palette.length) {
                        throw new IOException("Block data references palette entry " + value + " that doesn't exist.");
                     }

                     blocks[i] = value;
                     ++i;
                     continue label69;
                  }

                  shift += 7;
                  if (shift > 35) {
                     throw new IOException("Bad varint in block data.");
                  }
               }

               throw new IOException("Block data ended early (corrupt schematic?).");
            }

            return normalize(new Schematic(name, "Sponge .schem", width, height, length, palette, blocks));
         } else {
            throw new IOException("Schematic is missing its block palette/data.");
         }
      } else {
         throw new IOException("Schematic has no Width/Height/Length - is this a Sponge .schem file?");
      }
   }

   private static Schematic loadLitematic(Map<String, Object> root, String name) throws IOException {
      Map<String, Object> regions = Nbt.compound(root, "Regions");
      if (regions != null && !regions.isEmpty()) {
         List<LitRegion> parsed = new ArrayList();
         int minX = Integer.MAX_VALUE;
         int minY = Integer.MAX_VALUE;
         int minZ = Integer.MAX_VALUE;
         int maxX = Integer.MIN_VALUE;
         int maxY = Integer.MIN_VALUE;
         int maxZ = Integer.MIN_VALUE;

         for(Object regionObj : regions.values()) {
            if (regionObj instanceof Map) {
               Map<String, Object> region = (Map)regionObj;
               Map<String, Object> pos = Nbt.compound(region, "Position");
               Map<String, Object> size = Nbt.compound(region, "Size");
               List<Object> paletteList = Nbt.list(region, "BlockStatePalette");
               Object statesObj = region.get("BlockStates");
               if (pos != null && size != null && paletteList != null && statesObj instanceof long[]) {
                  long[] states = (long[])statesObj;
                  int px = Nbt.intValue(pos, "x", 0);
                  int py = Nbt.intValue(pos, "y", 0);
                  int pz = Nbt.intValue(pos, "z", 0);
                  int sx = Nbt.intValue(size, "x", 0);
                  int sy = Nbt.intValue(size, "y", 0);
                  int sz = Nbt.intValue(size, "z", 0);
                  if (sx != 0 && sy != 0 && sz != 0) {
                     int rx = sx < 0 ? px + sx + 1 : px;
                     int ry = sy < 0 ? py + sy + 1 : py;
                     int rz = sz < 0 ? pz + sz + 1 : pz;
                     int ax = Math.abs(sx);
                     int ay = Math.abs(sy);
                     int az = Math.abs(sz);
                     checkVolume((long)ax * (long)ay * (long)az);
                     String[] regionPalette = new String[paletteList.size()];

                     for(int i = 0; i < regionPalette.length; ++i) {
                        regionPalette[i] = litematicState(paletteList.get(i));
                     }

                     parsed.add(new LitRegion(rx, ry, rz, ax, ay, az, regionPalette, states));
                     minX = Math.min(minX, rx);
                     minY = Math.min(minY, ry);
                     minZ = Math.min(minZ, rz);
                     maxX = Math.max(maxX, rx + ax - 1);
                     maxY = Math.max(maxY, ry + ay - 1);
                     maxZ = Math.max(maxZ, rz + az - 1);
                  }
               }
            }
         }

         if (parsed.isEmpty()) {
            throw new IOException("Litematic regions are empty or unreadable.");
         } else {
            long width = (long)maxX - (long)minX + 1L;
            long height = (long)maxY - (long)minY + 1L;
            long length = (long)maxZ - (long)minZ + 1L;
            checkVolume(width * height * length);
            int w = (int)width;
            int h = (int)height;
            int l = (int)length;
            Map<String, Integer> mergedIndex = new HashMap();
            List<String> mergedPalette = new ArrayList();
            mergedIndex.put("minecraft:air", 0);
            mergedPalette.add("minecraft:air");
            int[] blocks = new int[w * h * l];

            for(LitRegion r : parsed) {
               int[] remap = new int[r.palette.length];

               for(int i = 0; i < r.palette.length; ++i) {
                  Integer existing = (Integer)mergedIndex.get(r.palette[i]);
                  if (existing == null) {
                     existing = mergedPalette.size();
                     mergedIndex.put(r.palette[i], existing);
                     mergedPalette.add(r.palette[i]);
                  }

                  remap[i] = existing;
               }

               int bits = Math.max(2, 32 - Integer.numberOfLeadingZeros(r.palette.length - 1));
               long mask = (1L << bits) - 1L;
               long total = (long)r.ax * (long)r.ay * (long)r.az;
               if ((total * (long)bits + 63L) / 64L > (long)r.states.length) {
                  throw new IOException("Litematic block data is shorter than its region size (corrupt file?).");
               }

               for(int i = 0; (long)i < total; ++i) {
                  long bitStart = (long)i * (long)bits;
                  int startIdx = (int)(bitStart >>> 6);
                  int endIdx = (int)((long)(i + 1) * (long)bits - 1L >>> 6);
                  int startOffset = (int)(bitStart & 63L);
                  long value;
                  if (startIdx == endIdx) {
                     value = r.states[startIdx] >>> startOffset & mask;
                  } else {
                     int endOffset = 64 - startOffset;
                     value = (r.states[startIdx] >>> startOffset | r.states[endIdx] << endOffset) & mask;
                  }

                  if (value < (long)remap.length) {
                     int x = i % r.ax;
                     int z = i / r.ax % r.az;
                     int y = i / (r.ax * r.az);
                     int gx = r.x + x - minX;
                     int gy = r.y + y - minY;
                     int gz = r.z + z - minZ;
                     int target = (gy * l + gz) * w + gx;
                     int state = remap[(int)value];
                     if (state != 0 || blocks[target] == 0) {
                        blocks[target] = state;
                     }
                  }
               }
            }

            return normalize(new Schematic(name, "Litematica .litematic", w, h, l, (String[])mergedPalette.toArray(new String[0]), blocks));
         }
      } else {
         throw new IOException("Litematic has no regions.");
      }
   }

   private static String litematicState(Object entry) {
      if (entry instanceof Map<?, ?> m) {
         Object nameObj = m.get("Name");
         String var10000;
         if (nameObj instanceof String s) {
            var10000 = s;
         } else {
            var10000 = "minecraft:air";
         }

         String blockName = var10000;
         Object propsObj = m.get("Properties");
         if (propsObj instanceof Map<?, ?> props) {
            if (!props.isEmpty()) {
               StringBuilder sb = (new StringBuilder(blockName)).append('[');
               boolean first = true;

               for(Map.Entry<?, ?> p : props.entrySet()) {
                  if (!first) {
                     sb.append(',');
                  }

                  first = false;
                  sb.append(p.getKey()).append('=').append(p.getValue());
               }

               return sb.append(']').toString();
            }
         }

         return blockName;
      } else {
         return "minecraft:air";
      }
   }

   private static void checkVolume(long volume) throws IOException {
      if (volume <= 0L || volume > 32000000L) {
         throw new IOException("Schematic is too large (" + volume + " blocks, limit is 32000000).");
      }
   }

   private static Schematic normalize(Schematic in) {
      int airIdx = -1;

      for(int i = 0; i < in.palette.length; ++i) {
         if (in.palette[i].equals("minecraft:air")) {
            airIdx = i;
            break;
         }
      }

      String[] palette = in.palette;
      int[] blocks = in.blocks;
      if (airIdx == 0) {
         return in;
      } else if (airIdx != -1) {
         String[] swapped = palette.clone();
         swapped[0] = palette[airIdx];
         swapped[airIdx] = palette[0];

         for(int i = 0; i < blocks.length; ++i) {
            if (blocks[i] == 0) {
               blocks[i] = airIdx;
            } else if (blocks[i] == airIdx) {
               blocks[i] = 0;
            }
         }

         return new Schematic(in.name, in.format, in.width, in.height, in.length, swapped, blocks);
      } else {
         String[] shifted = new String[palette.length + 1];
         shifted[0] = "minecraft:air";
         System.arraycopy(palette, 0, shifted, 1, palette.length);

         for(int i = 0; i < blocks.length; ++i) {
            int var10002 = blocks[i]++;
         }

         return new Schematic(in.name, in.format, in.width, in.height, in.length, shifted, blocks);
      }
   }

   private static record LitRegion(int x, int y, int z, int ax, int ay, int az, String[] palette, long[] states) {
   }
}
