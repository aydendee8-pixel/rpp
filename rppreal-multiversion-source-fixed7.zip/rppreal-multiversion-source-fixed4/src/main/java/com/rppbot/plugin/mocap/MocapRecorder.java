package com.rppbot.plugin.mocap;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.DoubleChest;
import org.bukkit.block.Lidded;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.entity.Pose;
import org.bukkit.entity.Projectile;
import org.bukkit.entity.ThrowableProjectile;
import org.bukkit.entity.ThrownPotion;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.BlockInventoryHolder;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.FireworkMeta;

public final class MocapRecorder {
   public static final int MAX_FRAMES = 12000;
   private final Player player;
   private final UUID worldId;
   private final List<MocapFrame> frames = new ArrayList();
   private final List<MocapBlockChange> changes = new ArrayList();
   private final List<MocapAction> actions = new ArrayList();
   private final List<Entity> liveProjectiles = new ArrayList();
   private Location openContainer;
   private Location lastClickedBlock;
   private ItemStack[] lastEquipment;
   private boolean pendingSwingMain;
   private boolean pendingSwingOff;
   private static final Set<EntityType> REPLAYABLE_PROJECTILES;

   public MocapRecorder(Player player) {
      this.player = player;
      this.worldId = player.getWorld().getUID();
   }

   public Player player() {
      return this.player;
   }

   public int frameCount() {
      return this.frames.size();
   }

   public boolean isFull() {
      return this.frames.size() >= 12000;
   }

   public boolean stillInWorld() {
      return this.player.isOnline() && this.player.getWorld().getUID().equals(this.worldId);
   }

   public void noteSwing(boolean offHand) {
      if (offHand) {
         this.pendingSwingOff = true;
      } else {
         this.pendingSwingMain = true;
      }

   }

   public void sample() {
      Location loc = this.player.getLocation();
      ItemStack[] equipment = this.snapshotEquipmentIfChanged();
      this.frames.add(new MocapFrame(loc.getX(), loc.getY(), loc.getZ(), loc.getYaw(), loc.getPitch(), this.player.isSneaking(), this.player.isSprinting(), this.player.getPose(), this.pendingSwingMain, this.pendingSwingOff, equipment, this.activeHand(), this.player.isGliding(), this.player.isRiptiding()));
      this.pendingSwingMain = false;
      this.pendingSwingOff = false;
   }

   private EquipmentSlot activeHand() {
      if (!this.player.isHandRaised()) {
         return null;
      } else {
         EquipmentSlot hand = this.player.getActiveItemHand();
         return hand == EquipmentSlot.OFF_HAND ? EquipmentSlot.OFF_HAND : EquipmentSlot.HAND;
      }
   }

   public static boolean isReplayableProjectile(EntityType type) {
      return REPLAYABLE_PROJECTILES.contains(type);
   }

   public void recordProjectile(Projectile projectile) {
      EntityType type = projectile.getType();
      if (isReplayableProjectile(type)) {
         ItemStack item = null;
         FireworkMeta fireworkMeta = null;
         boolean attached = false;
         boolean critical = false;
         boolean crossbow = false;
         int pierce = 0;
         if (projectile instanceof AbstractArrow) {
            AbstractArrow arrow = (AbstractArrow)projectile;
            item = arrow.getItemStack().clone();
            critical = arrow.isCritical();
            crossbow = arrow.isShotFromCrossbow();
            pierce = arrow.getPierceLevel();
         } else if (projectile instanceof ThrownPotion) {
            ThrownPotion potion = (ThrownPotion)projectile;
            item = potion.getItem().clone();
         } else if (projectile instanceof ThrowableProjectile) {
            ThrowableProjectile thrown = (ThrowableProjectile)projectile;
            item = thrown.getItem().clone();
         } else if (projectile instanceof Firework) {
            Firework firework = (Firework)projectile;
            fireworkMeta = firework.getFireworkMeta();
            attached = firework.getAttachedTo() != null;
         }

         this.actions.add(new MocapAction.Projectile(this.frames.size(), type, projectile.getLocation().clone(), projectile.getVelocity().clone(), item, fireworkMeta, attached, critical, crossbow, pierce));
         this.liveProjectiles.add(projectile);
      }
   }

   public void noteClickedBlock(Block block) {
      this.lastClickedBlock = block == null ? null : block.getLocation();
   }

   public void recordContainerOpen(Inventory inventory) {
      if (this.openContainer == null) {
         Location where = null;
         InventoryHolder holder = inventory.getHolder(false);
         if (holder instanceof DoubleChest) {
            DoubleChest chest = (DoubleChest)holder;
            holder = chest.getLeftSide(false);
         }

         if (holder instanceof BlockState) {
            BlockState state = (BlockState)holder;
            where = state.getLocation();
         } else if (holder instanceof BlockInventoryHolder) {
            BlockInventoryHolder blockHolder = (BlockInventoryHolder)holder;
            where = blockHolder.getBlock().getLocation();
         } else if (inventory.getType() == InventoryType.ENDER_CHEST && this.lastClickedBlock != null && this.lastClickedBlock.getBlock().getType() == Material.ENDER_CHEST) {
            where = this.lastClickedBlock;
         }

         if (where != null) {
            this.openContainer = where;
            this.actions.add(new MocapAction.ContainerOpen(this.frames.size(), where));
         }
      }
   }

   public void recordContainerClose() {
      if (this.openContainer != null) {
         this.actions.add(new MocapAction.ContainerClose(this.frames.size(), this.openContainer));
         this.openContainer = null;
      }
   }

   public void recordChange(int frame, BlockState before, BlockData after, Material item) {
      this.changes.add(new MocapBlockChange(frame, before, after, item));
   }

   public boolean hasChangeAt(Location location, int fromFrame) {
      for(int i = this.changes.size() - 1; i >= 0; --i) {
         MocapBlockChange change = (MocapBlockChange)this.changes.get(i);
         if (change.frame() < fromFrame) {
            break;
         }

         Location at = change.before().getLocation();
         if (at.getWorld() == location.getWorld() && at.getBlockX() == location.getBlockX() && at.getBlockY() == location.getBlockY() && at.getBlockZ() == location.getBlockZ()) {
            return true;
         }
      }

      return false;
   }

   public int changeCount() {
      return this.changes.size();
   }

   public void revertAll() {
      for(Entity projectile : this.liveProjectiles) {
         if (projectile.isValid()) {
            projectile.remove();
         }
      }

      this.liveProjectiles.clear();
      this.recordContainerClose();

      for(MocapAction action : this.actions) {
         if (action instanceof MocapAction.ContainerOpen open) {
            setLid(open.location(), false);
         }
      }

      for(int i = this.changes.size() - 1; i >= 0; --i) {
         try {
            ((MocapBlockChange)this.changes.get(i)).revert();
         } catch (Exception e) {
            Bukkit.getLogger().warning("[RppCommand] Couldn't revert a mocap block change: " + String.valueOf(e));
         }
      }

   }

   public MocapRecording finish() {
      int last = Math.max(0, this.frames.size() - 1);
      List<MocapBlockChange> ordered = new ArrayList(this.changes.size());

      for(MocapBlockChange change : this.changes) {
         ordered.add(change.frame() > last ? change.withFrame(last) : change);
      }

      ordered.sort(Comparator.comparingInt(MocapBlockChange::frame));
      this.recordContainerClose();
      List<MocapAction> orderedActions = new ArrayList(this.actions.size());

      for(MocapAction action : this.actions) {
         orderedActions.add(action.frame() > last ? action.withFrame(last) : action);
      }

      orderedActions.sort(Comparator.comparingInt(MocapAction::frame));
      return new MocapRecording(this.worldId, this.frames, ordered, orderedActions);
   }

   private ItemStack[] snapshotEquipmentIfChanged() {
      PlayerInventory inv = this.player.getInventory();
      ItemStack[] now = new ItemStack[]{clone(inv.getItemInMainHand()), clone(inv.getItemInOffHand()), clone(inv.getHelmet()), clone(inv.getChestplate()), clone(inv.getLeggings()), clone(inv.getBoots())};
      if (this.lastEquipment != null) {
         boolean same = true;

         for(int i = 0; i < now.length; ++i) {
            if (!sameItem(now[i], this.lastEquipment[i])) {
               same = false;
               break;
            }
         }

         if (same) {
            return null;
         }
      }

      this.lastEquipment = now;
      return now;
   }

   private static ItemStack clone(ItemStack stack) {
      return stack == null ? null : stack.clone();
   }

   private static boolean sameItem(ItemStack a, ItemStack b) {
      boolean aEmpty = a == null || a.getType().isAir();
      boolean bEmpty = b == null || b.getType().isAir();
      if (!aEmpty && !bEmpty) {
         return a.equals(b);
      } else {
         return aEmpty && bEmpty;
      }
   }

   public static void applyEquipment(EntityEquipment equipment, ItemStack[] snapshot) {
      if (equipment != null && snapshot != null && snapshot.length >= 6) {
         equipment.setItemInMainHand(clone(snapshot[0]));
         equipment.setItemInOffHand(clone(snapshot[1]));
         equipment.setHelmet(clone(snapshot[2]));
         equipment.setChestplate(clone(snapshot[3]));
         equipment.setLeggings(clone(snapshot[4]));
         equipment.setBoots(clone(snapshot[5]));
      }
   }

   public static void setLid(Location location, boolean open) {
      if (location != null && location.getWorld() != null) {
         BlockState state = location.getBlock().getState(false);
         if (state instanceof Lidded) {
            Lidded lidded = (Lidded)state;
            if (open) {
               lidded.open();
            } else {
               lidded.close();
            }
         }

      }
   }

   public static boolean isFancyPose(Pose pose) {
      return pose != null && pose != Pose.STANDING && pose != Pose.SNEAKING;
   }

   static {
      REPLAYABLE_PROJECTILES = Set.of(EntityType.ARROW, EntityType.SPECTRAL_ARROW, EntityType.TRIDENT, EntityType.SNOWBALL, EntityType.EGG, EntityType.ENDER_PEARL, EntityType.EXPERIENCE_BOTTLE, EntityType.SPLASH_POTION, EntityType.LINGERING_POTION, EntityType.WIND_CHARGE, EntityType.FIREWORK_ROCKET);
   }
}
