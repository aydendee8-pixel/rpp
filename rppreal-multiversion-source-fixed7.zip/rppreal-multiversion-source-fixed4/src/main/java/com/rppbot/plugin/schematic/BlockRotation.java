package com.rppbot.plugin.schematic;

import java.util.EnumMap;
import java.util.Map;
import org.bukkit.Axis;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;
import org.bukkit.block.data.MultipleFacing;
import org.bukkit.block.data.Orientable;
import org.bukkit.block.data.Rail;
import org.bukkit.block.data.Rotatable;
import org.bukkit.block.data.Rail.Shape;
import org.bukkit.block.data.type.RedstoneWire;
import org.bukkit.block.data.type.Wall;

public final class BlockRotation {
   private static final BlockFace[] ROTATABLE_ORDER;

   private BlockRotation() {
   }

   public static BlockData clockwise(BlockData data) {
      if (data == null) {
         return null;
      } else {
         BlockData copy = data.clone();

         try {
            if (copy instanceof Directional) {
               Directional directional = (Directional)copy;
               BlockFace next = cw(directional.getFacing());
               if (directional.getFaces().contains(next)) {
                  directional.setFacing(next);
               }
            }

            if (copy instanceof Rotatable) {
               Rotatable rotatable = (Rotatable)copy;
               rotatable.setRotation(cwRotatable(rotatable.getRotation()));
            }

            if (copy instanceof Orientable) {
               Orientable orientable = (Orientable)copy;
               Axis axis = orientable.getAxis();
               if (axis == Axis.X) {
                  orientable.setAxis(Axis.Z);
               } else if (axis == Axis.Z) {
                  orientable.setAxis(Axis.X);
               }
            }

            if (copy instanceof MultipleFacing) {
               MultipleFacing multi = (MultipleFacing)copy;
               Map<BlockFace, Boolean> old = new EnumMap(BlockFace.class);

               for(BlockFace face : multi.getAllowedFaces()) {
                  old.put(face, multi.hasFace(face));
               }

               for(BlockFace face : old.keySet()) {
                  multi.setFace(face, false);
               }

               for(Map.Entry<BlockFace, Boolean> e : old.entrySet()) {
                  BlockFace target = cw((BlockFace)e.getKey());
                  if ((Boolean)e.getValue() && old.containsKey(target)) {
                     multi.setFace(target, true);
                  }
               }
            }

            if (copy instanceof Wall) {
               Wall wall = (Wall)copy;
               Wall.Height n = wall.getHeight(BlockFace.NORTH);
               Wall.Height e = wall.getHeight(BlockFace.EAST);
               Wall.Height s = wall.getHeight(BlockFace.SOUTH);
               Wall.Height w = wall.getHeight(BlockFace.WEST);
               wall.setHeight(BlockFace.EAST, n);
               wall.setHeight(BlockFace.SOUTH, e);
               wall.setHeight(BlockFace.WEST, s);
               wall.setHeight(BlockFace.NORTH, w);
            }

            if (copy instanceof RedstoneWire) {
               RedstoneWire wire = (RedstoneWire)copy;
               Map<BlockFace, RedstoneWire.Connection> old = new EnumMap(BlockFace.class);

               for(BlockFace face : wire.getAllowedFaces()) {
                  old.put(face, wire.getFace(face));
               }

               for(Map.Entry<BlockFace, RedstoneWire.Connection> e : old.entrySet()) {
                  BlockFace target = cw((BlockFace)e.getKey());
                  if (old.containsKey(target)) {
                     wire.setFace(target, (RedstoneWire.Connection)e.getValue());
                  }
               }
            }

            if (copy instanceof Rail) {
               Rail rail = (Rail)copy;
               Rail.Shape next = cwRailShape(rail.getShape());
               if (rail.getShapes().contains(next)) {
                  rail.setShape(next);
               }
            }

            return copy;
         } catch (RuntimeException var7) {
            return data;
         }
      }
   }

   private static BlockFace cw(BlockFace face) {
      BlockFace var10000;
      switch (face) {
         case NORTH -> var10000 = BlockFace.EAST;
         case EAST -> var10000 = BlockFace.SOUTH;
         case SOUTH -> var10000 = BlockFace.WEST;
         case WEST -> var10000 = BlockFace.NORTH;
         default -> var10000 = face;
      }

      return var10000;
   }

   private static BlockFace cwRotatable(BlockFace face) {
      for(int i = 0; i < ROTATABLE_ORDER.length; ++i) {
         if (ROTATABLE_ORDER[i] == face) {
            return ROTATABLE_ORDER[(i + 4) % ROTATABLE_ORDER.length];
         }
      }

      return face;
   }

   private static Rail.Shape cwRailShape(Rail.Shape shape) {
      Rail.Shape var10000;
      switch (shape) {
         case NORTH_SOUTH -> var10000 = Shape.EAST_WEST;
         case EAST_WEST -> var10000 = Shape.NORTH_SOUTH;
         case ASCENDING_NORTH -> var10000 = Shape.ASCENDING_EAST;
         case ASCENDING_EAST -> var10000 = Shape.ASCENDING_SOUTH;
         case ASCENDING_SOUTH -> var10000 = Shape.ASCENDING_WEST;
         case ASCENDING_WEST -> var10000 = Shape.ASCENDING_NORTH;
         case NORTH_EAST -> var10000 = Shape.SOUTH_EAST;
         case SOUTH_EAST -> var10000 = Shape.SOUTH_WEST;
         case SOUTH_WEST -> var10000 = Shape.NORTH_WEST;
         case NORTH_WEST -> var10000 = Shape.NORTH_EAST;
         default -> var10000 = shape;
      }

      return var10000;
   }

   static {
      ROTATABLE_ORDER = new BlockFace[]{BlockFace.NORTH, BlockFace.NORTH_NORTH_EAST, BlockFace.NORTH_EAST, BlockFace.EAST_NORTH_EAST, BlockFace.EAST, BlockFace.EAST_SOUTH_EAST, BlockFace.SOUTH_EAST, BlockFace.SOUTH_SOUTH_EAST, BlockFace.SOUTH, BlockFace.SOUTH_SOUTH_WEST, BlockFace.SOUTH_WEST, BlockFace.WEST_SOUTH_WEST, BlockFace.WEST, BlockFace.WEST_NORTH_WEST, BlockFace.NORTH_WEST, BlockFace.NORTH_NORTH_WEST};
   }
}
