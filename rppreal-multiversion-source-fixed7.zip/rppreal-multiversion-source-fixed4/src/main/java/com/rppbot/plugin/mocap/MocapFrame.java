package com.rppbot.plugin.mocap;

import org.bukkit.entity.Pose;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

public record MocapFrame(double x, double y, double z, float yaw, float pitch, boolean sneaking, boolean sprinting, Pose pose, boolean swingMain, boolean swingOff, ItemStack[] equipment, EquipmentSlot usingHand, boolean gliding, boolean riptiding) {
}
